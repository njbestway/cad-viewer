import { AcDbObject } from '../../base/index.js';
/**
 * Boundary at which a shared snapshot is re-fingerprinted.
 *
 * The four boundaries are the only places where snapshot sharing can turn from
 * a saved clone into a correctness bug: a transaction ending (`commit`,
 * `abort`) or a change being replayed (`undo`, `redo`).
 */
export type AcDbSnapshotIntegrityBoundary = 'commit' | 'abort' | 'undo' | 'redo';
/**
 * One detected mutation of a snapshot that was supposed to be immutable.
 */
export interface AcDbSnapshotIntegrityViolation {
    /** Boundary at which the difference was seen. */
    boundary: AcDbSnapshotIntegrityBoundary;
    /** Object whose snapshot changed. */
    objectId: string;
    /**
     * Snapshot side-keys whose fingerprint moved.
     *
     * `_attrs` is reported when an attribute value or attribute-set changed,
     * `_xDataMap` when extended data changed; every other entry is an own
     * property name that participates in `copySnapshotStateTo`.
     */
    changedKeys: string[];
}
/**
 * Result of one integrity pass.
 *
 * `copyOnWriteCount === 0` is not evidence on its own: it only says the sharing
 * layer never asked for a copy, not that nobody wrote to the snapshot. The
 * counts below are what the acceptance criteria read.
 */
export interface AcDbSnapshotIntegrityMetrics {
    /** True when a probe is attached to the transaction manager. */
    enabled: boolean;
    /** Snapshots currently fingerprinted and watched. */
    watchedSnapshots: number;
    /** Successful re-fingerprints (one per watched snapshot per boundary). */
    checks: number;
    /** Boundaries for which at least one pass ran. */
    checkedBoundaries: number;
    /** Snapshots that differed from their recorded fingerprint. */
    violations: number;
    /** Watches dropped because `maxWatched` was reached. */
    evictedSnapshots: number;
    /** Last boundary that ran a pass, or null. */
    lastBoundary: AcDbSnapshotIntegrityBoundary | null;
    /** Violations found by the last pass. */
    lastPassViolations: number;
    /** Most recent violations, capped at {@link AcDbSnapshotIntegrityProbeOptions.maxViolationLog}. */
    recentViolations: AcDbSnapshotIntegrityViolation[];
}
/** Options for {@link AcDbSnapshotIntegrityProbe}. */
export interface AcDbSnapshotIntegrityProbeOptions {
    /**
     * Maximum number of watched snapshots.
     *
     * Watches are dropped oldest-first when the cap is reached, so a long
     * session pays a bounded amount of bookkeeping. Default `20000`.
     */
    maxWatched?: number;
    /** Maximum violations retained for reporting. Default `32`. */
    maxViolationLog?: number;
}
/**
 * Per-side-key fingerprints of one snapshot.
 *
 * `_attrs` and `_xDataMap` are fingerprinted separately from the own
 * properties because they are the two containers `restoreFrom` treats
 * specially, and a violation is far easier to read when it names the side
 * instead of "something changed".
 */
export declare function acdbFingerprintSnapshot(snapshot: AcDbObject): Record<string, string>;
/**
 * Development/test-only integrity probe for shared snapshots.
 *
 * Attach one to `AcDbDatabaseTransactionManager.snapshotIntegrityProbe` and
 * every snapshot that is shared between the rollback map and the undo record is
 * fingerprinted when it is created and re-fingerprinted at commit, abort, undo
 * and redo. Snapshot sharing is safe exactly as long as nothing ever writes to
 * a snapshot; this class turns that assumption into an assertion.
 *
 * Cost is confined to the probe: when the manager field is `undefined` the
 * kernel performs one property read per snapshot and no hashing at all, so the
 * production performance path is untouched.
 */
export declare class AcDbSnapshotIntegrityProbe {
    private readonly maxWatched;
    private readonly maxViolationLog;
    /** objectId → recorded fingerprints, in insertion order for FIFO eviction. */
    private readonly watched;
    private readonly violations;
    private _checks;
    private _checkedBoundaries;
    private _violations;
    private _evicted;
    private _lastBoundary;
    private _lastPassViolations;
    constructor(options?: AcDbSnapshotIntegrityProbeOptions);
    /** Number of snapshots currently watched. */
    get watchedSnapshots(): number;
    /**
     * Records the state of a snapshot that is about to be shared.
     *
     * @param objectId - Owner of the snapshot; later passes report it verbatim.
     * @param snapshot - The clone that both the rollback map and the undo record hold.
     */
    watch(objectId: string, snapshot: AcDbObject): void;
    /** Stops watching one object, for example once its undo record is discarded. */
    release(objectId: string): void;
    /** Drops every watch and every counted violation. */
    clear(): void;
    /**
     * Compares one snapshot with its recorded fingerprint.
     *
     * @param objectId - Owner of the snapshot.
     * @param snapshot - Snapshot to re-fingerprint; must be the same object that was watched.
     * @param boundary - Boundary being crossed, for the report.
     * @returns True when the snapshot is unchanged.
     */
    check(objectId: string, snapshot: AcDbObject, boundary: AcDbSnapshotIntegrityBoundary): boolean;
    /**
     * Re-fingerprints every watched snapshot.
     *
     * The caller is responsible for passing the boundary; `undo` and `redo` are
     * separate entries because the same record is replayed in both directions and
     * a violation should name the direction that saw it.
     *
     * @param boundary - Boundary being crossed.
     * @param resolve - Optional snapshot lookup; without it the pass cannot
     *   re-read the object and only counts the boundary.
     * @returns Number of violations found by this pass.
     */
    checkAll(boundary: AcDbSnapshotIntegrityBoundary, resolve?: (objectId: string) => AcDbObject | undefined): number;
    /**
     * Counts a boundary even when the caller holds its own snapshot references.
     *
     * Used by the commit path, which verifies the transaction's `originalStates`
     * map directly instead of resolving through the database.
     */
    noteBoundary(boundary: AcDbSnapshotIntegrityBoundary, violations: number): void;
    /** Snapshot of the probe's counters; see {@link AcDbSnapshotIntegrityMetrics}. */
    getMetrics(): AcDbSnapshotIntegrityMetrics;
}
//# sourceMappingURL=AcDbSnapshotSharingIntegrity.d.ts.map