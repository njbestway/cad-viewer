import { AcDbUndoRecord } from './AcDbUndoRecord.js';
import type { AcDbDatabaseChange } from './AcDbDatabaseChange.js';
/**
 * Manages undo and redo history for database changes.
 *
 * Stores committed {@link AcDbUndoRecord} entries. {@link push} is the
 * user-initiated entry point and clears the redo stack, while
 * {@link pushUndo} only restores an undone record during a redo so the
 * remaining redo records survive.
 */
export declare class AcDbUndoStack {
    private readonly undoRecords;
    private readonly redoRecords;
    /** Maximum number of undo records retained. */
    maxDepth: number;
    /**
     * Pushes a new undo record and clears redo history.
     *
     * Use this when the user performs a new operation: any previously undone
     * step can no longer be redone, so the redo stack is discarded.
     *
     * When {@link maxDepth} is exceeded, the oldest undo record is discarded.
     *
     * @param record - Undo record produced by {@link AcDbDatabaseTransactionManager}
     */
    push(record: AcDbUndoRecord): void;
    /**
     * Pushes a record back onto the undo stack without clearing redo history.
     *
     * Used when replaying a redo. Calling {@link push} in that situation would
     * discard the remaining redo records, which made it impossible to redo more
     * than one step in a row.
     *
     * @param record - Record that was just redone
     */
    pushUndo(record: AcDbUndoRecord): void;
    /**
     * Discards the oldest undo records when {@link maxDepth} is exceeded.
     */
    private trimUndoRecords;
    /**
     * Removes and returns the most recent undo record.
     *
     * @returns The record popped from the undo stack, or undefined when empty
     */
    popUndo(): AcDbUndoRecord | undefined;
    /**
     * Stores an undo record on the redo stack after {@link popUndo}.
     *
     * @param record - Record that was just undone and may be redone
     */
    pushRedo(record: AcDbUndoRecord): void;
    /**
     * Removes and returns the most recent redo record.
     *
     * @returns The record popped from the redo stack, or undefined when empty
     */
    popRedo(): AcDbUndoRecord | undefined;
    /**
     * Returns true when at least one undo record is available.
     */
    canUndo(): boolean;
    /**
     * Returns true when at least one redo record is available.
     */
    canRedo(): boolean;
    /**
     * Number of change entries retained by both stacks.
     *
     * Phase 2.10 diagnostic: this is the part of retained memory that undo
     * history owns on purpose, so it can be reported separately from anything
     * that should have been released but was not.
     */
    get retainedChangeCount(): number;
    /** Change entries retained by the undo stack alone. */
    get undoChangeCount(): number;
    /** Change entries retained by the redo stack alone. */
    get redoChangeCount(): number;
    /**
     * Visits every change entry retained by both stacks.
     *
     * Used by the phase 2.10 byte estimate: the estimator has to look at every
     * snapshot the history holds, and the stacks are otherwise opaque.
     *
     * @param visit - Called once per retained change, undo stack first
     */
    forEachChange(visit: (change: AcDbDatabaseChange) => void): void;
    /**
     * Discards all undo and redo records.
     */
    clear(): void;
}
//# sourceMappingURL=AcDbUndoStack.d.ts.map