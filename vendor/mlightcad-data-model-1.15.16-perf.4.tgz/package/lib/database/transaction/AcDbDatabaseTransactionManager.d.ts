import { AcDbObject } from '../../base/index.js';
import { AcDbDatabase } from '../AcDbDatabase.js';
import { AcDbChangeContainer } from './AcDbDatabaseChange.js';
import { AcDbDatabaseTransaction } from './AcDbDatabaseTransaction.js';
import { AcDbSnapshotSharingMetrics, AcDbSnapshotSizeEstimator } from './AcDbSnapshotSharingMetrics.js';
import { AcDbSnapshotIntegrityMetrics, AcDbSnapshotIntegrityProbe } from './AcDbSnapshotSharingIntegrity.js';
/**
 * Manages database transactions and undo/redo history for one {@link AcDbDatabase}.
 *
 * Aligns with ObjectARX {@code AcDbTransactionManager} semantics and provides
 * undo mark grouping for editor commands.
 */
export declare class AcDbDatabaseTransactionManager {
    private readonly database;
    private readonly transactionStack;
    private readonly undoStack;
    private readonly changeApplier;
    private readonly undoMarkStack;
    private _applyingUndoRedo;
    private readonly _pendingEntityModified;
    private readonly _pendingLayerModified;
    /**
     * When true, mutations outside an active transaction throw an error.
     *
     * Undo/redo replay is exempt so {@link AcDbChangeApplier} can restore state.
     */
    strictMode: boolean;
    /**
     * Phase 2.10 experiment switch: reuse the rollback snapshot as the undo
     * `before` snapshot.
     *
     * While false (the default) a first write clones twice, exactly as in
     * `1.15.16-perf.3`. The A/B harness flips it per session so both arms run the
     * same build. It is read once, when a transaction is created, so flipping it
     * never changes a transaction that is already open.
     */
    snapshotSharing: boolean;
    /**
     * Optional per-snapshot byte estimate, forwarded to every new transaction.
     *
     * Undefined by default so the production path does no estimation work.
     */
    snapshotSizeEstimator: AcDbSnapshotSizeEstimator | undefined;
    /** Accumulated phase 2.10 counters; see {@link getSnapshotSharingMetrics}. */
    private readonly _snapshotMetrics;
    /**
     * Optional shared-snapshot integrity probe (phase 2.11, task A2).
     *
     * Attach one in development and test builds to prove that a snapshot shared
     * between the rollback map and the undo record is never written. Undefined by
     * default, which is what keeps the production performance path free of
     * fingerprinting: the kernel only reads this field.
     */
    snapshotIntegrityProbe: AcDbSnapshotIntegrityProbe | undefined;
    /**
     * Creates a transaction manager for one database.
     *
     * @param database - Database whose mutations and undo history are managed
     */
    constructor(database: AcDbDatabase);
    /**
     * Starts a new database transaction and pushes it onto the stack.
     *
     * Equivalent to ObjectARX `AcDbTransactionManager::startTransaction()`.
     *
     * @returns The newly created transaction
     */
    startTransaction(): AcDbDatabaseTransaction;
    /**
     * Returns the top-most active transaction, if any.
     */
    currentTransaction(): AcDbDatabaseTransaction | undefined;
    /**
     * Returns true when at least one transaction is active.
     */
    hasTransaction(): boolean;
    /**
     * Returns true when mutations should be recorded into the current transaction.
     *
     * Recording is disabled while undo/redo is being applied.
     */
    isRecording(): boolean;
    /**
     * Returns true while {@link AcDbChangeApplier} is replaying undo or redo changes.
     */
    isApplyingUndoRedo(): boolean;
    /**
     * Returns true when the object was opened for write in an active transaction.
     *
     * Used by {@link AcDbSymbolTableRecord.assertOpenForWrite} to enforce ObjectARX
     * write semantics. A modify entry in a transaction recorder indicates the object
     * was opened with {@link AcDbOpenMode.kForWrite}, including entries merged from
     * nested transactions.
     *
     * @param objectId - Object identifier to check
     */
    isOpenedForWriteInTransaction(objectId: string): boolean;
    /**
     * Commits the current transaction.
     *
     * Nested transactions merge their recorder into the parent. The outermost
     * commit finalizes changes, dispatches events, and enqueues undo history
     * when an undo mark is active.
     *
     * @throws Error if no transaction is active
     */
    commitTransaction(): void;
    /**
     * Aborts the current transaction and rolls back all recorded changes.
     *
     * @throws Error if no transaction is active
     */
    abortTransaction(): void;
    /**
     * Opens an undo-mark group.
     *
     * Commits performed before {@link endUndoMark} are merged into one
     * {@link AcDbUndoRecord}.
     *
     * @param label - Optional label for undo UI (for example, `"Move"`)
     */
    startUndoMark(label?: string): void;
    /**
     * Closes the current undo mark and pushes a record when changes were committed.
     *
     * @throws Error if no undo mark is active
     */
    endUndoMark(): void;
    /**
     * Discards the current undo mark without creating an undo record.
     */
    cancelUndoMark(): void;
    /**
     * Undoes the most recent undo record.
     *
     * @returns True when an undo record was applied; false when the stack is empty
     */
    undo(): boolean;
    /**
     * Redoes the most recently undone record.
     *
     * @returns True when a redo record was applied; false when the redo stack is empty
     */
    redo(): boolean;
    /**
     * Returns true when at least one undo record is available.
     */
    canUndo(): boolean;
    /**
     * Returns true when at least one redo record is available.
     */
    canRedo(): boolean;
    /**
     * Clears both undo and redo history for this database.
     */
    clearUndoStack(): void;
    /**
     * Phase 2.10 counters accumulated since {@link resetSnapshotSharingMetrics}.
     *
     * The retained fields are sampled at call time rather than accumulated, so a
     * caller can watch the undo history's own footprint separately from the
     * clone counts. Byte estimates stay 0 unless
     * {@link snapshotSizeEstimator} is set.
     *
     * @returns A copy; mutating it does not affect the manager
     */
    getSnapshotSharingMetrics(): AcDbSnapshotSharingMetrics;
    /** Zeroes every counter without touching the undo history. */
    resetSnapshotSharingMetrics(): void;
    /**
     * Shared-snapshot integrity counters (phase 2.11, task A2).
     *
     * `enabled: false` when no probe is attached, which is the production
     * default. `copyOnWriteCount === 0` from
     * {@link getSnapshotSharingMetrics} is not evidence that a shared snapshot
     * stayed unchanged; `checks` and `violations` are.
     *
     * @returns A copy; mutating it does not affect the probe
     */
    getSnapshotIntegrityMetrics(): AcDbSnapshotIntegrityMetrics;
    /**
     * Re-fingerprints the `before` snapshots of one undo record.
     *
     * Undo and redo both read `change.before` through `restoreFrom`, so a write
     * to a shared snapshot shows up here before it can corrupt the replay. Only
     * object changes carry an `AcDbObject` payload; attribute changes are
     * skipped.
     *
     * @param changes - Changes of the record about to be replayed
     * @param boundary - `undo` or `redo`
     */
    private verifyUndoPayload;
    /**
     * Adds caller-measured transform time to the metrics.
     *
     * The kernel never sees the transform itself — a caller mutates the opened
     * object — so the harness reports its own measurement here instead of the
     * kernel inventing one.
     *
     * @param ms - Milliseconds spent transforming in the measured window
     */
    addSnapshotTransformMs(ms: number): void;
    /**
     * Folds one transaction's counters into the accumulated metrics.
     *
     * @param tr - Transaction that is leaving the stack
     * @param includeRecorder - False for a nested commit, whose recorder counters
     *   have already rolled up into the parent via `mergeFrom`
     */
    private absorbTransactionCounters;
    /** Estimated bytes of every snapshot the undo/redo stacks currently hold. */
    private estimateRetainedSnapshotBytes;
    /**
     * Records append of an object into a container during the active transaction.
     *
     * No-op when {@link isRecording} is false.
     *
     * @param container - Container that received the object
     * @param object - Object that was appended
     */
    recordAppend(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records removal of an object from a container during the active transaction.
     *
     * No-op when {@link isRecording} is false.
     *
     * @param container - Container that owned the removed object
     * @param object - Object that was removed
     */
    recordRemove(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records the pre-change value of a system variable.
     *
     * No-op when {@link isRecording} is false.
     *
     * @param name - System variable name
     * @param before - Value observed before mutation
     */
    recordSysvar(name: string, before: unknown): void;
    /**
     * Maps a symbol table instance to the stable name stored in undo records.
     *
     * @param table - Symbol table whose logical name is needed
     * @returns Known table name, or the table's object ID as a fallback
     */
    resolveSymbolTableName(table: {
        objectId: string;
    }): string;
    /**
     * Runs one undoable editor command inside a transaction and undo mark.
     *
     * On success the transaction is committed and the undo mark is closed.
     * On failure the transaction is aborted and the undo mark is cancelled.
     *
     * @param label - Label stored on the resulting undo record
     * @param fn - Callback that performs the command using the active transaction
     * @returns The value returned by `fn`
     */
    runUndoable<T>(label: string, fn: (tr: AcDbDatabaseTransaction) => T): T;
    /**
     * Appends committed changes to the active undo mark, if any.
     *
     * Called after the outermost transaction commit so multiple commits within
     * one {@link startUndoMark} group merge into a single {@link AcDbUndoRecord}.
     *
     * @param changes - Finalized changes from the committed transaction
     */
    private enqueueUndoChanges;
    /**
     * Dispatches entity, dictionary, and sysvar events after a successful commit.
     *
     * @param changes - Finalized changes from the committed outermost transaction
     */
    private dispatchCommitEvents;
    /**
     * Dispatches entity, dictionary, and sysvar events after undo or redo replay.
     *
     * Append/remove and dictionary notifications are swapped when `inverse` is
     * true so listeners observe the same semantics as the user-facing operation.
     *
     * @param changes - Changes from the undo record being applied
     * @param inverse - True when undoing (inverse replay); false when redoing
     */
    private dispatchUndoRedoEvents;
    /**
     * Dispatches or queues a layer-modified notification after commit or undo/redo.
     */
    private dispatchLayerModified;
    /**
     * Dispatches or queues an entity-modified notification after commit or undo/redo.
     */
    private dispatchEntityModified;
    /**
     * Dispatches layer-modified notifications accumulated during event batching.
     *
     * Called from {@link AcDbDatabase.endEventBatch} when the outermost batch closes.
     */
    flushPendingLayerModifiedEvents(): void;
    /**
     * Dispatches entity-modified notifications accumulated during event batching.
     *
     * Called from {@link AcDbDatabase.endEventBatch} when the outermost batch closes.
     */
    flushPendingEntityModifiedEvents(): void;
}
//# sourceMappingURL=AcDbDatabaseTransactionManager.d.ts.map