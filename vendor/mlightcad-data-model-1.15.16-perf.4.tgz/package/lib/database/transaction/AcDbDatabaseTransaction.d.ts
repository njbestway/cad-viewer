import { AcDbObject, AcDbObjectId } from '../../base/index.js';
import { AcDbDatabase } from '../AcDbDatabase.js';
import { AcDbTransaction, AcDbTransactionOptions } from './AcDbTransaction.js';
/**
 * Database-bound transaction with object lookup through {@link AcDbDatabase}.
 *
 * Created by {@link AcDbDatabaseTransactionManager.startTransaction} and
 * returned from {@link AcDbDatabaseTransactionManager.runUndoable}.
 */
export declare class AcDbDatabaseTransaction extends AcDbTransaction {
    private readonly database;
    /**
     * @param database - Database whose objects are opened and recorded
     * @param options - Snapshot-sharing experiment knobs forwarded to the base class
     */
    constructor(database: AcDbDatabase, options?: AcDbTransactionOptions);
    /**
     * Resolves an object ID through the owning database.
     *
     * @param objectId - Identifier of the object to open
     * @param openErased - Reserved for erased-object support
     * @returns The matching live object
     * @throws Error when the object cannot be found
     */
    protected lookupObject<T extends AcDbObject>(objectId: AcDbObjectId, openErased: boolean): T;
}
//# sourceMappingURL=AcDbDatabaseTransaction.d.ts.map