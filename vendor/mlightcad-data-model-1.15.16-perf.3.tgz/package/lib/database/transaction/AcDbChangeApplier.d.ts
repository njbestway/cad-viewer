import { AcDbObject } from '../../base/index.js';
import { AcDbEntity } from '../../entity/AcDbEntity.js';
import { AcDbDatabase, AcDbLayerModifiedEventArgs } from '../AcDbDatabase.js';
import { AcDbLayerTableRecord, AcDbLayerTableRecordAttrs } from '../AcDbLayerTableRecord.js';
import { AcDbDatabaseChange } from './AcDbDatabaseChange.js';
/**
 * Applies forward or inverse database changes for undo/redo operations.
 *
 * Structural changes (append/remove) and property snapshots (modify/sysvar)
 * are replayed against a live {@link AcDbDatabase} instance.
 */
export declare class AcDbChangeApplier {
    private readonly database;
    /**
     * Creates an applier bound to one database.
     *
     * @param database - Database whose containers and objects receive replayed changes
     */
    constructor(database: AcDbDatabase);
    /**
     * Replays changes in commit order.
     *
     * Used by redo and by applying the forward direction of an undo record.
     *
     * Removals from one block table record are interchangeable, so a maximal run
     * of consecutive ones is replayed with a single
     * `AcDbBlockTableRecord.removeEntity(ids)` call. Every other change — a
     * modify, a sysvar, an append, a removal from a different container — is an
     * ordering barrier: it flushes the pending run and is then replayed in
     * place, so the logical order of the record is unchanged. The change list
     * itself is never reordered, which is what keeps the post-replay event
     * stream identical — it is derived from that list, not from the execution
     * order.
     *
     * @param changes - Ordered list of changes recorded by {@link AcDbChangeRecorder}
     */
    applyForward(changes: AcDbDatabaseChange[]): void;
    /**
     * Replays the inverse of each change in reverse order.
     *
     * Used by undo and transaction abort to restore the prior database state.
     *
     * @param changes - Ordered list of changes recorded by {@link AcDbChangeRecorder}
     */
    applyInverse(changes: AcDbDatabaseChange[]): void;
    /**
     * Dispatches one recorded change in the requested direction.
     *
     * @param change - Single entry from a transaction or undo record
     * @param forward - When true, replay the original mutation; when false, apply its inverse
     */
    private applyChange;
    /**
     * Removes a run of objects from one block table record in a single call.
     *
     * The result is defined by the surviving sequence only: stable compaction
     * yields the same entity order whether the ids are removed one at a time or
     * together, duplicate ids collapse in both forms, and ids that are already
     * gone are silently skipped by `AcDbBlockTableRecord.removeEntity`.
     *
     * Nothing is recorded and nothing is dispatched here. During replay the
     * block table record sees `isRecording()` false (there is no transaction on
     * the stack) and `isApplyingUndoRedo()` true, so it neither records nor
     * notifies; undo/redo events are produced from the change list after the
     * replay completes.
     *
     * Both of those properties are what make the collapse unobservable, so the
     * collapse is restricted to that context. A caller outside a replay gets the
     * per-change replay instead: with no transaction open the block table record
     * notifies `entityErased` once per removal, and inside an open transaction it
     * records the removals in change-list order. Fusing either of those into one
     * bulk call is observable, and no production path asks for it.
     *
     * @param ownerId - Object id of the block table record holding the objects
     * @param objects - Removed entities in recorded order; must not be empty
     */
    private applyRemoveBatch;
    /**
     * Restores object property state from a modify snapshot.
     *
     * @param change - Modify entry with before/after clones
     * @param forward - When true, apply `after`; when false, apply `before`
     */
    private applyModify;
    /**
     * Restores a system variable from a sysvar snapshot.
     *
     * @param change - Sysvar entry with before/after values
     * @param forward - When true, apply `after`; when false, apply `before`
     */
    private applySysvar;
    /**
     * Re-inserts an object into the container described by `container`.
     *
     * @param container - Target block table record, symbol table, or dictionary entry
     * @param object - Object snapshot to append
     */
    private applyAppend;
    /**
     * Removes an object from the container described by `container`.
     *
     * @param container - Source block table record, symbol table, or dictionary entry
     * @param object - Object whose {@link AcDbObject.objectId} identifies the removal target
     */
    private applyRemove;
    /**
     * Resolves a symbol table instance from the stable name stored in undo records.
     *
     * @param tableName - Logical table name (for example, `"layerTable"`) or unknown fallback ID
     * @returns Matching table on this applier's database, or undefined when unrecognized
     */
    private getSymbolTable;
}
/**
 * Collects entities affected by changes for post-commit/undo/redo event dispatch.
 *
 * Only block-table-record append/remove operations contribute to the
 * appended and erased lists; modify entries always resolve through object IDs.
 *
 * @param database - Database used to resolve live entity references
 * @param changes - Changes produced by a transaction or undo record
 * @returns Entity buckets keyed by the kind of structural or property change
 */
export declare function acdbCollectChangeEntities(database: AcDbDatabase, changes: AcDbDatabaseChange[]): {
    /** Entities whose properties were modified */
    modified: AcDbEntity[];
    /** Entities appended to a block table record */
    appended: AcDbEntity[];
    /** Entities removed from a block table record */
    erased: AcDbEntity[];
};
/**
 * One dictionary entry referenced by an append or remove change.
 */
export interface AcDbDictionaryChangeEntry {
    /** Dictionary object that was set or erased */
    object: AcDbObject;
    /** Dictionary key associated with the object */
    key: string;
}
/**
 * Collects dictionary entries affected by changes for post-commit/undo/redo dispatch.
 *
 * @param database - Database used to resolve live object references after replay
 * @param changes - Changes produced by a transaction or undo record
 * @returns Dictionary entries grouped by set and erase operations
 */
export declare function acdbCollectDictionaryChanges(database: AcDbDatabase, changes: AcDbDatabaseChange[]): {
    /** Entries inserted or replaced in a dictionary */
    set: AcDbDictionaryChangeEntry[];
    /** Entries removed from a dictionary */
    erased: AcDbDictionaryChangeEntry[];
};
/**
 * Compares two layer table record snapshots and returns changed attribute values.
 *
 * @param before - State before modification
 * @param after - State after modification
 * @returns Changed attributes mapped to their values in `after`
 */
export declare function acdbDiffLayerTableRecordAttrs(before: AcDbLayerTableRecord, after: AcDbLayerTableRecord): Partial<AcDbLayerTableRecordAttrs>;
/**
 * Collects layer modification events from transaction or undo record changes.
 *
 * @param database - Database used to resolve live layer references
 * @param changes - Changes produced by a transaction or undo record
 * @param inverse - When true, compute diffs for undo replay
 * @returns Layer-modified event payloads for dispatch
 */
export declare function acdbCollectLayerModifications(database: AcDbDatabase, changes: AcDbDatabaseChange[], inverse?: boolean): AcDbLayerModifiedEventArgs[];
//# sourceMappingURL=AcDbChangeApplier.d.ts.map