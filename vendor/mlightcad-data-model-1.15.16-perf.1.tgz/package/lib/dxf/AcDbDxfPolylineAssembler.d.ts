import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbEntity } from '../entity/AcDbEntity.js';
/**
 * Reads a POLYLINE header + following VERTEX entities until SEQEND and builds
 * the matching AcDb 2d/3d/mesh/polyface polyline (parity with
 * `AcDbEntityConverter.convertPolyline`).
 *
 * Expects the filer positioned just after the `(0, POLYLINE)` pair.
 * XData on the POLYLINE header (before VERTEX) is preserved on the result.
 */
export declare function acdbDxfInPolyline(filer: AcDbDxfFiler): AcDbEntity | null;
//# sourceMappingURL=AcDbDxfPolylineAssembler.d.ts.map