import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbEntity } from '../entity/AcDbEntity.js';
/**
 * Drain one DIMENSION object's pairs (including XData) and create the matching
 * dimension subclass via group-100 markers (with group-70 type-bit fallback).
 *
 * Expects the filer just after `(0, DIMENSION)`.
 */
export declare function acdbDxfInDimension(filer: AcDbDxfFiler): AcDbEntity | null;
//# sourceMappingURL=AcDbDxfDimensionAssembler.d.ts.map