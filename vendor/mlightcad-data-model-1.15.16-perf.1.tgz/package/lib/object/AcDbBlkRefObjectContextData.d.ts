import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative block references
 * (`AcDbBlkRefObjectContextData`).
 */
export declare class AcDbBlkRefObjectContextData extends AcDbAnnotScaleObjectContextData {
    private _position;
    private _rotation;
    private _scaleX;
    private _scaleY;
    private _scaleZ;
    get position(): AcGePoint3d;
    set position(value: AcGePoint3d);
    get rotation(): number;
    set rotation(value: number);
    get scaleX(): number;
    set scaleX(value: number);
    get scaleY(): number;
    set scaleY(value: number);
    get scaleZ(): number;
    set scaleZ(value: number);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbBlkRefObjectContextData.d.ts.map