import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative leaders / multileaders
 * (`AcDbLeaderObjectContextData`).
 */
export declare class AcDbLeaderObjectContextData extends AcDbAnnotScaleObjectContextData {
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbLeaderObjectContextData.d.ts.map