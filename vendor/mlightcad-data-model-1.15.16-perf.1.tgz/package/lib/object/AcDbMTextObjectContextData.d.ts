import { AcGePoint3d, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for an annotative MTEXT
 * (`ACDB_MTEXTOBJECTCONTEXTDATA_CLASS` / `AcDbMTextObjectContextData`).
 *
 * Text height is not stored here — derive it from the linked {@link scaleId}
 * and the entity's stored height for the default scale.
 */
export declare class AcDbMTextObjectContextData extends AcDbAnnotScaleObjectContextData {
    private _attachmentPoint;
    private _direction;
    private _insertionPoint;
    private _definedWidth;
    private _definedHeight;
    private _extentsWidth;
    private _extentsHeight;
    private _columnType;
    get attachmentPoint(): number;
    set attachmentPoint(value: number);
    get direction(): AcGeVector3d;
    set direction(value: AcGeVector3d);
    get insertionPoint(): AcGePoint3d;
    set insertionPoint(value: AcGePoint3d);
    get definedWidth(): number;
    set definedWidth(value: number);
    get definedHeight(): number;
    set definedHeight(value: number);
    get extentsWidth(): number;
    set extentsWidth(value: number);
    get extentsHeight(): number;
    set extentsHeight(value: number);
    get columnType(): number;
    set columnType(value: number);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbMTextObjectContextData.d.ts.map