import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative TEXT
 * (`ACDB_TEXTOBJECTCONTEXTDATA_CLASS` / `AcDbTextObjectContextData`).
 */
export declare class AcDbTextObjectContextData extends AcDbAnnotScaleObjectContextData {
    private _horizontalMode;
    private _rotation;
    private _alignmentPoint;
    private _position;
    get horizontalMode(): number;
    set horizontalMode(value: number);
    get rotation(): number;
    set rotation(value: number);
    get alignmentPoint(): AcGePoint3d;
    set alignmentPoint(value: AcGePoint3d);
    get position(): AcGePoint3d;
    set position(value: AcGePoint3d);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbTextObjectContextData.d.ts.map