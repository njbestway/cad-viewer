import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbObjectId } from '../base/AcDbObject.js';
import { AcDbObjectContextData } from './AcDbObjectContextData.js';
/**
 * Annotation-scale context data base
 * (`AcDbAnnotScaleObjectContextData` in AutoCAD ObjectARX).
 *
 * Links a per-scale representation to an {@link AcDbScale} via {@link scaleId}.
 */
export declare class AcDbAnnotScaleObjectContextData extends AcDbObjectContextData {
    private _scaleId;
    /** Soft-pointer to the {@link AcDbScale} object (DXF 340). */
    get scaleId(): AcDbObjectId;
    set scaleId(value: AcDbObjectId);
    dxfOutFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbAnnotScaleObjectContextData.d.ts.map