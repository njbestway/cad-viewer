import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
/**
 * Nongraphical `DICTIONARYVAR` object (`AcDbDictionaryVar`).
 *
 * Used for variables such as `CANNOSCALE` stored under
 * `AcDbVariableDictionary` in the named object dictionary.
 */
export declare class AcDbDictionaryVar extends AcDbObject {
    private _schema;
    private _value;
    /** Schema / type number (DXF group 280). */
    get schema(): number;
    set schema(value: number);
    /** Variable value (DXF group 1), e.g. `"1:100"` for CANNOSCALE. */
    get value(): string;
    set value(value: string);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbDictionaryVar.d.ts.map