import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
/**
 * Nongraphical SCALE object (`AcDbScale`) stored in `ACAD_SCALELIST`.
 *
 * The annotation scale factor used for annotative objects is
 * {@link drawingUnits} / {@link paperUnits}.
 */
export declare class AcDbScale extends AcDbObject {
    private _classVersion;
    private _scaleName;
    private _paperUnits;
    private _drawingUnits;
    /** DXF group 290 — unit scale / temporary flag as written by AutoCAD. */
    private _isUnitScale;
    get classVersion(): number;
    set classVersion(value: number);
    /** Human-readable scale name (DXF group 300), e.g. `"1:50"`. */
    get scaleName(): string;
    set scaleName(value: string);
    /** Paper units (DXF group 140). */
    get paperUnits(): number;
    set paperUnits(value: number);
    /** Drawing (model) units (DXF group 141). */
    get drawingUnits(): number;
    set drawingUnits(value: number);
    get isUnitScale(): boolean;
    set isUnitScale(value: boolean);
    /**
     * Scale factor that converts paper size to model size
     * (`drawingUnits / paperUnits`).
     */
    get scaleFactor(): number;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbScale.d.ts.map