import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative hatches
 * (`AcDbHatchScaleContextData`).
 */
export declare class AcDbHatchScaleContextData extends AcDbAnnotScaleObjectContextData {
    private _patternScale;
    get patternScale(): number;
    set patternScale(value: number);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbHatchScaleContextData.d.ts.map