import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
/**
 * Base class for per-context representation data
 * (`AcDbObjectContextData` in AutoCAD ObjectARX).
 */
export declare class AcDbObjectContextData extends AcDbObject {
    private _classVersion;
    private _isDefault;
    get classVersion(): number;
    set classVersion(value: number);
    /** True when this representation matches the entity record (DXF 290). */
    get isDefault(): boolean;
    set isDefault(value: boolean);
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Reads `AcDbObjectContextData` fields. Returns the next subclass marker
     * when present so subclasses can continue the section walk.
     */
    protected dxfInObjectContextData(filer: AcDbDxfFiler): string | undefined;
}
//# sourceMappingURL=AcDbObjectContextData.d.ts.map