import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative dimensions
 * (`ACDB_*DIMOBJECTCONTEXTDATA_CLASS` / `AcDbDimensionObjectContextData`).
 *
 * Critical fields for viewing:
 * - {@link blockName} — anonymous dim block for this scale (DXF 2)
 * - {@link definitionPoint} — OCS definition / insertion point (DXF 10)
 * - {@link dimLinePoint} — common subclass point (DXF 11), e.g. aligned dim line
 */
export declare class AcDbDimensionObjectContextData extends AcDbAnnotScaleObjectContextData {
    private _blockName;
    private _definitionPoint;
    private _dimLinePoint;
    private _hasDimLinePoint;
    private _b293;
    private _b294;
    private _bd140;
    private _b298;
    private _b291;
    private _flag;
    private _b292;
    private _bs71;
    private _b280;
    private _b295;
    private _b296;
    private _b297;
    /** Anonymous dimension block name for this scale (DXF 2), e.g. `*D94`. */
    get blockName(): string;
    set blockName(value: string);
    /** Definition / insertion point for this scale (DXF 10). */
    get definitionPoint(): AcGePoint3d;
    set definitionPoint(value: AcGePoint3d);
    /**
     * Dim-line / type-specific point commonly stored as DXF 11 after the
     * aligned/rotated/… subclass marker.
     */
    get dimLinePoint(): AcGePoint3d;
    set dimLinePoint(value: AcGePoint3d);
    get hasDimLinePoint(): boolean;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbDimensionObjectContextData.d.ts.map