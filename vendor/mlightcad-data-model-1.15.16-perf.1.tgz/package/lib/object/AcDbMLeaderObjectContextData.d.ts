import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbAnnotScaleObjectContextData } from './AcDbAnnotScaleObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative multileaders
 * (`ACDB_MLEADEROBJECTCONTEXTDATA_CLASS` / `AcDbMLeaderObjectContextData`).
 *
 * Stores the feature sizes and text anchor needed to redraw at CANNOSCALE.
 * Full leader vertex trees are still owned by the entity; when present this
 * context overrides scale-dependent sizes and the text landing point.
 */
export declare class AcDbMLeaderObjectContextData extends AcDbAnnotScaleObjectContextData {
    private _contentScale;
    private _textHeight;
    private _arrowheadSize;
    private _textAnchor;
    private _hasTextAnchor;
    /** Content / overall scale for this representation (DXF 40). */
    get contentScale(): number;
    set contentScale(value: number);
    /** Text height at this scale (DXF 41 / 44). */
    get textHeight(): number;
    set textHeight(value: number);
    /** Arrowhead size at this scale (DXF 140). */
    get arrowheadSize(): number;
    set arrowheadSize(value: number);
    /** MText landing / anchor point at this scale (DXF 12). */
    get textAnchor(): AcGePoint3d;
    set textAnchor(value: AcGePoint3d);
    get hasTextAnchor(): boolean;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbMLeaderObjectContextData.d.ts.map