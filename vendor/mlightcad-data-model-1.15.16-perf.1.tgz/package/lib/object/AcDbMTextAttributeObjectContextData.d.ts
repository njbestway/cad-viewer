import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbMTextObjectContextData } from './AcDbMTextObjectContextData.js';
/**
 * Per-annotation-scale representation for annotative MTEXT attributes
 * (`AcDbMTextAttributeObjectContextData`).
 *
 * Field layout matches MTEXT context data; used for attribute definitions /
 * references that use multiline text content.
 */
export declare class AcDbMTextAttributeObjectContextData extends AcDbMTextObjectContextData {
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbMTextAttributeObjectContextData.d.ts.map