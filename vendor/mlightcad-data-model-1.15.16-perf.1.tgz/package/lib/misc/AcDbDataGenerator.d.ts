import { AcDbDatabase } from '../database/AcDbDatabase.js';
export declare class AcDbDataGenerator {
    readonly db: AcDbDatabase;
    constructor(db: AcDbDatabase);
    createDefaultLayer(): void;
    createDefaultLineType(): void;
    createDefaultTextStyle(): void;
    createDefaultDimStyle(): void;
    createDefaultLayout(): void;
    createArrowBlock(): void;
    /**
     * Ensure a standard AutoCAD-style arrowhead block exists in the block table.
     * Arrow geometry is authored in unit size with tip at the origin pointing +X
     * when rotated 0; inserts typically rotate so the tip points along the
     * dimension line toward the outside.
     */
    ensureArrowBlock(blockName: string): void;
    private lineEntity;
}
//# sourceMappingURL=AcDbDataGenerator.d.ts.map