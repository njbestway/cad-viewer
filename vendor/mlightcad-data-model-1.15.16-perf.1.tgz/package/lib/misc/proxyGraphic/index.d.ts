/**
 * Proxy-entity graphics decoding utilities.
 *
 * This module exposes the binary stream readers, command-type enum, parser, and
 * DXF import/export helpers used by {@link AcDbProxyEntity}.
 */
export { AcDbProxyGraphic, AcDbProxyGraphicType, ACDB_PROXY_GRAPHIC_CHUNK_SIZE, acdbLoadProxyGraphicFromDxf } from './AcDbProxyGraphic.js';
export { AcDbProxyGraphicBitStream, AcDbProxyGraphicByteStream, AcDbProxyGraphicEndOfBufferError, acdbBytesToHexString, acdbCombineDxfBinaryChunks, acdbHexStringsToBytes } from './AcDbProxyGraphicBinaryStream.js';
//# sourceMappingURL=index.d.ts.map