import type { AcDbObject } from '../base/AcDbObject.js';
import type { AcDbDatabase } from '../database/AcDbDatabase.js';
import { AcDbAnnotScaleObjectContextData } from '../object/AcDbAnnotScaleObjectContextData.js';
import { AcDbScale } from '../object/AcDbScale.js';
/** Extension-dictionary key that stores a viewport's annotation scale. */
export declare const ACDB_VIEWPORT_ANNOTATION_SCALE_XREC = "ASDK_XREC_ANNOTATION_SCALE_INFO";
/** XDATA app name that marks an entity as annotative. */
export declare const ACDB_ANNOTATIVE_XDATA_APP = "AcadAnnotative";
/**
 * Runtime annotation-scale metadata attached to drawn annotative entities so
 * paper-space viewports can rescale or hide them for the active scale.
 */
export interface AcDbAnnotationScaleDrawInfo {
    /** Scale factor baked into the drawable geometry. */
    drawnScaleFactor: number;
    /** Scale name baked into the drawable (when known). */
    drawnScaleName?: string;
    /** Supported annotation scale factors (drawing/paper). */
    supportedScaleFactors: number[];
    /** Supported annotation scale names. */
    supportedScaleNames: string[];
}
/**
 * One per-scale representation resolved from an entity's context-data chain.
 */
export interface AcDbAnnotationScaleContext {
    scale: AcDbScale;
    contextData?: AcDbAnnotScaleObjectContextData;
    isDefault: boolean;
}
/**
 * Returns true when the object carries AcadAnnotative XDATA marking it
 * annotative (`AnnotativeData { 1 … }`).
 */
export declare function acdbIsAnnotativeObject(object: AcDbObject): boolean;
/**
 * True when the object is annotative via XDATA or has annotation-scale
 * context data in its extension dictionary.
 */
export declare function acdbGetAnnotative(object: AcDbObject): boolean;
/**
 * Sets or clears the annotative flag on `object`.
 *
 * When `value` is `false`, clears AcadAnnotative XDATA **and** removes all
 * annotation-scale context entries so {@link acdbGetAnnotative} / entity
 * `annotative` getters agree with the setter.
 */
export declare function acdbSetAnnotative(object: AcDbObject, value: boolean): void;
/**
 * Resolves a SCALE object by handle or by scale name from ACAD_SCALELIST.
 */
export declare function acdbFindScale(db: AcDbDatabase, handleOrName?: string): AcDbScale | undefined;
/**
 * Walks an entity's extension dictionary → AcDbContextDataManager →
 * ACDB_ANNOTATIONSCALES and returns linked scale contexts.
 */
export declare function acdbGetAnnotationScaleContexts(object: AcDbObject): AcDbAnnotationScaleContext[];
/**
 * Paper height implied by the entity's stored model height and its default
 * (or first) annotation scale context.
 */
export declare function acdbAnnotativePaperHeight(modelHeight: number, contexts: readonly AcDbAnnotationScaleContext[]): number;
/**
 * Model-space height for an annotative object at the given scale factor,
 * derived from its paper height.
 */
export declare function acdbAnnotativeModelHeight(paperHeight: number, scaleFactor: number): number;
/**
 * Picks the context matching `scaleName` or `scaleFactor`, falling back to
 * the default context when unmatched.
 */
export declare function acdbMatchAnnotationScaleContext(contexts: readonly AcDbAnnotationScaleContext[], scaleName?: string, scaleFactor?: number): AcDbAnnotationScaleContext | undefined;
/**
 * Reads the viewport annotation scale from
 * `ASDK_XREC_ANNOTATION_SCALE_INFO` in the viewport extension dictionary.
 */
export declare function acdbGetViewportAnnotationScale(viewport: AcDbObject): AcDbScale | undefined;
/**
 * Builds draw-time metadata for an annotative entity.
 */
export declare function acdbBuildAnnotationScaleDrawInfo(contexts: readonly AcDbAnnotationScaleContext[], drawn: AcDbAnnotationScaleContext): AcDbAnnotationScaleDrawInfo;
/**
 * Returns SCALE objects currently present in `ACAD_SCALELIST` (read-only).
 * Does not seed defaults — use {@link acdbEnsureDefaultAnnotationScales} when
 * the UI needs a non-empty OBJECTSCALE list.
 */
export declare function acdbListAnnotationScales(db: AcDbDatabase): AcDbScale[];
/**
 * Ensures the drawing scale list contains the common default annotation
 * scales (`1:1` … `1:1000`). Returns the full scale list afterwards.
 */
export declare function acdbEnsureDefaultAnnotationScales(db: AcDbDatabase): AcDbScale[];
/**
 * Ensures a named {@link AcDbScale} exists in the drawing scale list.
 */
export declare function acdbEnsureNamedScale(db: AcDbDatabase, scaleName: string, drawingUnits?: number): AcDbScale;
/**
 * Adds a supported annotation scale to `object` (OBJECTSCALE Add).
 * Creates a typed per-entity context (when known), seeded from the default
 * context or the entity's current representation.
 */
export declare function acdbAddAnnotationScaleToObject(object: AcDbObject, scaleName: string): boolean;
/**
 * Removes a supported annotation scale from `object` (OBJECTSCALE Delete).
 * Also drops the context from `objects.objectContextData` and promotes a new
 * default when the removed scale was the default.
 */
export declare function acdbRemoveAnnotationScaleFromObject(object: AcDbObject, scaleName: string): boolean;
/**
 * Resolves annotation draw metadata for an annotative object at the database
 * CANNOSCALE (or the default context when unmatched).
 */
export declare function acdbResolveAnnotationScaleDrawInfo(object: AcDbObject): {
    contexts: AcDbAnnotationScaleContext[];
    preferred?: AcDbAnnotationScaleContext;
    annotationScale?: AcDbAnnotationScaleDrawInfo;
};
//# sourceMappingURL=AcDbAnnotationScale.d.ts.map