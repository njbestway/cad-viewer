import { AcDbEntity } from './AcDbEntity.js';
/**
 * Abstract base class for OLE container entities.
 *
 * {@link AcDbFrame} is the ObjectARX base class for {@link AcDbOleFrame} and
 * {@link AcDbOle2Frame}. Applications typically use {@link AcDbOle2Frame}
 * rather than this class directly.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbFrame
 */
export declare abstract class AcDbFrame extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
}
//# sourceMappingURL=AcDbFrame.d.ts.map