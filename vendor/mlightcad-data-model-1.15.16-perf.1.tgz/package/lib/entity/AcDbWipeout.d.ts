import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbRasterImage } from './AcDbRasterImage.js';
/**
 * Entity that creates a blank area in the drawing.
 *
 * The AcDbWipeout entity creates a blank area that covers other entities
 * in the drawing. It's commonly used to hide parts of the drawing or
 * create clean areas for annotations. The wipeout area is defined by
 * a boundary path and is rendered as a solid fill in the current
 * canvas / layout background colour (matching AutoCAD).
 *
 * @example
 * ```typescript
 * const wipeout = new AcDbWipeout();
 * // Set up boundary path and other properties
 * wipeout.draw(renderer);
 * ```
 */
export declare class AcDbWipeout extends AcDbRasterImage {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /**
     * Draws the wipeout entity.
     *
     * This method creates a solid background-coloured area based on the
     * boundary path of the wipeout entity. The area covers all entities
     * behind it (by draw order), effectively "wiping out" that portion of
     * the drawing.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered entity or undefined if rendering fails
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbWipeout.d.ts.map