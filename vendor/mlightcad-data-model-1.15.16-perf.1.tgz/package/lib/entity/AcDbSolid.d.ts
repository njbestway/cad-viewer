import { AcDbTrace } from './AcDbTrace.js';
/**
 * Represents a solid entity in AutoCAD.
 *
 * A solid is a filled four-sided (or triangular) polygon. Dimension arrowheads
 * are typically authored as `SOLID` entities inside anonymous dimension blocks.
 * Geometry and DXF subclass data are shared with {@link AcDbTrace}
 * (`AcDbTrace`); only the DXF entity type name differs (`SOLID` vs `TRACE`).
 */
export declare class AcDbSolid extends AcDbTrace {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
}
//# sourceMappingURL=AcDbSolid.d.ts.map