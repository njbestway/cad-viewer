import { AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/index.js';
import { AcDbEntityProperties } from '../AcDbEntityProperties.js';
import { AcDbDimension } from './AcDbDimension.js';
/**
 * Represents an arc length dimension entity in AutoCAD.
 *
 * This dimension type measures the length of an arc by defining the arc's center point,
 * two points that define the arc's extent, and a point on the arc itself. Arc length
 * dimensions are commonly used in mechanical drawings, architectural plans, and other
 * technical documentation where precise arc measurements are required.
 *
 * The dimension displays the actual arc length value and typically includes extension
 * lines, dimension lines, and arrows positioned to clearly indicate the arc being measured.
 */
export declare class AcDbArcDimension extends AcDbDimension {
    /** The entity type name */
    static typeName: string;
    private _arcPoint;
    private _centerPoint;
    private _xLine1Point;
    private _xLine2Point;
    /**
     * Creates a new arc length dimension.
     *
     * @param centerPoint - The center point of the arc being measured. This defines
     *                      the center of the circle that contains the arc
     * @param xLine1Point - The first extension line end point. This defines one end
     *                      of the arc being measured
     * @param xLine2Point - The second extension line end point. This defines the other
     *                      end of the arc being measured
     * @param arcPoint - A point on the arc that helps define the specific arc segment
     *                   being measured. This point is typically between the two extension
     *                   line points
     * @param dimText - Optional custom dimension text to display instead of the calculated
     *                  arc length value. If null, the calculated length will be displayed
     * @param dimStyle - Optional name of the dimension style table record to use for
     *                   formatting. If null, the current default style will be used
     */
    constructor(centerPoint: AcGePoint3dLike, xLine1Point: AcGePoint3dLike, xLine2Point: AcGePoint3dLike, arcPoint: AcGePoint3dLike, dimText?: string | null, dimStyle?: string | null);
    /**
     * Gets or sets a point on the arc that helps define the arc segment being measured.
     *
     * This point is typically positioned between the two extension line points and helps
     * determine which arc segment should be measured when multiple arcs could be defined
     * by the same center and end points.
     *
     * @returns The arc point that defines the arc segment
     */
    get arcPoint(): AcGePoint3d;
    set arcPoint(value: AcGePoint3d);
    /**
     * Gets or sets the center point of the arc being measured.
     *
     * The center point defines the center of the circle that contains the arc. This point
     * is used to calculate the arc length and position the dimension elements correctly.
     *
     * @returns The center point of the arc
     */
    get centerPoint(): AcGePoint3d;
    set centerPoint(value: AcGePoint3d);
    /**
     * Gets or sets the first extension line end point.
     *
     * This point defines one end of the arc being measured. The extension line extends
     * from this point to the arc, helping to clearly identify the starting point of
     * the arc length measurement.
     *
     * @returns The first extension line end point
     */
    get xLine1Point(): AcGePoint3d;
    set xLine1Point(value: AcGePoint3d);
    /**
     * Gets or sets the second extension line end point.
     *
     * This point defines the other end of the arc being measured. The extension line
     * extends from this point to the arc, helping to clearly identify the ending point
     * of the arc length measurement.
     *
     * @returns The second extension line end point
     */
    get xLine2Point(): AcGePoint3d;
    set xLine2Point(value: AcGePoint3d);
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     */
    protected collectDimensionDefinitionGripPoints(): AcGePoint3d[];
    /**
     * @inheritdoc
     */
    protected subTransformBy(matrix: AcGeMatrix3d): void;
    /**
     * Gets the geometric extents (bounding box) of this dimension entity.
     *
     * The geometric extents define the minimum bounding box that completely contains
     * the dimension entity, including all its components like extension lines,
     * dimension lines, arrows, and text.
     *
     * @returns A 3D bounding box containing the dimension entity
     * @inheritdoc
     */
    get geometricExtents(): import("@mlightcad/geometry-engine").AcGeBox3d;
    /**
     * Arc length of the feature arc (feature radius × sweep), not the offset
     * dimension-arc radius.
     */
    protected getMeasurementPropertyValue(): number;
    createDimBlock(blockName: string): import("../../index.js").AcDbBlockTableRecord;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbArcDimension.d.ts.map