import { AcGeMatrix3d, AcGePoint3d, AcGePointLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/index.js';
import { AcDbEntityProperties } from '../AcDbEntityProperties.js';
import { AcDbDimension } from './AcDbDimension.js';
/**
 * Represents a three-point angular dimension entity in AutoCAD.
 *
 * This dimension type measures the angle between two lines or edges by defining three points:
 * a center point and two points that define the lines or edges being measured. The dimension
 * displays the angle value and typically includes extension lines, dimension lines, and arrows.
 *
 * Three-point angular dimensions are commonly used to measure angles between non-parallel lines,
 * angles of arcs, or any angular measurement that requires three reference points.
 */
export declare class AcDb3PointAngularDimension extends AcDbDimension {
    /** The entity type name */
    static typeName: string;
    private _arcPoint;
    private _centerPoint;
    private _xLine1Point;
    private _xLine2Point;
    /**
     * Creates a new three-point angular dimension.
     *
     * @param centerPoint - The center point of the angle being measured. This is typically
     *                      the vertex where the two lines or edges meet
     * @param xLine1Point - The first extension line end point. This defines one of the
     *                      lines or edges being measured
     * @param xLine2Point - The second extension line end point. This defines the other
     *                      line or edge being measured
     * @param arcPoint - A point on the arc that represents the angle being measured.
     *                   This point helps determine the direction and extent of the angle
     * @param dimText - Optional custom dimension text to display instead of the calculated
     *                  angle value. If null, the calculated angle will be displayed
     * @param dimStyle - Optional name of the dimension style table record to use for
     *                   formatting. If null, the current default style will be used
     */
    constructor(centerPoint: AcGePointLike, xLine1Point: AcGePointLike, xLine2Point: AcGePointLike, arcPoint: AcGePointLike, dimText?: string | null, dimStyle?: string | null);
    /**
     * Gets or sets a point on the arc that represents the angle being measured.
     *
     * This point is used to determine the direction and extent of the angle measurement.
     * It helps define which side of the angle should be measured and how the dimension
     * arc should be drawn.
     *
     * @returns The arc point that defines the angle measurement
     */
    get arcPoint(): AcGePoint3d;
    set arcPoint(value: AcGePoint3d);
    /**
     * Gets or sets the center point of the angle being measured.
     *
     * The center point is the vertex where the two lines or edges meet. This point
     * serves as the reference for measuring the angle between the two extension lines.
     *
     * @returns The center point of the angle
     */
    get centerPoint(): AcGePoint3d;
    set centerPoint(value: AcGePoint3d);
    /**
     * Gets or sets the first extension line end point.
     *
     * This point defines one of the lines or edges being measured. The extension line
     * extends from this point to the center point, helping to clearly identify the
     * first reference line for the angle measurement.
     *
     * @returns The first extension line end point
     */
    get xLine1Point(): AcGePoint3d;
    set xLine1Point(value: AcGePoint3d);
    /**
     * Gets or sets the second extension line end point.
     *
     * This point defines the other line or edge being measured. The extension line
     * extends from this point to the center point, helping to clearly identify the
     * second reference line for the angle measurement.
     *
     * @returns The second extension line end point
     */
    get xLine2Point(): AcGePoint3d;
    set xLine2Point(value: AcGePoint3d);
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     */
    protected collectDimensionDefinitionGripPoints(): AcGePoint3d[];
    /**
     * @inheritdoc
     */
    protected subTransformBy(matrix: AcGeMatrix3d): void;
    /**
     * Gets the geometric extents (bounding box) of this dimension entity.
     *
     * The geometric extents define the minimum bounding box that completely contains
     * the dimension entity, including all its components like extension lines,
     * dimension lines, arrows, and text.
     *
     * @returns A 3D bounding box containing the dimension entity
     * @inheritdoc
     */
    get geometricExtents(): import("@mlightcad/geometry-engine").AcGeBox3d;
    protected getMeasurementPropertyValue(): number;
    createDimBlock(blockName: string): import("../../index.js").AcDbBlockTableRecord;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDb3PointAngularDimension.d.ts.map