import { AcGeLine3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcGiMTextAttachmentPoint } from '@mlightcad/graphic-interface';
import type { AcDbObject } from '../../base/AcDbObject.js';
import { AcDbBlockTableRecord } from '../../database/AcDbBlockTableRecord.js';
import { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbDimStyleTableRecord } from '../../database/AcDbDimStyleTableRecord.js';
import { AcDbArc } from '../AcDbArc.js';
import { AcDbBlockReference } from '../AcDbBlockReference.js';
import { AcDbLine } from '../AcDbLine.js';
import { AcDbMText } from '../AcDbMText.js';
import { acdbDimFeatureScale } from './AcDbDimFeatureScale.js';
export { acdbDimFeatureScale };
/** Closed filled uses empty dimblk in AutoCAD; we store geometry under this BTR name. */
export declare const CLOSED_FILLED_ARROW_BLOCK = "_CLOSEDFILLED";
export declare function acdbResolveArrowBlockName(dimblk: string | undefined | null): string;
export declare function acdbEnsureDimArrowBlocks(db: AcDbDatabase, style: AcDbDimStyleTableRecord): void;
export declare function acdbCreateDimLineEntity(start: AcGePoint3dLike, end: AcGePoint3dLike, style: AcDbDimStyleTableRecord, kind?: 'dimension' | 'extension'): AcDbLine;
export declare function acdbCreateDimArrowInsert(pos: AcGePoint3dLike, rotation: number, scale: number, blockName: string): AcDbBlockReference | null;
export declare function acdbArrowScaleFromStyle(style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
export declare function acdbTextHeightFromStyle(style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
export declare function acdbCreateDimMText(options: {
    contents: string;
    position: AcGePoint3dLike;
    rotation: number;
    style: AcDbDimStyleTableRecord;
    attachmentPoint?: AcGiMTextAttachmentPoint;
    entity?: AcDbObject;
}): AcDbMText | null;
/**
 * Offset text position along the normal of the dimension line based on dimtad/dimgap.
 */
export declare function acdbOffsetTextAlongNormal(mid: AcGePoint3dLike, rotation: number, style: AcDbDimStyleTableRecord, entity?: AcDbObject): AcGePoint3d;
export declare function acdbAppendCenterMark(block: AcDbBlockTableRecord, center: AcGePoint3dLike, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
export declare function acdbCreateEmptyDimBlock(blockName: string): AcDbBlockTableRecord;
export declare function acdbBuildAnnotationText(measured: number, dimensionText: string | null | undefined, style: AcDbDimStyleTableRecord, kind: 'linear' | 'angular' | 'radial' | 'diametric'): string;
/**
 * Create a dimension-line arc for angular dimensions.
 */
export declare function acdbCreateDimArcEntity(center: AcGePoint3dLike, radius: number, startAngle: number, endAngle: number, style: AcDbDimStyleTableRecord): AcDbArc;
export declare function acdbUnitVectorFromAngle(angle: number): AcGeVector3d;
export declare function acdbAngleOfPoints(from: AcGePoint3dLike, to: AcGePoint3dLike): number;
/**
 * Resolve the CCW angular sweep from ray1→ray2 that contains `arcPoint`.
 * When the arc point lies on the complementary (major) arc, the start/end
 * rays are swapped so measurement matches drawn geometry.
 */
export declare function acdbResolveAngularSweep(options: {
    center: AcGePoint3dLike;
    xLine1: AcGePoint3dLike;
    xLine2: AcGePoint3dLike;
    arcPoint: AcGePoint3dLike;
}): {
    start: number;
    end: number;
    sweep: number;
};
export declare function acdbPointAt(origin: AcGePoint3dLike, angle: number, distance: number): AcGePoint3d;
export declare function acdbMidPoint(a: AcGePoint3dLike, b: AcGePoint3dLike): AcGePoint3d;
export declare function acdbExtendLineByDimDle(line: AcGeLine3d, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
//# sourceMappingURL=AcDbDimBlockBuilder.d.ts.map