import type { AcDbObject } from '../../base/AcDbObject.js';
import { AcDbDimStyleTableRecord } from '../../database/AcDbDimStyleTableRecord.js';
/**
 * Scale applied to dimension text, arrows, gaps, and extension offsets.
 *
 * Prefer the entity's matched annotation-scale context (CANNOSCALE) when the
 * dimension is annotative. Otherwise use the per-dimstyle annotative factor
 * from the database, then DIMSCALE (0 falls back to 1).
 */
export declare function acdbDimFeatureScale(style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
//# sourceMappingURL=AcDbDimFeatureScale.d.ts.map