import { AcDbDimStyleTableRecord } from '../../database/AcDbDimStyleTableRecord.js';
/**
 * Format a linear measurement using DIMSTYLE primary-unit settings.
 */
export declare function acdbFormatLinearMeasurement(raw: number, style: AcDbDimStyleTableRecord): string;
/**
 * Format an angular measurement (radians) using DIMSTYLE angular settings.
 * dimaunit: 0 decimal degrees, 1 deg/min/sec, 2 gradians, 3 radians
 */
export declare function acdbFormatAngularMeasurement(radians: number, style: AcDbDimStyleTableRecord): string;
/**
 * Resolve the final dimension annotation string, including <> placeholder,
 * alternate units, and tolerances when enabled.
 */
export declare function acdbResolveDimensionAnnotation(measuredRaw: number, dimensionText: string | null | undefined, style: AcDbDimStyleTableRecord, kind?: 'linear' | 'angular' | 'radial' | 'diametric'): string;
//# sourceMappingURL=AcDbDimMeasurementFormat.d.ts.map