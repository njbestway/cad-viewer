import { AcDbDatabase } from './AcDbDatabase.js';
import { AcDbSymbolTable } from './AcDbSymbolTable.js';
import { AcDbUcsTableRecord } from './AcDbUcsTableRecord.js';
/**
 * Symbol table for named User Coordinate Systems (DXF UCS table).
 */
export declare class AcDbUcsTable extends AcDbSymbolTable<AcDbUcsTableRecord> {
    /**
     * Creates a new AcDbUcsTable instance.
     *
     * @param db - The database this UCS table belongs to
     */
    constructor(db: AcDbDatabase);
}
//# sourceMappingURL=AcDbUcsTable.d.ts.map