import { AcDbObject } from '../../base/index.js';
import { AcDbDatabase } from '../AcDbDatabase.js';
import { AcDbChangeContainer, AcDbDatabaseChange } from './AcDbDatabaseChange.js';
/**
 * Accumulates structured database changes during an active transaction.
 *
 * Append/remove pairs that cancel within the same transaction are coalesced,
 * and duplicate modify/sysvar entries for the same target are ignored.
 *
 * `changes` stays the single source of truth for ordering and is what
 * {@link getChanges} hands to the transaction manager, the event dispatcher and
 * the undo record. Alongside it the recorder keeps three indexes so that a
 * bulk edit never rescans the change log:
 *
 * - `modifyById` - `objectId -> modify entry` (first write wins);
 * - `sysvarByName` - `normalized name -> sysvar entry` (first write wins);
 * - `structuralByKey` - `kind/container/objectId -> live append or remove`
 *   entries, in insertion order.
 *
 * Index updates are O(1). Cancelling an append/remove pair tombstones the
 * earlier entry and drops the new one, exactly like the previous
 * `splice(index, 1)`, but without shifting the array or invalidating the other
 * indexes; {@link compact} removes the tombstones in one linear pass the next
 * time the change log is read. A transaction that records N changes therefore
 * costs O(N) instead of O(N^2).
 */
export declare class AcDbChangeRecorder {
    private readonly changes;
    /** First `modify` entry recorded per object id. */
    private readonly modifyById;
    /** First `sysvar` entry recorded per normalized name. */
    private readonly sysvarByName;
    /**
     * Live append/remove entries per `kind/container/objectId`.
     *
     * A container can legitimately see the same object appended twice (for
     * example a re-append after a failed insert), and the previous linear scan
     * cancelled the *earliest* match, so the queue is kept in insertion order.
     */
    private readonly structuralByKey;
    /**
     * Structural entries that were cancelled by their opposite change.
     *
     * They are still referenced by `changes` until {@link compact} runs, which is
     * why they carry a membership test instead of being removed immediately.
     */
    private readonly cancelledStructurals;
    /**
     * Returns the changes recorded so far in this transaction.
     *
     * The returned array is the internal store; callers should treat it as read-only.
     */
    getChanges(): AcDbDatabaseChange[];
    /**
     * Discards all recorded changes without applying them.
     */
    clear(): void;
    /**
     * Merges changes from a nested transaction into this recorder.
     *
     * Used when an inner transaction commits into its parent without touching
     * the undo stack.
     *
     * @param other - Recorder from a child transaction being committed
     */
    mergeFrom(other: AcDbChangeRecorder): void;
    /**
     * Records the pre-modification snapshot of an opened-for-write object.
     *
     * Only the first modify entry per {@link AcDbObject.objectId} is kept.
     *
     * @param object - Object whose state should be restorable on abort/undo
     */
    recordModify(object: AcDbObject): void;
    /**
     * Returns true when a modify entry exists for the given object ID.
     *
     * Used by {@link AcDbDatabaseTransactionManager.isOpenedForWriteInTransaction}
     * to determine whether a symbol table record was opened for write within the
     * active transaction stack.
     *
     * @param objectId - Object identifier to look up
     */
    hasModify(objectId: string): boolean;
    /**
     * Records insertion of an object into a database container.
     *
     * If a matching remove was recorded earlier in the same transaction,
     * the pair cancels and neither change is retained.
     *
     * @param container - Container that received the object
     * @param object - Object that was appended; stored as an identity-preserving clone
     */
    recordAppend(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records removal of an object from a database container.
     *
     * If a matching append was recorded earlier in the same transaction,
     * the pair cancels and neither change is retained.
     *
     * @param container - Container that owned the removed object
     * @param object - Object that was removed; stored as an identity-preserving clone
     */
    recordRemove(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records the value of a system variable before mutation.
     *
     * Only the first sysvar entry per normalized name is kept.
     *
     * @param name - System variable name (case-insensitive)
     * @param before - Value observed before the mutation
     */
    recordSysvar(name: string, before: unknown): void;
    /**
     * Captures the post-change state for modify and sysvar entries at commit time.
     *
     * Append/remove entries are complete when recorded and do not require
     * finalization.
     *
     * @param database - Database used to read live post-commit values
     */
    finalize(database: AcDbDatabase): void;
    /**
     * Checks that every index agrees with the ordered change log.
     *
     * Intended for tests and for diagnosing a suspicious undo record: it walks
     * the whole log, so it is O(N) and must not be called on a hot path.
     *
     * @returns Human-readable problems; an empty array means the recorder is consistent
     */
    validateIndexes(): string[];
    /**
     * Records or coalesces one append/remove change.
     *
     * When an opposite structural change for the same container and object ID
     * already exists in this transaction, both entries cancel and neither is kept.
     *
     * @param change - Append or remove entry to merge into the recorder
     */
    private recordStructuralChange;
    /**
     * Merges one change from a nested transaction into this recorder.
     *
     * Modify and sysvar entries deduplicate by object ID or variable name;
     * structural entries use the same cancel/coalesce rules as {@link recordAppend}.
     *
     * @param change - Change copied from a child transaction recorder
     */
    private mergeChange;
    /**
     * Removes tombstoned structural entries from the ordered log.
     *
     * Runs in one pass, in place, so any array reference previously returned by
     * {@link getChanges} keeps observing the same live change set. No-op when
     * nothing was cancelled, which is the common case.
     */
    private compact;
    /**
     * Reads the current value of a system variable from the database.
     *
     * @param database - Database passed to {@link AcDbSysVarManager.getVar}
     * @param name - Normalized system variable name
     * @returns Live variable value used to populate `after` during {@link finalize}
     */
    private getSysvarValue;
}
//# sourceMappingURL=AcDbChangeRecorder.d.ts.map