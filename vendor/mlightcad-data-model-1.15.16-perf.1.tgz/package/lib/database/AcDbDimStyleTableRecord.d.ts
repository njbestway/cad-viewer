import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbSymbolTableRecord, AcDbSymbolTableRecordAttrs } from './AcDbSymbolTableRecord.js';
/**
 * Controls the horizontal positioning of dimension text relative to the dimension line.
 * This setting affects how dimension text is aligned when it's placed outside the extension lines.
 */
export declare enum AcDbDimTextHorizontal {
    /** Centers the text between the extension lines */
    Center = 0,
    /** Positions text next to the first extension line */
    Left = 1,
    /** Positions text next to the second extension line */
    Right = 2,
    /** Positions text above and aligned with the first extension line */
    OverFirst = 3,
    /** Positions text above and aligned with the second extension line */
    OverSecond = 4
}
/**
 * Controls the vertical positioning of dimension text relative to the dimension line.
 * This setting determines whether text appears above, below, or centered on the dimension line.
 */
export declare enum AcDbDimTextVertical {
    /** Centers text between the extension lines */
    Center = 0,
    /** Places text above the dimension line */
    Above = 1,
    /** Places text on the side farthest from the defining points */
    Outside = 2,
    /** Places text according to Japanese Industrial Standards (JIS) */
    JIS = 3,
    /** Places text below the dimension line */
    Below = 4
}
/**
 * Controls the suppression of zeros in primary unit values for linear dimensions.
 * This setting affects how feet, inches, and decimal values are displayed.
 */
export declare enum AcDbDimZeroSuppression {
    /** Suppresses zero feet and precisely zero inches */
    Feet = 0,
    /** Includes zero feet and precisely zero inches */
    None = 1,
    /** Includes zero feet and suppresses zero inches */
    Inch = 2,
    /** Includes zero inches and suppresses zero feet */
    FeetAndInch = 3,
    /** Suppresses leading zeros in decimal dimensions */
    Leading = 4,
    /** Suppresses trailing zeros in decimal dimensions */
    Trailing = 8,
    /** Suppresses both leading and trailing zeros */
    LeadingAndTrailing = 12
}
/**
 * Controls the suppression of zeros in angular dimension values.
 * This setting affects how angular dimensions are displayed.
 */
export declare enum AcDbDimZeroSuppressionAngular {
    /** Displays all leading and trailing zeros */
    None = 0,
    /** Suppresses leading zeros in decimal dimensions */
    Leading = 1,
    /** Suppresses trailing zeros in decimal dimensions */
    Trailing = 2,
    /** Suppresses both leading and trailing zeros */
    LeadingAndTrailing = 3
}
/**
 * Controls the vertical justification of tolerance values relative to the nominal dimension text.
 * This setting only affects dimensions when tolerance is enabled.
 */
export declare enum AcDbDimVerticalJustification {
    /** Aligns tolerance text at the bottom */
    Bottom = 0,
    /** Centers tolerance text vertically */
    Middle = 1,
    /** Aligns tolerance text at the top */
    Top = 2
}
/**
 * Interface defining the attributes for a dimension style table record.
 * Contains all the properties that control the appearance and behavior of dimensions
 * that reference this style.
 */
export interface AcDbDimStyleTableRecordAttrs extends AcDbSymbolTableRecordAttrs {
    /** Dimension postfix for text prefix/suffix */
    dimpost: string;
    /** Dimension append postfix for alternate units */
    dimapost: string;
    /** Overall scale factor for dimensions */
    dimscale: number;
    /** Arrow size for dimension lines */
    dimasz: number;
    /** Extension line offset from origin */
    dimexo: number;
    /** Dimension line increment for baseline dimensions */
    dimdli: number;
    /** Extension line extension beyond dimension line */
    dimexe: number;
    /** Rounding value for dimension distances */
    dimrnd: number;
    /** Dimension line extension beyond extension lines */
    dimdle: number;
    /** Plus tolerance value */
    dimtp: number;
    /** Minus tolerance value */
    dimtm: number;
    /** Text height for dimensions */
    dimtxt: number;
    /** Center mark size for circles/arcs */
    dimcen: number;
    /** Tick size (replaces arrows when > 0) */
    dimtsz: number;
    /** Alternate unit scale factor */
    dimaltf: number;
    /** Linear dimension scale factor */
    dimlfac: number;
    /** Text vertical position offset */
    dimtvp: number;
    /** Text height scale factor */
    dimtfac: number;
    /** Gap between dimension line and text */
    dimgap: number;
    /** Text background fill: 0 = off, 1 = drawing background color, 2 = custom color */
    dimtfill: 0 | 1 | 2;
    /** Custom fill color for dimension text background (ACI or packed true color) */
    dimtfillclr: number;
    /** Alternate unit rounding */
    dimaltrnd: number;
    /** Enable/disable tolerance display */
    dimtol: 0 | 1;
    /** Enable/disable dimension limits */
    dimlim: 0 | 1;
    /** Text horizontal alignment inside extension lines */
    dimtih: 0 | 1;
    /** Text horizontal alignment outside extension lines */
    dimtoh: 0 | 1;
    /** Dimension text viewing direction: 0 = left to right, 1 = right to left */
    dimtxtdirection: 0 | 1;
    /** Suppress first extension line */
    dimse1: 0 | 1;
    /** Suppress second extension line */
    dimse2: 0 | 1;
    /** Text vertical position relative to dimension line */
    dimtad: AcDbDimTextVertical;
    /** Zero suppression for primary units */
    dimzin: AcDbDimZeroSuppression;
    /** Zero suppression for angular dimensions */
    dimazin: AcDbDimZeroSuppressionAngular;
    /** Enable/disable alternate units */
    dimalt: 0 | 1;
    /** Decimal places for alternate units */
    dimaltd: number;
    /** Force dimension line between extension lines */
    dimtofl: 0 | 1;
    /** Use separate arrow blocks for each end */
    dimsah: 0 | 1;
    /** Force text inside extension lines */
    dimtix: 0 | 1;
    /** Suppress arrows when text doesn't fit */
    dimsoxd: 0 | 1;
    /** Dimension line color */
    dimclrd: number;
    /** Extension line color */
    dimclre: number;
    /** Dimension text color */
    dimclrt: number;
    /** Angular dimension decimal places */
    dimadec: number;
    /** Linear dimension units format */
    dimunit: number;
    /** Primary unit decimal places */
    dimdec: number;
    /** Tolerance decimal places */
    dimtdec: number;
    /** Alternate unit format */
    dimaltu: number;
    /** Alternate tolerance decimal places */
    dimalttd: number;
    /** Angular dimension units */
    dimaunit: number;
    /** Fraction format for architectural units */
    dimfrac: number;
    /** Linear dimension units */
    dimlunit: number;
    /** Decimal separator character */
    dimdsep: string;
    /** Text movement rules */
    dimtmove: number;
    /** Text horizontal justification */
    dimjust: AcDbDimTextHorizontal;
    /** Suppress first dimension line */
    dimsd1: 0 | 1;
    /** Suppress second dimension line */
    dimsd2: 0 | 1;
    /** Tolerance text vertical justification */
    dimtolj: AcDbDimVerticalJustification;
    /** Tolerance zero suppression */
    dimtzin: AcDbDimZeroSuppression;
    /** Alternate unit zero suppression */
    dimaltz: AcDbDimZeroSuppression;
    /** Alternate tolerance zero suppression */
    dimalttz: AcDbDimZeroSuppression;
    /** Text fitting behavior */
    dimfit: number;
    /** User positioning control */
    dimupt: number;
    /** Angular dimension text/arrow fitting */
    dimatfit: number;
    /** Text style name */
    dimtxsty: string;
    /** Leader arrow block name */
    dimldrblk: string;
    /** Arrow block name */
    dimblk: string;
    /** First arrow block name (when using separate arrows) */
    dimblk1: string;
    /** Second arrow block name (when using separate arrows) */
    dimblk2: string;
    /** Dimension line weight */
    dimlwd: number;
    /** Extension line weight */
    dimlwe: number;
}
/**
 * Objects of this class represent the records found in the dimension style table. Each of these
 * records contains the information necessary to generate a specific appearance (that is, text
 * above, in, or below the line; arrows, slashes, or dots at the end of the dimension line, and
 * so on) for dimensions that reference it.
 */
export declare class AcDbDimStyleTableRecord extends AcDbSymbolTableRecord<AcDbDimStyleTableRecordAttrs> {
    static DEFAULT_DIM_VALUES: AcDbDimStyleTableRecordAttrs;
    constructor(attrs?: Partial<AcDbDimStyleTableRecordAttrs>, defaultAttrs?: Partial<AcDbDimStyleTableRecordAttrs>);
    /**
     * Dimension postfix. This property specifies a text prefix or suffix (or both) to the dimension
     * measurement.
     * For example, to establish a suffix for millimeters, set DIMPOST to mm; a distance of 19.2 units
     * would be displayed as 19.2 mm.
     * If tolerances are turned on, the suffix is applied to the tolerances as well as to the main
     * dimension. Use <> to indicate placement of the text in relation to the dimension value. For
     * example, enter <>mm to display a 5.0 millimeter radial dimension as "5.0mm". If you entered
     * mm <>, the dimension would be displayed as "mm 5.0". Use the <> mechanism for angular
     * dimensions.
     */
    get dimpost(): string;
    set dimpost(value: string);
    /**
     * Dimension append postfix. This property specifies a text prefix or suffix (or both) to the
     * alternate dimension measurement for all types of dimensions except angular.
     * For instance, if the current units are Architectural, DIMALT is on, DIMALTF is 25.4 (the
     * number of millimeters per inch), DIMALTD is 2, and DIMAPOST is set to "mm", a distance of 10
     * units would be displayed as 10"[254.00mm].
     * To turn off an established prefix or suffix (or both), set it to a single period (.).
     */
    get dimapost(): string;
    set dimapost(value: string);
    /**
     * Dimension scale. This property controls the scale factor for dimensioning objects. If you need
     * to adjust the scale of your dimensions, you can change this value to better fit your drawing's
     * scale.
     */
    get dimscale(): number;
    set dimscale(value: number);
    /**
     * Whether this dimension style is annotative (AcadAnnotative XDATA).
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    /**
     * Dimension arrow size. This property controls the size of the arrowheads used in dimensions. You
     * can modify this value to adjust the size of arrowheads based on your drawing's requirements.
     */
    get dimasz(): number;
    set dimasz(value: number);
    /**
     * Dimension extension line offset. This property controls the offset distance from the origin point
     * to where the extension line starts. You can adjust it to control how far the extension line is set
     * back from the object being dimensioned.
     */
    get dimexo(): number;
    set dimexo(value: number);
    /**
     * Dimension line Increment. This property controls the spacing between the dimension lines when you
     * create multiple parallel dimensions using the baseline dimensioning method.
     */
    get dimdli(): number;
    set dimdli(value: number);
    /**
     * Dimension extension line extension. This property controls how far beyond the dimension line the
     * extension lines extend. You can adjust this value to control the length of the extension line
     * past the dimension line.
     */
    get dimexe(): number;
    set dimexe(value: number);
    /**
     * Dimension rounding. This property controls the rounding of dimension distances to a specified value.
     * When set to 0.0, no rounding occurs, and the dimension is displayed with its exact value. You can
     * set it to a non-zero value to round dimensions to a specific increment.
     */
    get dimrnd(): number;
    set dimrnd(value: number);
    /**
     * Dimension line extension. This property controls how far the dimension line is extended beyond
     * the extension lines. By default, the dimension line ends at the extension lines, but you can
     * adjust this value to extend the dimension line beyond them.
     */
    get dimdle(): number;
    set dimdle(value: number);
    /**
     * Dimension text post. This property controls the tolerance value added after the dimension text,
     * typically used for specifying tolerance values in dimensions. The default setting of 0.0 means
     * that no additional tolerance is applied by default.
     */
    get dimtp(): number;
    set dimtp(value: number);
    /**
     * Dimension minus tolerance. This property controls the lower tolerance limit for dimensions. When
     * set to 0.0, no minus tolerance is applied by default. You can set this to a different value if
     * you need to specify a negative tolerance for your dimensions.
     */
    get dimtm(): number;
    set dimtm(value: number);
    /**
     * Dimension text height. This property controls the height of the dimension text. You can adjust
     * this value to change the size of the text in your dimensions to fit the scale and appearance of
     * your drawing.
     */
    get dimtxt(): number;
    set dimtxt(value: number);
    /**
     * Dimension center mark size. This property controls the size of the center marks or centerlines
     * for circles and arcs in dimensions. A positive value specifies the size of the center mark,
     * while a negative value specifies the size of the centerline. If set to 0, no center mark or
     * centerline is drawn.
     */
    get dimcen(): number;
    set dimcen(value: number);
    /**
     * Dimension tick size. When set to 0.0, no tick marks are displayed, and the default arrowheads are
     * used for dimension lines. If you set it to a positive value, it will display tick marks instead
     * of arrowheads, with the value controlling the size of the ticks.
     */
    get dimtsz(): number;
    set dimtsz(value: number);
    /**
     * Alternate dimensioning. The default value of DIMALT is set to 0 for DIMALTF (Dimension Alternate
     * Text Format), which means that alternate dimensions are not displayed by default.
     * When DIMALT is set to 1, it indicates that alternate dimensioning is enabled, and you can use
     * DIMALTF to specify the format of the alternate dimension text. You can set it to various values
     * depending on how you want the alternate dimensions to be displayed.
     */
    get dimaltf(): number;
    set dimaltf(value: number);
    /**
     * Dimension linear factor. This property controls the scaling factor for linear dimensions. If you
     * want to adjust the size of linear dimensions without changing the actual dimension text height or
     * other dimension settings, you can modify this value. A setting of 1.0 means that dimensions are
     * displayed at their actual size.
     */
    get dimlfac(): number;
    set dimlfac(value: number);
    /**
     * Dimension text vertical position. This property controls the vertical position of dimension text
     * relative to the dimension line. A value of 0.0 means that the dimension text is placed directly
     * on the dimension line. You can adjust this value to change the vertical offset of the dimension
     * text above or below the dimension line.
     */
    get dimtvp(): number;
    set dimtvp(value: number);
    /**
     * Dimension text factor. This property is used to scale the height of dimension text based on the
     * current DIMTXT value. If you set DIMTFAC to a value greater than 1.0, the dimension text will be
     * larger than the default height specified by DIMTXT. Conversely, setting it to a value less than
     * 1.0 will make the text smaller.
     */
    get dimtfac(): number;
    set dimtfac(value: number);
    /**
     * Dimension gap. This property controls the distance between the dimension line and the extension
     * lines. You can adjust this value to create more space or less space between these elements in
     * your dimensions.
     */
    get dimgap(): number;
    set dimgap(value: number);
    /**
     * Text fill. Controls whether the space behind dimension text is filled to
     * hide drawing elements under the text.
     * - 0: No background fill
     * - 1: Fills with the drawing background color
     * - 2: Fills with the color stored in dimtfillclr
     */
    get dimtfill(): 0 | 1 | 2;
    set dimtfill(value: 0 | 1 | 2);
    /**
     * Text fill custom color. This property stores the ACI (or packed true)
     * color used as dimension text background when dimtfill is 2.
     */
    get dimtfillclr(): number;
    set dimtfillclr(value: number);
    /**
     * Dimension alternate rounding. This property controls rounds off the alternate dimension units.
     */
    get dimaltrnd(): number;
    set dimaltrnd(value: number);
    /**
     * Dimension tolerance. This property determines whether to appends tolerances to dimension text.
     * Setting DIMTOL to on (1) turns DIMLIM off (0).
     */
    get dimtol(): 0 | 1;
    set dimtol(value: 0 | 1);
    /**
     * Dimension limit. This property determines whether to generate dimension limits as the default
     * text. Setting DIMLIM to On turns DIMTOL off.
     * - 0: Dimension limits are not generated as default text
     * - 1: Dimension limits are generated as default text
     */
    get dimlim(): 0 | 1;
    set dimlim(value: 0 | 1);
    /**
     * Dimension text inside horizontal. This property controls the position of dimension text inside the
     * extension lines for all dimension types except Ordinate.
     * - 0: Aligns text with the dimension line
     * - 1: Draws text horizontally
     */
    get dimtih(): 0 | 1;
    set dimtih(value: 0 | 1);
    /**
     * Dimension text outside horizontal. This property controls the position of dimension text
     * outside the extension lines.
     * - 0: Aligns text with the dimension line
     * - 1: Draws text horizontally
     */
    get dimtoh(): 0 | 1;
    set dimtoh(value: 0 | 1);
    /**
     * Text viewing direction. Controls the reading direction of dimension text.
     * - 0: Places text so it reads from left to right
     * - 1: Places text so it reads from right to left (mirrored)
     */
    get dimtxtdirection(): 0 | 1;
    set dimtxtdirection(value: 0 | 1);
    /**
     * Dimension suppress extension line 1. This property controls whether to suppresses display of the
     * first extension line.
     * - 0: Extension line is not suppressed
     * - 1: Extension line is suppressed
     */
    get dimse1(): 0 | 1;
    set dimse1(value: 0 | 1);
    /**
     * Dimension suppress extension line 2. This property controls whether to suppresses display of the
     * second extension line.
     * - 0: Extension line is not suppressed
     * - 1: Extension line is suppressed
     */
    get dimse2(): 0 | 1;
    set dimse2(value: 0 | 1);
    /**
     * Dimension text above dimension line. This property the vertical position of text in relation to
     * the dimension line.
     * - 0: Centers the dimension text between the extension lines.
     * - 1: Places the dimension text above the dimension line except when the dimension line is not
     * horizontal and text inside the extension lines is forced horizontal ( DIMTIH = 1). The distance
     * from the dimension line to the baseline of the lowest line of text is the current DIMGAP value.
     * - 2: Places the dimension text on the side of the dimension line farthest away from the defining
     * points.
     * - 3: Places the dimension text to conform to Japanese Industrial Standards (JIS).
     * - 4: Places the dimension text below the dimension line.
     */
    get dimtad(): AcDbDimTextVertical;
    set dimtad(value: AcDbDimTextVertical);
    /**
     * Dimension zero-in. This property controls the suppression of zeros in the primary unit value.
     * - 0: Suppresses zero feet and precisely zero inches
     * - 1: Includes zero feet and precisely zero inches
     * - 2: Includes zero feet and suppresses zero inches
     * - 3: Includes zero inches and suppresses zero feet
     * - 4: Suppresses leading zeros in decimal dimensions (for example, 0.5000 becomes .5000)
     * - 8: Suppresses trailing zeros in decimal dimensions (for example, 12.5000 becomes 12.5)
     * - 12: Suppresses both leading and trailing zeros (for example, 0.5000 becomes .5)
     */
    get dimzin(): AcDbDimZeroSuppression;
    set dimzin(value: AcDbDimZeroSuppression);
    /**
     * Dimension zero-in for angular dimensions.
     * - 0: Displays all leading and trailing zeros
     * - 1: Suppresses leading zeros in decimal dimensions (for example, 0.5000 becomes .5000)
     * - 2: Suppresses trailing zeros in decimal dimensions (for example, 12.5000 becomes 12.5)
     * - 3: Suppresses leading and trailing zeros (for example, 0.5000 becomes .5)
     */
    get dimazin(): AcDbDimZeroSuppressionAngular;
    set dimazin(value: AcDbDimZeroSuppressionAngular);
    /**
     * Dimension angular zero-in. This property controls the display of alternate units in dimensions.
     * - 0: Disables alternate units
     * - 1: Enables alternate units
     */
    get dimalt(): 0 | 1;
    set dimalt(value: 0 | 1);
    /**
     * Dimension alternate dimension. This property controls the number of decimal places in alternate
     * units. If DIMALT is turned on, DIMALTD sets the number of digits displayed to the right of the
     * decimal point in the alternate measurement.
     */
    get dimaltd(): number;
    set dimaltd(value: number);
    /**
     * Dimension to first extension line. This property controls whether a dimension line is drawn
     * between the extension lines even when the text is placed outside. For radius and diameter
     * dimensions, a dimension line is drawn inside the circle or arc when the text, arrowheads,
     * and leader are placed outside.
     * - 0: Does not draw dimension lines between the measured points when arrowheads are placed
     * outside the measured points
     * - 1: Draws dimension lines between the measured points even when arrowheads are placed
     * outside the measured points
     */
    get dimtofl(): 0 | 1;
    set dimtofl(value: 0 | 1);
    /**
     * Dimension suppress arrowheads. This property controls the display of dimension line arrowhead blocks.
     * - 0: Use arrowhead blocks set by DIMBLK
     * - 1: Use arrowhead blocks set by DIMBLK1 and DIMBLK2
     */
    get dimsah(): 0 | 1;
    set dimsah(value: 0 | 1);
    /**
     * Dimension text inside extension lines. This property controls the position of dimension text
     * relative to the extension lines.
     * - 0: For linear and angular dimensions, dimension text is placed inside the extension lines if
     * there is sufficient room.
     * - 1: Draws dimension text between the extension lines even if it would ordinarily be placed
     * outside those lines. For radius and diameter dimensions, DIMTIX on always forces the dimension
     * text outside the circle or arc.
     */
    get dimtix(): 0 | 1;
    set dimtix(value: 0 | 1);
    /**
     * Dimension suppress offset x-direction. This property controls whether to suppresses arrowheads
     * if not enough space is available inside the extension lines.
     * If not enough space is available inside the extension lines and DIMTIX is on, setting DIMSOXD to
     * On suppresses the arrowheads. If DIMTIX is off, DIMSOXD has no effect.
     * - 0: Arrowheads are not suppressed
     * - 1: Arrowheads are suppressed
     */
    get dimsoxd(): 0 | 1;
    set dimsoxd(value: 0 | 1);
    /**
     * Dimension color. This property controls colors to dimension lines, arrowheads, and dimension leader
     * lines. For BYBLOCK, enter 0. For BYLAYER, enter 256.
     */
    get dimclrd(): number;
    set dimclrd(value: number);
    /**
     * Dimension extension line color. This property controls colors to extension lines, center marks,
     * and centerlines. For BYBLOCK, enter 0. For BYLAYER, enter 256.
     */
    get dimclre(): number;
    set dimclre(value: number);
    /**
     * Dimension text color. This property controls colors to dimension text. For BYBLOCK, enter 0.
     * For BYLAYER, enter 256.
     */
    get dimclrt(): number;
    set dimclrt(value: number);
    /**
     * Dimension angular decimal places. This property controls the number of precision places displayed
     * in angular dimensions.
     * - 1: Angular dimensions display the number of decimal places specified by DIMDEC
     * - 0-8: Specifies the number of decimal places displayed in angular dimensions (independent of DIMDEC)
     */
    get dimadec(): number;
    set dimadec(value: number);
    /**
     * Dimension linear units. This property controls the format in which linear dimensions are displayed.
     * The value of this property include:
     * - 1: Scientific
     * - 2: Decimal
     * - 3: Engineering
     * - 4: Architectural (always displayed stacked)
     * - 5: Fractional (always displayed stacked)
     * - 6: Microsoft Windows Desktop (decimal format using Control Panel settings for decimal separator
     * and number grouping symbols)
     */
    get dimunit(): number;
    set dimunit(value: number);
    /**
     * Dimension decimal places. This property controls the number of decimal places displayed for the
     * primary units of a dimension. Its initial value is	4 for imperial unit or 2 for metric unit.
     * The precision is based on the units or angle format you have selected. Specified value is applied
     * to angular dimensions when DIMADEC is set to -1.
     */
    get dimdec(): number;
    set dimdec(value: number);
    /**
     * Dimension tolerance decimal places. This property controls the number of decimal places to display
     * in tolerance values for the primary units in a dimension. This property has no effect unless DIMTOL
     * is set to On. The default for DIMTOL is Off.
     */
    get dimtdec(): number;
    set dimtdec(value: number);
    /**
     * Dimension alternate unit format. This property controls the units format for alternate units of
     * all dimension substyles except Angular. The value of this property include:
     * - 1: Scientific
     * - 2: Decimal
     * - 3: Engineering
     * - 4: Architectural (stacked)
     * - 5: Fractional (stacked)
     * - 6: Architectural
     * - 7: Fractional
     * - 8: Microsoft Windows Desktop (decimal format using Control Panel settings for decimal separator
     * and number grouping symbols)
     */
    get dimaltu(): number;
    set dimaltu(value: number);
    /**
     * Dimension alternate tolerance decimal places. This property controls the number of decimal places
     * for the tolerance values in the alternate units of a dimension.
     */
    get dimalttd(): number;
    set dimalttd(value: number);
    /**
     * Dimension angular units. This property controls the units format for angular dimensions.
     * - 0: Decimal degrees
     * - 1: Degrees/minutes/seconds
     * - 2: Gradians
     * - 3: Radians
     */
    get dimaunit(): number;
    set dimaunit(value: number);
    /**
     * Dimension fraction format. This property controls the fraction format when DIMLUNIT is set to 4
     * (Architectural) or 5 (Fractional).
     * - 0: Horizontal stacking
     * - 1: Diagonal stacking
     * - 2: Not stacked (for example, 1/2)
     */
    get dimfrac(): number;
    set dimfrac(value: number);
    /**
     * Dimension linear units. This property controls units for all dimension types except angular.
     * The value of this property include:
     * - 1: Scientific
     * - 2: Decimal
     * - 3: Engineering
     * - 4: Architectural (always displayed stacked)
     * - 5: Fractional (always displayed stacked)
     * - 6: Microsoft Windows Desktop (decimal format using Control Panel settings for decimal separator
     * and number grouping symbols)
     */
    get dimlunit(): number;
    set dimlunit(value: number);
    /**
     * Dimension decimal separator. This property is used to specifies a single-character decimal separator
     * to use when creating dimensions whose unit format is decimal.
     */
    get dimdsep(): string;
    set dimdsep(value: string);
    /**
     * Dimension text movement. This property is used to set dimension text movement rules.
     * - 0: Moves the dimension line with dimension text
     * - 1: Adds a leader when dimension text is moved
     * - 2: Allows text to be moved freely without a leader
     */
    get dimtmove(): number;
    set dimtmove(value: number);
    /**
     * Dimension text justification. This property controls the horizontal positioning of dimension text.
     * - 0: Positions the text above the dimension line and center-justifies it between the extension lines
     * - 1: Positions the text next to the first extension line
     * - 2: Positions the text next to the second extension line
     * - 3: Positions the text above and aligned with the first extension line
     * - 4: Positions the text above and aligned with the second extension line
     */
    get dimjust(): number;
    set dimjust(value: number);
    /**
     * Suppress first dimension line. This property controls suppression of the first dimension line
     * and arrowhead. When turned on, suppresses the display of the dimension line and arrowhead
     * between the first extension line and the text.
     * - 0: First dimension line is not suppressed
     * - 1: First dimension line is suppressed
     */
    get dimsd1(): 0 | 1;
    set dimsd1(value: 0 | 1);
    /**
     * Suppress second dimension line. This property controls suppression of the second dimension line
     * and arrowhead. When turned on, suppresses the display of the dimension line and arrowhead
     * between the second extension line and the text.
     * - 0: Second dimension line is not suppressed
     * - 1: Second dimension line is suppressed
     */
    get dimsd2(): 0 | 1;
    set dimsd2(value: 0 | 1);
    /**
     * Dimension tolerance justification. This property sets the vertical justification for tolerance
     * values relative to the nominal dimension text. This property has no effect unless DIMTOL is set
     * to On. The default for DIMTOL is Off.
     * - 0: Bottom
     * - 1: Middle
     * - 2: Top
     */
    get dimtolj(): AcDbDimVerticalJustification;
    set dimtolj(value: AcDbDimVerticalJustification);
    /**
     * Dimension tolerance zero suppress. This property controls the suppression of zeros in tolerance values.
     * Values 0-3 affect feet-and-inch dimensions only.
     * - 0: Suppresses zero feet and precisely zero inches
     * - 1: Includes zero feet and precisely zero inches
     * - 2: Includes zero feet and suppresses zero inches
     * - 3: Includes zero inches and suppresses zero feet
     * - 4: Suppresses leading zeros in decimal dimensions (for example, 0.5000 becomes .5000)
     * - 8: Suppresses trailing zeros in decimal dimensions (for example, 12.5000 becomes 12.5)
     * - 12: Suppresses both leading and trailing zeros (for example, 0.5000 becomes .5)
     */
    get dimtzin(): AcDbDimZeroSuppression;
    set dimtzin(value: AcDbDimZeroSuppression);
    /**
     * Dimension alternate unit zero suppress. This property controls the suppression of zeros for
     * alternate unit dimension values. DIMALTZ values 0-3 affect feet-and-inch dimensions only.
     * - 0: Suppresses zero feet and precisely zero inches
     * - 1: Includes zero feet and precisely zero inches
     * - 2: Includes zero feet and suppresses zero inches
     * - 3: Includes zero inches and suppresses zero feet
     * - 4: Suppresses leading zeros in decimal dimensions (for example, 0.5000 becomes .5000)
     * - 8: Suppresses trailing zeros in decimal dimensions (for example, 12.5000 becomes 12.5)
     * - 12: Suppresses both leading and trailing zeros (for example, 0.5000 becomes .5)
     */
    get dimaltz(): AcDbDimZeroSuppression;
    set dimaltz(value: AcDbDimZeroSuppression);
    /**
     * Dimension alternate tolerance zero suppress. This property controls suppression of zeros in
     * tolerance values.
     * - 0: Suppresses zero feet and precisely zero inches
     * - 1: Includes zero feet and precisely zero inches
     * - 2: Includes zero feet and suppresses zero inches
     * - 3: Includes zero inches and suppresses zero feet
     *
     * To suppress leading or trailing zeros, add the following values to one of the preceding values:
     * - 4: Suppresses leading zeros
     * - 8: Suppresses trailing zeros
     */
    get dimalttz(): AcDbDimZeroSuppression;
    set dimalttz(value: AcDbDimZeroSuppression);
    /**
     * Dimension fit. This property controls how dimension text fits within the dimension line.
     * The value of this property include:
     * - 0: Fit (default) – The dimension text is placed outside the dimension lines if it does not fit inside.
     * - 1: Above – The dimension text is placed above the dimension line.
     * - 2: Center – The dimension text is centered between the extension lines.
     * With the default setting of 0, the software automatically positions the dimension text based on
     * available space.
     */
    get dimfit(): number;
    set dimfit(value: number);
    /**
     * Dimension update. This property controls options for user-positioned text.
     * - 0: Cursor controls only the dimension line location
     * - 1: Cursor controls both the text position and the dimension line location
     */
    get dimupt(): number;
    set dimupt(value: number);
    /**
     * Dimension angular tolerance fit. This property determines how dimension text and arrows are
     * arranged when space is not sufficient to place both within the extension lines.
     * - 0: Places both text and arrows outside extension lines
     * - 1: Moves arrows first, then text
     * - 2: Moves text first, then arrows
     * - 3: Moves either text or arrows, whichever fits best
     * A leader is added to moved dimension text when DIMTMOVE is set to 1.
     */
    get dimatfit(): number;
    set dimatfit(value: number);
    /**
     * Dimension text style. This property specifies the text style of the dimension.
     */
    get dimtxsty(): string;
    set dimtxsty(value: string);
    /**
     * Dimension leader block. This property specifies the arrow type for leaders. To return to the
     * default, closed-filled arrowhead display, enter a single period (.). For a list of arrowhead
     * entries, see DIMBLK.
     * Note: Annotative blocks cannot be used as custom arrowheads for dimensions or leaders.
     */
    get dimldrblk(): string;
    set dimldrblk(value: string);
    /**
     * Dimension arrowhead block. This property controls the arrowhead block displayed at the ends of
     * dimension lines.
     */
    get dimblk(): string;
    set dimblk(value: string);
    /**
     * Dimension arrowhead block for the first arrow. This property controls the arrowhead for the
     * first end of the dimension line when DIMSAH is on.
     */
    get dimblk1(): string;
    set dimblk1(value: string);
    /**
     * Dimension arrowhead block for the second arrow. This property controls the arrowhead for the
     * second end of the dimension line when DIMSAH is on.
     */
    get dimblk2(): string;
    set dimblk2(value: string);
    /**
     * Dimension line weight. This property controls lineweight to dimension lines.
     * - -1: Sets the lineweight to "BYLAYER."
     * - -2: Sets the lineweight to "BYBLOCK."
     * - -3: Sets the lineweight to "DEFAULT." "DEFAULT" is controlled by the LWDEFAULT system variable.
     * Other valid values entered in hundredths of millimeters include 0, 5, 9, 13, 15, 18, 20, 25, 30,
     * 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, and 211.
     * All values must be entered in hundredths of millimeters. (Multiply a value by 2540 to convert
     * values from inches to hundredths of millimeters.)
     */
    get dimlwd(): number;
    set dimlwd(value: number);
    /**
     * Dimension line weight for extension lines. This property controls lineweight to extension lines.
     * - -1: Sets the lineweight to "BYLAYER."
     * - -2: Sets the lineweight to "BYBLOCK."
     * - -3: Sets the lineweight to "DEFAULT." "DEFAULT" is controlled by the LWDEFAULT system variable.
     * Other valid values entered in hundredths of millimeters include 0, 5, 9, 13, 15, 18, 20, 25, 30,
     * 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, and 211.
     * All values must be entered in hundredths of millimeters. (Multiply a value by 2540 to convert
     * values from inches to hundredths of millimeters.)
     */
    get dimlwe(): number;
    set dimlwe(value: number);
    /**
     * Writes this object to the DXF output.
     *
     * DIMSTYLE table records use group code **105** for the handle (not 5).
     *
     * @returns The instance (for chaining).
     */
    dxfOut(...args: unknown[]): unknown;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbDimStyleTableRecord.d.ts.map