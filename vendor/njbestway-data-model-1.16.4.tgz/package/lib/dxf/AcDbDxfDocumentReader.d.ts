import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbDatabase } from '../database/AcDbDatabase.js';
export interface AcDbDxfDocumentReaderOptions {
    /**
     * How often to check parse progress / UI yield while streaming entities
     * (entity count). Actual yields are time-budgeted via {@link yieldBudgetMs}.
     */
    entityBatchSize?: number;
    /**
     * Minimum wall time between cooperative UI yields during parse.
     * Defaults to {@link ACCM_DEFAULT_UI_YIELD_BUDGET_MS}.
     */
    yieldBudgetMs?: number;
    /**
     * Called with approximate parse completion in `[0, 1]` based on byte
     * offset. Used by the native converter to emit mid-PARSE progress.
     */
    onProgress?: (ratio: number) => void | Promise<void>;
    /** Total DXF byte length for {@link onProgress}. */
    totalBytes?: number;
}
export interface AcDbDxfDocumentReaderResult {
    /**
     * Entities without a native class. They are kept as
     * {@link AcDbUnknownEntity} and written back verbatim.
     */
    unknownEntityCount: number;
    /** OBJECTS-section records kept verbatim (no native reader yet). */
    unknownObjectCount: number;
}
/**
 * Single-pass streaming DXF document reader.
 *
 * Walks HEADER → CLASSES → TABLES → BLOCKS → ENTITIES → OBJECTS in file
 * order and writes directly into {@link AcDbDatabase}. Does not buffer the
 * whole file as tag groups.
 */
export declare class AcDbDxfDocumentReader {
    private readonly _db;
    private readonly _options;
    private _unknownEntityCount;
    private _unknownObjectCount;
    /** ATTRIB entities waiting for their owning INSERT (keyed by INSERT objectId). */
    private readonly _attributeMap;
    /**
     * INSERT whose ATTRIB sequence may follow. ATTRIBs between an INSERT and
     * its SEQEND belong to it structurally (DXF R12 files carry no 330 owner
     * handles), as ezdxf and ODA link them.
     */
    private _openInsert?;
    private readonly _yieldGate;
    constructor(_db: AcDbDatabase, _options?: AcDbDxfDocumentReaderOptions);
    get unknownEntityCount(): number;
    get unknownObjectCount(): number;
    read(filer: AcDbDxfFiler): Promise<AcDbDxfDocumentReaderResult>;
    private readSectionName;
    private readSection;
    /**
     * Attaches ACDSDATA `ASM_Data` SAB payloads to matching {@link AcDb3dSolid}
     * entities (keyed by entity handle / group 5).
     *
     * Modern DXF files often store 3DSOLID geometry only in ACDSDATA rather than
     * inline encrypted SAT groups 1/3 — without this step solids render empty.
     */
    private applyAcdsDataToSolids;
    private readThumbnailImageSection;
    private readClassesSection;
    private readClassRecord;
    private readTablesSection;
    /**
     * DIMSTYLE groups 340–344 are handles (text style / arrow block records),
     * but {@link AcDbDimStyleTableRecord} stores names. BLOCK_RECORD follows
     * DIMSTYLE in the TABLES section, so resolve once the section is read.
     * Handles that resolve to nothing fall back to the defaults.
     */
    private resolveDimStyleHandles;
    private readTableName;
    private readTable;
    private readNamedTable;
    private readBlockRecordTable;
    private skipUntilEndTab;
    private readBlocksSection;
    /**
     * Reads one BLOCK … ENDBLK definition: sync BTR metadata, then stream entities.
     * @returns Updated sinceYield counter for batching.
     */
    private readBlockDefinition;
    /**
     * Block definitions may own entities. `*Model_Space` and the active
     * `*Paper_Space` layout are streamed from the ENTITIES section. Inactive
     * layouts (`*Paper_Space0`, `*Paper_Space1`, …) keep their entities in the
     * block (ezdxf and some CAD writers); those must be read here.
     *
     * @see https://ezdxf.readthedocs.io/en/stable/dxfinternals/filestructure.html
     */
    private shouldAcceptBlockEntity;
    /**
     * The active paper-space layout's internal block name is exactly
     * `*Paper_Space`. Numbered names are inactive layouts.
     */
    private static isActivePaperSpaceName;
    /** Consume a SEQEND object after its `(0, SEQEND)` pair was already read. */
    private consumeSeqend;
    private readBlockBeginFields;
    private ensureBlockTableRecord;
    private readEntitiesSection;
    /**
     * Chooses model vs paper space BTR for an ENTITIES-section entity.
     * Prefers ownerId (330) when it names a space BTR; falls back to DXF group 67.
     */
    private resolveEntityOwner;
    /**
     * Appends an entity (or links ATTRIB → INSERT).
     */
    private acceptEntity;
    private countUnknownEntity;
    private linkOrDeferAttribute;
    private flushRemainingAttributes;
    private skipUntilEndSec;
    private reportParseProgress;
    private yieldAndReportProgress;
}
//# sourceMappingURL=AcDbDxfDocumentReader.d.ts.map