import type { AcDbObject } from '../base/AcDbObject.js';
/**
 * Returns the DXF record name (group 0) used to write `object` into the
 * OBJECTS section, or `undefined` when the object cannot be written.
 *
 * Context data created in-app (no tags preserved from a DXF) is only written
 * when the drawing declares its class in CLASSES; AutoCAD rejects records of
 * undeclared custom classes.
 *
 * @param classNames - Upper-case DXF record names declared in CLASSES.
 */
export declare function acdbDxfObjectRecordName(object: AcDbObject, classNames: ReadonlySet<string>): string | undefined;
//# sourceMappingURL=AcDbDxfObjectRecordName.d.ts.map