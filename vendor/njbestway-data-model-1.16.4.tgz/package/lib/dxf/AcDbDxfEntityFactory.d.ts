import type { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbEntity } from '../entity/AcDbEntity.js';
/**
 * Creates an empty entity instance for the given DXF type name, ready for dxfIn.
 * Returns null for unsupported types (caller should skip to next code 0).
 *
 * Composite types that need a subclass/assembler pass first are **not** created
 * here — use {@link acdbDxfInEntity} (or the dedicated assemblers) instead:
 * - `INSERT` / MINSERT → {@link acdbDxfInInsert}
 * - `POLYLINE` → {@link acdbDxfInPolyline}
 * - `DIMENSION` → {@link acdbDxfInDimension}
 */
export declare function acdbCreateEntityForDxfIn(typeName: string): AcDbEntity | null;
/**
 * Create entity from the current filer position.
 * Expects the filer to be at (or just past) the type name pair (0, TYPENAME).
 * When `typeName` is omitted, reads the next (0, name) pair.
 */
export declare function acdbDxfInEntity(filer: AcDbDxfFiler, typeName?: string): AcDbEntity | null;
//# sourceMappingURL=AcDbDxfEntityFactory.d.ts.map