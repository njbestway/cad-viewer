import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbBlockReference } from '../entity/AcDbBlockReference.js';
/**
 * Drain one INSERT object's pairs (including XData) and create either an
 * {@link AcDbBlockReference} or an {@link AcDbMInsertBlock}.
 *
 * DXF stores both INSERT and MINSERT with the entity type name `INSERT`.
 * A MINSERT is recognized by:
 * - its `AcDbMInsertBlock` subclass marker (ODA / ezdxf),
 * - a column count (70) or row count (71) greater than one (AutoCAD keeps the
 *   `AcDbBlockReference` marker), or
 * - non-zero column/row spacing (44/45), so 1×1 arrays with spacing survive a
 *   round trip instead of dropping those fields.
 *
 * Expects the filer just after `(0, INSERT)`.
 */
export declare function acdbDxfInInsert(filer: AcDbDxfFiler): AcDbBlockReference;
//# sourceMappingURL=AcDbDxfInsertAssembler.d.ts.map