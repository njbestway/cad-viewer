import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbDatabase } from '../database/AcDbDatabase.js';
/**
 * Streams the DXF OBJECTS section into {@link AcDbDatabase} dictionaries.
 *
 * Known object types are written immediately. DICTIONARY / XRECORD payloads
 * are also buffered as lightweight persist maps for the Layer Manager filter
 * tree, then discarded after {@link acdbReadLayerFilterTree}.
 */
export declare class AcDbDxfObjectsReader {
    private readonly _db;
    private readonly _dictionaries;
    private readonly _xrecords;
    private _unknownObjectCount;
    /** Objects kept verbatim, linked into dictionaries once all are loaded. */
    private readonly _unknownObjects;
    /** Natively read associative-framework records. */
    private readonly _assocObjects;
    constructor(_db: AcDbDatabase);
    /** Count of OBJECTS records kept verbatim because no native reader exists. */
    get unknownObjectCount(): number;
    /**
     * Reads OBJECTS until ENDSEC. Caller must have already consumed the
     * `(0, SECTION)` / `(2, OBJECTS)` header pairs.
     */
    read(filer: AcDbDxfFiler): void;
    private readObject;
    /**
     * Reads an associative-framework record (network, action, body,
     * dependency, action parameter). These are owned through hard pointers or
     * dictionaries and resolved by handle.
     */
    private readAssocObject;
    /**
     * Reads a context-data record keeping its tags for verbatim export; only
     * part of each record is modeled natively.
     */
    private readContextData;
    /**
     * Wire the root named-object dictionary and known child dictionaries
     * (ACAD_LAYOUT / ACAD_GROUP / …) from buffered DICTIONARY persist maps.
     */
    private finishNamedObjectDictionaries;
    /**
     * Gives a bootstrap dictionary the handle it has in the DXF. A default
     * object that was minted the same handle (e.g. an `ACAD_GROUP` the file
     * does not contain) moves to a fresh handle so no handle is written twice.
     */
    private adoptDxfHandle;
    private collectLoadedObjectsByHandle;
    /**
     * Materializes every buffered DICTIONARY into an {@link AcDbDictionary}
     * registered in the database handle map so entity/viewport extension
     * dictionaries and annotation-scale context chains resolve via
     * {@link AcDbDatabase.getObjectById}.
     */
    private materializeBufferedDictionaries;
    /**
     * Reads CANNOSCALE from AcDbVariableDictionary → DICTIONARYVAR.
     */
    private finishCannoscale;
    /**
     * Reads ANNOALLVISIBLE from AcDbVariableDictionary → DICTIONARYVAR.
     * AutoCAD stores `"0"` / `"1"`; defaults to true when absent.
     */
    private finishAnnoallvisible;
    private readPersistDictionary;
    private finishLayerFilterTree;
    /**
     * Cross-links LAYOUT objects with BLOCK_RECORD layoutId / blockTableRecordId,
     * matching {@link AcDbObjectConverter.convertLayout} resolution rules.
     */
    private linkLayoutsToBlockTableRecords;
}
//# sourceMappingURL=AcDbDxfObjectsReader.d.ts.map