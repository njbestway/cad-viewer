import type { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbDxfPair } from '../base/AcDbDxfPair.js';
import type { AcDbTypedValue } from '../base/AcDbTypedValue.js';
/**
 * Tags of one DXF record kept verbatim for round-trip (ezdxf `DXFTagStorage`,
 * ODA unknown-class objects).
 *
 * `header` holds the pairs before the first subclass marker except the handle
 * (5/105) and owner (330), which are re-emitted from the live object so a
 * reminted handle or a new owner stays consistent. `body` starts at the first
 * subclass marker. XData is not stored here: it is read through the regular
 * {@link AcDbObject.dxfIn} path so `getXData` keeps working.
 */
export interface AcDbDxfRawTags {
    header: AcDbTypedValue[];
    body: AcDbTypedValue[];
}
/**
 * Drains the current record's tags (up to XData or the next group 0).
 *
 * @returns The captured tags plus the handle/owner found in the header.
 */
export declare function acdbCaptureDxfRawTags(filer: AcDbDxfFiler): AcDbDxfRawTagsCapture;
export interface AcDbDxfRawTagsCapture {
    tags: AcDbDxfRawTags;
    handle?: string;
    ownerId?: string;
    extensionDictionary?: string;
}
/**
 * Splits one record's pairs into {@link AcDbDxfRawTags}. Pairs from the first
 * XData group (1001) on are ignored.
 *
 * The `{ACAD_XDICTIONARY` group is not kept: its id is returned and written
 * back like any native object's (only when the dictionary is exported).
 * Everything after the owner handle goes to `body`, so tags keep their
 * original order around the re-emitted 330.
 */
export declare function acdbSplitDxfRawTags(pairs: readonly AcDbDxfPair[]): AcDbDxfRawTagsCapture;
/**
 * Writes the handle, the preserved header tags (e.g. reactors), the
 * extension dictionary, the owner and the body. The caller writes the
 * `(0, TYPE)` record start and any XData afterwards.
 */
export declare function acdbWriteDxfRawTags(filer: AcDbDxfFiler, tags: AcDbDxfRawTags, object: {
    objectId?: string;
    ownerId?: string;
    extensionDictionary?: string;
}, handleCode?: number): void;
//# sourceMappingURL=AcDbDxfRawTags.d.ts.map