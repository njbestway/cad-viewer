import type { AcDbObject } from '../base/AcDbObject.js';
import type { AcDbDatabase } from '../database/AcDbDatabase.js';
import { AcDbDimStyleTableRecord } from '../database/AcDbDimStyleTableRecord.js';
/** Registered application name that carries the `DSTYLE` override block. */
export declare const ACDB_DSTYLE_XDATA_APP = "ACAD";
/** Marker string that opens the `DSTYLE` subsection inside the `ACAD` XData. */
export declare const ACDB_DSTYLE_XDATA_MARKER = "DSTYLE";
/**
 * One per-entity dimension style override.
 *
 * `code` is the **DIMSTYLE table record group code** of the overridden variable
 * (not an XData group code). For example `41` is DIMASZ and `341` is DIMLDRBLK.
 */
export interface AcDbDimStyleOverride {
    /** DIMSTYLE table group code of the overridden variable. */
    code: number;
    /** Override value exactly as stored in XData (number, string or handle). */
    value: number | string;
}
/** Returns the DIMSTYLE property name for a group code, if supported. */
export declare function acdbDimStylePropertyForCode(code: number): string | undefined;
/**
 * Reads the raw `ACAD`/`DSTYLE` overrides attached to an entity.
 *
 * Dimensions, leaders and tolerance entities store per-entity dimension
 * variable overrides as XData under the `ACAD` AppId:
 *
 * ```text
 * 1001 ACAD
 * 1000 DSTYLE
 * 1002 {
 * 1070 <dimstyle group code> <typed value>   // repeated
 * 1002 }
 * ```
 *
 * Handle-valued overrides (340–344) keep their raw handle string here; use
 * {@link acdbResolveDimStyleOverrides} to turn them into record names.
 *
 * The read path is allocation-free on the compact import form: it never
 * materializes the XData result buffer.
 *
 * @param object - Entity that may carry `ACAD`/`DSTYLE` XData
 * @returns Overrides in the order they appear; empty when absent
 */
export declare function acdbReadDimStyleOverrides(object: AcDbObject): AcDbDimStyleOverride[];
/**
 * Resolves handle-valued overrides (DIMTXSTY / DIMLDRBLK / DIMBLK*) to names.
 *
 * AutoCAD only records an override when the entity value differs from the
 * style, so the very common `(1070 . 341) (1005 . 0)` is meaningful: it clears
 * DIMLDRBLK and the leader therefore uses the standard closed-filled arrow
 * instead of the block referenced by the style. A zero arrow handle is turned
 * into an empty name (satisfying that), while DIMTXSTY = 0 is ignored because an
 * empty text style would leave the dimension text without a style at all.
 *
 * @param overrides - Raw overrides from {@link acdbReadDimStyleOverrides}
 * @param database - Database used to look up the referenced records
 * @returns Overrides with record names substituted for handles
 */
export declare function acdbResolveDimStyleOverrides(overrides: readonly AcDbDimStyleOverride[], database?: AcDbDatabase): AcDbDimStyleOverride[];
/**
 * Builds a style record that reflects the entity's overrides on top of the
 * referenced dimension style.
 *
 * The returned record is a detached `AcDbDimStyleTableRecord` — mutating it
 * never touches the table record in the drawing, and the caller must not add it
 * to the table. Only resolved overrides (see
 * {@link acdbResolveDimStyleOverrides}) are applied; unsupported group codes
 * are ignored so a newer drawing cannot corrupt rendering.
 *
 * @param base - Style referenced by the entity (may be undefined)
 * @param overrides - Resolved overrides, in XData order
 * @returns Effective style for drawing this entity
 */
export declare function acdbApplyDimStyleOverrides(base: AcDbDimStyleTableRecord | undefined, overrides: readonly AcDbDimStyleOverride[]): AcDbDimStyleTableRecord;
/**
 * Convenience wrapper: reads, resolves and applies the overrides of `object`.
 *
 * Returns `base` itself when the entity carries no usable override, so callers
 * on the hot draw path do not pay for a clone per entity per frame.
 *
 * @param object - Entity whose `ACAD`/`DSTYLE` XData is inspected
 * @param base - Style referenced by the entity
 * @param database - Database used to resolve handle-valued overrides
 */
export declare function acdbResolveEffectiveDimStyle(object: AcDbObject, base: AcDbDimStyleTableRecord | undefined, database?: AcDbDatabase): AcDbDimStyleTableRecord | undefined;
/**
 * Writes the `ACAD`/`DSTYLE` override subsection back onto `object`.
 *
 * Mirror of {@link acdbReadDimStyleOverrides}: any existing `DSTYLE` subsection
 * is replaced while the rest of the `ACAD` XData is preserved, because AutoCAD
 * stores all `ACAD` data (overrides included) in a single result buffer per
 * application. Passing an empty list removes only the override subsection.
 *
 * @param object - Entity receiving the overrides
 * @param overrides - Overrides to store; values may be numbers, strings or
 *   handle strings for the 340–344 group codes
 */
export declare function acdbWriteDimStyleOverrides(object: AcDbObject, overrides: readonly AcDbDimStyleOverride[]): void;
/** True when the DIMSTYLE variable of `code` is an integer value. */
export declare function acdbIsIntegerDimStyleCode(code: number): boolean;
/** Default style used when an entity references a missing dimension style. */
export declare const ACDB_DEFAULT_DIM_STYLE: import("../database/AcDbDimStyleTableRecord.js").AcDbDimStyleTableRecordAttrs;
//# sourceMappingURL=AcDbDimStyleOverrides.d.ts.map