import { AcDbDatabase } from '../database/AcDbDatabase.js';
export declare class AcDbDataGenerator {
    readonly db: AcDbDatabase;
    constructor(db: AcDbDatabase);
    createDefaultLayer(): void;
    createDefaultLineType(): void;
    createDefaultTextStyle(): void;
    createDefaultDimStyle(): void;
    createDefaultLayout(): void;
    createArrowBlock(): void;
    /**
     * Ensure a standard AutoCAD-style arrowhead block exists in the block table.
     * Arrow geometry is authored in unit size with tip at the origin pointing +X
     * when rotated 0; inserts typically rotate so the tip points along the
     * dimension line toward the outside.
     */
    ensureArrowBlock(blockName: string): void;
    /**
     * Arrowheads are authored ByBlock. An INSERT or leader then paints them
     * with the dimension line color (DIMCLRD). Leaving the default ByLayer
     * color makes the arrow follow layer 0 / CECOLOR, which is black when the
     * leader line itself is a style color.
     */
    private appendArrowEntity;
    private lineEntity;
}
//# sourceMappingURL=AcDbDataGenerator.d.ts.map