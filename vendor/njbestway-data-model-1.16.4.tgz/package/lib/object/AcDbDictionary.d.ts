import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject, AcDbObjectId } from '../base/AcDbObject.js';
import { AcDbDatabase } from '../database/AcDbDatabase.js';
import { AcDbObjectIterator } from '../misc/AcDbObjectIterator.js';
/**
 * A database-resident object dictionary that maintains a map between text strings and database objects.
 *
 * An instance of this class represents a single object, such as Drawing Symbol Table, to which objects
 * derived from AcDbObject may be added, accessed, and removed. Entries in an AcDbDictionary must be unique.
 * Entries consist of a unique AcDbObject and string, which comprises the entry's key name. The key may be
 * either a text string, or an asterisk ('*') as the first character in the string to signify an anonymous
 * entry. An anonymous entry's key will be constructed internally by appending an 'A' plus a unique integer
 * value to the asterisk; for example, '*A13'. When an object is placed in a dictionary, the dictionary is
 * established as the object's owner, the lookup key string is associated with the object's object ID, and
 * the dictionary itself is attached to the object as a persistent reactor so that the dictionary is notified
 * when the object is erased.
 *
 * @template TObjectType - The type of objects stored in this dictionary
 *
 * @example
 * ```typescript
 * const dictionary = new AcDbDictionary<AcDbLayout>(database);
 * const layout = new AcDbLayout();
 * dictionary.setAt('MyLayout', layout);
 * const retrievedLayout = dictionary.getAt('MyLayout');
 * ```
 */
export declare class AcDbDictionary<TObjectType extends AcDbObject = AcDbObject> extends AcDbObject {
    /** Map of records indexed by name */
    protected _recordsByName: Map<string, TObjectType>;
    /**
     * Creates a new AcDbDictionary instance.
     *
     * @param db - The database this dictionary belongs to
     *
     * @example
     * ```typescript
     * const dictionary = new AcDbDictionary(database);
     * ```
     */
    constructor(db: AcDbDatabase);
    /**
     * Gets the number of entries in the dictionary.
     *
     * @returns The number of entries in the dictionary
     *
     * @example
     * ```typescript
     * const count = dictionary.numEntries;
     * console.log(`Dictionary has ${count} entries`);
     * ```
     */
    get numEntries(): number;
    /**
     * Adds a new entry to the dictionary.
     *
     * If an entry with the specified key already exists, the existing entry is erased
     * and replaced with the new one.
     *
     * @param key - String representing the object's search key name
     * @param value - The new object to add to the dictionary
     *
     * @example
     * ```typescript
     * const layout = new AcDbLayout();
     * dictionary.setAt('MyLayout', layout);
     * ```
     */
    setAt(key: string, value: TObjectType): void;
    /**
     * Removes the entry specified by name from the dictionary.
     *
     * @param name - String representing the entry's key (or name)
     * @returns True if the entry was found and removed, false otherwise
     *
     * @example
     * ```typescript
     * const removed = dictionary.remove('MyLayout');
     * if (removed) {
     *   console.log('Layout removed successfully');
     * }
     * ```
     */
    remove(name: string): boolean;
    /**
     * Removes the entry specified by object ID from the dictionary.
     *
     * @param id - ID of the object to delete
     * @returns True if the entry was found and removed, false otherwise
     *
     * @example
     * ```typescript
     * const removed = dictionary.removeId('some-object-id');
     * ```
     */
    removeId(id: string): boolean;
    /**
     * Removes one dictionary entry from internal maps and records the change when needed.
     *
     * Shared by {@link remove} and {@link removeId}. Enforces strict-mode transaction
     * requirements and defers {@link AcDbDatabase.notifyDictObjectErased} while
     * recording or applying undo/redo.
     *
     * @param object - Stored dictionary object to remove
     * @param key - Dictionary key associated with the object (may be empty when resolved by ID)
     */
    private removeStoredObject;
    /**
     * Removes all records from the dictionary.
     *
     * @example
     * ```typescript
     * dictionary.removeAll();
     * ```
     */
    removeAll(): void;
    /**
     * Checks if the dictionary contains an object with the specified name.
     *
     * @param name - Name to search for
     * @returns True if the dictionary contains an object with the specified name, false otherwise
     *
     * @example
     * ```typescript
     * if (dictionary.has('MyLayout')) {
     *   console.log('Layout exists');
     * }
     * ```
     */
    has(name: string): boolean;
    /**
     * Checks if the dictionary contains an object with the specified ID.
     *
     * @param id - ID to search for
     * @returns True if the dictionary contains an object with the specified ID, false otherwise
     *
     * @example
     * ```typescript
     * if (dictionary.hasId('some-object-id')) {
     *   console.log('Object exists');
     * }
     * ```
     */
    hasId(id: string): boolean;
    /**
     * Gets the object with the specified name from the dictionary.
     *
     * @param name - Name of the object to retrieve
     * @returns The object with the specified name, or undefined if not found
     *
     * @example
     * ```typescript
     * const layout = dictionary.getAt('MyLayout');
     * if (layout) {
     *   console.log('Layout found:', layout);
     * }
     * ```
     */
    getAt(name: string): TObjectType | undefined;
    /**
     * Gets the object with the specified ID from the dictionary.
     *
     * @param id - ID of the object to retrieve
     * @returns The object with the specified ID, or undefined if not found
     *
     * @example
     * ```typescript
     * const object = dictionary.getIdAt('some-object-id');
     * ```
     */
    getIdAt(id: AcDbObjectId): TObjectType | undefined;
    /**
     * Creates a new iterator for traversing the dictionary entries.
     *
     * @returns A new AcDbObjectIterator for this dictionary
     *
     * @example
     * ```typescript
     * const iterator = dictionary.newIterator();
     * while (iterator.hasNext()) {
     *   const object = iterator.next();
     *   console.log('Object:', object);
     * }
     * ```
     */
    newIterator(): AcDbObjectIterator<TObjectType>;
    /**
     * Returns dictionary entries as `[key, object]` tuples.
     */
    entries(): IterableIterator<[string, TObjectType]>;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Default entry of an `ACDBDICTIONARYWDFLT` dictionary (DXF group 340),
     * e.g. the `Normal` placeholder of `ACAD_PLOTSTYLENAME`. Undefined for a
     * plain `DICTIONARY`.
     */
    defaultId?: AcDbObjectId;
    /** DXF record type name: `ACDBDICTIONARYWDFLT` when {@link defaultId} is set. */
    get dxfTypeName(): "ACDBDICTIONARYWDFLT" | "DICTIONARY";
    private _dxfOutEntryFilter?;
    /**
     * Writes this dictionary listing only the entries accepted by `include`, so
     * a DXF export never points at records it does not write.
     *
     * @internal Used by {@link AcDbDatabase.dxfOut}.
     */
    dxfOutFiltered(filer: AcDbDxfFiler, include: (value: AcDbObject) => boolean): this;
    /**
     * Reads dictionary entry name/handle pairs.
     *
     * Note: resolved object instances are wired later by
     * {@link AcDbDxfObjectsReader} after child objects are loaded.
     */
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbDictionary.d.ts.map