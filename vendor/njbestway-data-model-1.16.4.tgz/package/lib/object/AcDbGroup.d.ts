import { AcCmColor } from '@mlightcad/common';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject, type AcDbObjectId } from '../base/AcDbObject.js';
import { AcDbEntity } from '../entity/AcDbEntity.js';
import { AcDbObjectIterator } from '../misc/AcDbObjectIterator.js';
/**
 * Nongraphical GROUP object (DXF GROUP / ObjectARX `AcDbGroup`).
 *
 * A group is an ordered, named persistent selection set of database entities.
 * It does not own its members. The group **name** is the key in the
 * `ACAD_GROUP` dictionary; DXF group code 300 stores the **description**.
 *
 * @remarks
 * ObjectARX requires the group to be added to the group dictionary (so it has
 * an object id) before members are appended.
 */
export declare class AcDbGroup extends AcDbObject {
    /** Dictionary key name of this group (`ACAD_GROUP` entry). */
    private _name;
    /** Group description (DXF group 300). */
    private _description;
    /** True when this is an anonymous (`*A…`) group. */
    private _anonymous;
    /** Whether the group can be selected as a unit. */
    private _selectable;
    /** Soft-pointer member entity ids, in group order. */
    private _entityIds;
    /**
     * Creates a new group.
     *
     * @param description - Optional description (ObjectARX ctor first arg).
     * @param selectable - Whether the group is selectable as a unit (default `true`).
     */
    constructor(description?: string, selectable?: boolean);
    /**
     * Gets the dictionary key name of this group (`ACAD_GROUP` entry).
     *
     * @returns The group name.
     */
    get name(): string;
    /**
     * Sets the dictionary key name of this group.
     *
     * Prefer {@link setName} when the group is already stored in
     * `database.objects.group`, so the dictionary key stays in sync.
     *
     * @param value - The new group name.
     */
    set name(value: string);
    /**
     * Gets the group description (DXF group 300).
     *
     * @returns The description string.
     */
    get description(): string;
    /**
     * Sets the group description (DXF group 300).
     *
     * @param value - The new description.
     */
    set description(value: string);
    /**
     * Gets whether this is an anonymous (`*A…`) group.
     *
     * @returns `true` when the group is anonymous.
     *
     * @deprecated Prefer {@link isAnonymous} / {@link setAnonymous}.
     */
    get unnamed(): boolean;
    /**
     * Sets whether this is an anonymous group.
     *
     * @param value - `true` to mark the group anonymous.
     *
     * @deprecated Prefer {@link isAnonymous} / {@link setAnonymous}.
     */
    set unnamed(value: boolean);
    /**
     * Gets whether this is an anonymous group.
     *
     * @returns `true` when the group is anonymous.
     */
    get anonymous(): boolean;
    /**
     * Sets whether this is an anonymous group.
     *
     * @param value - `true` to mark the group anonymous.
     */
    set anonymous(value: boolean);
    /**
     * Gets whether the group can be selected as a unit.
     *
     * @returns `true` when the group is selectable.
     */
    get selectable(): boolean;
    /**
     * Sets whether the group can be selected as a unit.
     *
     * @param value - `true` to allow selecting the group as a unit.
     */
    set selectable(value: boolean);
    /**
     * Gets soft-pointer member entity ids, in group order.
     *
     * @returns A readonly view of member object ids.
     */
    get entityIds(): readonly AcDbObjectId[];
    /**
     * Replaces the entire member id list.
     *
     * @param value - New ordered list of member object ids.
     */
    set entityIds(value: readonly AcDbObjectId[]);
    /**
     * Appends one member id to the group.
     *
     * @param id - Object id of the entity to append.
     *
     * @deprecated Prefer {@link append}.
     */
    addEntityId(id: AcDbObjectId): void;
    /**
     * Returns whether this group is anonymous.
     *
     * Mirrors ObjectARX `AcDbGroup::isAnonymous`.
     *
     * @returns `true` when the group is anonymous.
     */
    isAnonymous(): boolean;
    /**
     * Marks this group as anonymous.
     *
     * Mirrors ObjectARX `AcDbGroup::setAnonymous`.
     */
    setAnonymous(): void;
    /**
     * Returns whether the group is not accessible.
     *
     * Mirrors ObjectARX `AcDbGroup::isNotAccessible`. This port always returns
     * `false` (inaccessible/proxy groups are not modeled).
     *
     * @returns Always `false`.
     */
    isNotAccessible(): boolean;
    /**
     * Sets the group name and, when database-bound, renames its `ACAD_GROUP`
     * dictionary entry to match.
     *
     * Mirrors ObjectARX `AcDbGroup::setName`.
     *
     * @param name - The new group name.
     */
    setName(name: string): void;
    /**
     * Returns the number of member entities in the group.
     *
     * Mirrors ObjectARX `AcDbGroup::numEntities`.
     *
     * @returns Member count.
     */
    numEntities(): number;
    /**
     * Copies all member object ids into `out` (when provided) and returns the
     * member count.
     *
     * Mirrors ObjectARX `AcDbGroup::allEntityIds`.
     *
     * @param out - Optional array cleared and filled with member ids.
     * @returns The number of member ids.
     */
    allEntityIds(out?: AcDbObjectId[]): number;
    /**
     * Returns whether the group contains the given entity or object id.
     *
     * Mirrors ObjectARX `AcDbGroup::has`.
     *
     * @param entityOrId - An {@link AcDbEntity} or an object id string.
     * @returns `true` when the id is a member of this group.
     */
    has(entityOrId: AcDbEntity | AcDbObjectId): boolean;
    /**
     * Returns the zero-based index of a member id, or `-1` when not found.
     *
     * Mirrors ObjectARX `AcDbGroup::getIndex`.
     *
     * @param id - Member object id to look up.
     * @returns Index in the group, or `-1`.
     */
    getIndex(id: AcDbObjectId): number;
    /**
     * Creates an iterator over member object ids (in group order).
     *
     * Uses the shared {@link AcDbObjectIterator} pattern of this codebase
     * (rather than ObjectARX `AcDbGroupIterator`).
     *
     * @returns An iterator yielding member {@link AcDbObjectId} values.
     *
     * @example
     * ```typescript
     * for (const id of group.newIterator()) {
     *   const entity = db.getObjectById(id)
     * }
     * ```
     */
    newIterator(): AcDbObjectIterator<AcDbObjectId>;
    /**
     * Appends one or more member ids to the end of the group.
     *
     * Duplicate ids already in the group are ignored. Mirrors ObjectARX
     * `AcDbGroup::append`.
     *
     * @param idOrIds - A single object id or an array of object ids.
     */
    append(idOrIds: AcDbObjectId | readonly AcDbObjectId[]): void;
    /**
     * Prepends one or more member ids to the start of the group.
     *
     * Duplicate ids already in the group are ignored. Mirrors ObjectARX
     * `AcDbGroup::prepend`.
     *
     * @param idOrIds - A single object id or an array of object ids.
     */
    prepend(idOrIds: AcDbObjectId | readonly AcDbObjectId[]): void;
    /**
     * Inserts one or more member ids at the given index.
     *
     * Duplicate ids already in the group are ignored. Mirrors ObjectARX
     * `AcDbGroup::insertAt`.
     *
     * @param index - Zero-based insertion index (clamped to `[0, length]`).
     * @param idOrIds - A single object id or an array of object ids.
     */
    insertAt(index: number, idOrIds: AcDbObjectId | readonly AcDbObjectId[]): void;
    /**
     * Removes one or more members by object id.
     *
     * Mirrors ObjectARX `AcDbGroup::remove`.
     *
     * @param idOrIds - A single object id or an array of object ids to remove.
     */
    remove(idOrIds: AcDbObjectId | readonly AcDbObjectId[]): void;
    /**
     * Removes a member at `index`, or removes the given ids starting from that
     * index when `ids` is provided.
     *
     * Mirrors ObjectARX `AcDbGroup::removeAt`.
     *
     * @param index - Zero-based index of the first member to consider.
     * @param ids - Optional subset of ids to remove from `index` onward.
     */
    removeAt(index: number, ids?: readonly AcDbObjectId[]): void;
    /**
     * Replaces one member id with another.
     *
     * If `newId` is already in the group, `oldId` is simply removed. Mirrors
     * ObjectARX `AcDbGroup::replace`.
     *
     * @param oldId - Existing member object id.
     * @param newId - Replacement object id.
     */
    replace(oldId: AcDbObjectId, newId: AcDbObjectId): void;
    /**
     * Moves `num` members starting at `fromIndex` so they begin at `toIndex`.
     *
     * Mirrors ObjectARX `AcDbGroup::transfer`.
     *
     * @param fromIndex - Start index of the block to move.
     * @param toIndex - Destination index for the block.
     * @param num - Number of members to move.
     */
    transfer(fromIndex: number, toIndex: number, num: number): void;
    /**
     * Reverses the order of members in the group.
     *
     * Mirrors ObjectARX `AcDbGroup::reverse`.
     */
    reverse(): void;
    /**
     * Removes all members from the group.
     *
     * Mirrors ObjectARX `AcDbGroup::clear`.
     */
    clear(): void;
    /**
     * Sets the color of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setColor`.
     *
     * @param color - Color to apply (cloned onto each entity).
     */
    setColor(color: AcCmColor): void;
    /**
     * Sets the ACI color of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setColorIndex`.
     *
     * @param index - AutoCAD Color Index (`0`–`256`).
     */
    setColorIndex(index: number): void;
    /**
     * Sets the layer of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setLayer`. When `layerOrId` is an object id
     * of a layer table record, the record's name is used.
     *
     * @param layerOrId - Layer name or layer-table-record object id.
     */
    setLayer(layerOrId: string | AcDbObjectId): void;
    /**
     * Sets the linetype of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setLinetype`. When `linetypeOrId` is an
     * object id of a linetype table record, the record's name is used.
     *
     * @param linetypeOrId - Linetype name or linetype-table-record object id.
     */
    setLinetype(linetypeOrId: string | AcDbObjectId): void;
    /**
     * Sets the linetype scale of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setLinetypeScale`.
     *
     * @param scale - Linetype scale factor.
     */
    setLinetypeScale(scale: number): void;
    /**
     * Sets the material of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setMaterial`. Currently a no-op because
     * entities keep material as a raw DXF extra without a typed setter.
     *
     * @param _materialOrId - Material name or material object id.
     */
    setMaterial(_materialOrId: string | AcDbObjectId): void;
    /**
     * Sets the visibility of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setVisibility`.
     *
     * @param visible - `true` to show members; `false` to hide them.
     */
    setVisibility(visible: boolean): void;
    /**
     * Sets the highlight state of every resolvable member entity.
     *
     * Mirrors ObjectARX `AcDbGroup::setHighlight`. Currently a no-op because
     * this model has no per-entity highlight persistence.
     *
     * @param _highlight - Desired highlight state.
     */
    setHighlight(_highlight: boolean): void;
    /**
     * Writes DXF subclass fields for this group.
     *
     * @param filer - DXF output writer.
     * @returns This instance for chaining.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Reads DXF subclass fields for this group.
     *
     * @param filer - DXF input reader positioned at this object.
     * @returns This instance for chaining.
     */
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Resolves member ids to {@link AcDbEntity} instances via the owning
     * database. Non-entity or missing ids are skipped.
     *
     * @returns Entities currently resolvable from {@link entityIds}.
     */
    private memberEntities;
    /**
     * Resolves a layer name from a name string or layer-table-record object id.
     *
     * @param layerOrId - Layer name or object id.
     * @returns Layer name to apply to member entities.
     */
    private resolveLayerName;
    /**
     * Resolves a linetype name from a name string or linetype-table-record
     * object id.
     *
     * @param linetypeOrId - Linetype name or object id.
     * @returns Linetype name to apply to member entities.
     */
    private resolveLinetypeName;
}
//# sourceMappingURL=AcDbGroup.d.ts.map