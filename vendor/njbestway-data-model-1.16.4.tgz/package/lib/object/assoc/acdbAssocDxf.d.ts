import { AcGePoint3d } from '@mlightcad/geometry-engine';
import type { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import type { AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbTypedValue } from '../../base/AcDbTypedValue.js';
/**
 * Sequential reader over the group codes of one DXF subclass.
 *
 * Associative-framework records (ACDBASSOC*) are positional: the same group
 * code (90, 330, 360, 40, …) repeats with different meanings, so they cannot be
 * read with the usual order-independent `switch`. The cursor collects every
 * pair up to the next subclass marker (100), end of object, or XData, and
 * hands them out in order.
 *
 * Reads tolerate a short record: a missing value yields the default.
 */
export declare class AcDbAssocDxfCursor {
    private readonly _items;
    private _index;
    private _misses;
    private constructor();
    /** Every pair of the subclass, consumed or not. */
    get items(): readonly AcDbTypedValue[];
    /**
     * True when every pair was consumed and no expected value was missing, i.e.
     * the record matched the layout the reader assumed.
     */
    get isClean(): boolean;
    /**
     * Consumes the pairs of the current subclass from `filer`. When `subclass`
     * is given, the `100` marker is consumed first if present.
     */
    static read(filer: AcDbDxfFiler, subclass?: string): AcDbAssocDxfCursor;
    /** Builds a cursor over already-collected pairs. */
    static fromItems(items: AcDbTypedValue[]): AcDbAssocDxfCursor;
    get atEnd(): boolean;
    /** Group code of the next pair, or `undefined` at the end. */
    peekCode(): number | undefined;
    /** Returns the next pair and advances. */
    next(): AcDbTypedValue | undefined;
    /** Remaining pairs (not consumed). */
    rest(): AcDbTypedValue[];
    private take;
    int(code?: number, fallback?: number): number;
    double(code?: number, fallback?: number): number;
    bool(code?: number, fallback?: boolean): boolean;
    string(code?: number, fallback?: string): string;
    /** Reads a handle; `0` and empty become `''`. */
    id(codes?: readonly number[]): AcDbObjectId;
    /** Reads a handle and reports its group code (330 soft vs 360 hard). */
    idWithCode(codes?: readonly number[]): {
        id: AcDbObjectId;
        code: number;
    } | undefined;
    /** Reads a point stored as `code`, `code + 10`, `code + 20`. */
    point(code?: number): AcGePoint3d;
    /** Reads `count` consecutive values of `code`. */
    doubles(count: number, code?: number): number[];
}
/** Normalizes a DXF handle value: `0`/empty → `''`. */
export declare function acdbAssocNormalizeId(value: unknown): AcDbObjectId;
/**
 * Writes a handle the way AutoCAD does for associative records: a null id is
 * written explicitly as `0` (AutoCAD emits `330 0`, `360 0`).
 */
export declare function acdbAssocWriteId(filer: AcDbDxfFiler, code: number, id: AcDbObjectId | undefined): void;
/**
 * True when `id` resolves in the written file: an OBJECTS record of the
 * current export, or a resident entity / symbol-table record (written in
 * TABLES, BLOCKS or ENTITIES).
 */
export declare function acdbAssocIsIdWritten(filer: AcDbDxfFiler, id: AcDbObjectId | undefined): id is AcDbObjectId;
/** Writes a 4×4 matrix as 16 row-major group-40 doubles (AutoCAD order). */
export declare function acdbAssocWriteMatrix(filer: AcDbDxfFiler, elements: readonly number[], code?: number): void;
//# sourceMappingURL=acdbAssocDxf.d.ts.map