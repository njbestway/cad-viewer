import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import { AcDbObject, type AcDbObjectId } from '../../base/AcDbObject.js';
/**
 * Abstract body that implements the algorithm of an {@link AcDbAssocAction}
 * (ObjectARX `AcDbAssocActionBody`).
 *
 * Custom behaviors override {@link evaluateOverride}. The parent action owns
 * this body (it is the body's DXF owner); when the action is erased the body
 * is erased with it.
 *
 * DXF layout (`AcDbAssocActionBody` subclass): `90 classVersion (2)`.
 */
export declare abstract class AcDbAssocActionBody extends AcDbObject {
    private _actionBodyClassVersion;
    /** Owning {@link AcDbAssocAction} id (the DXF owner handle). */
    get parentActionId(): AcDbObjectId;
    set parentActionId(value: AcDbObjectId);
    /**
     * Performs the associative evaluation algorithm.
     *
     * Must be overridden by concrete action bodies.
     */
    abstract evaluateOverride(): void;
    /**
     * True when the objects this body drives no longer exist (e.g. the array
     * INSERT was erased). Orphaned actions are skipped by evaluation and DXF
     * export but kept in memory, so undo/redo of the erase restores them.
     */
    isOrphaned(): boolean;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbAssocActionBody.d.ts.map