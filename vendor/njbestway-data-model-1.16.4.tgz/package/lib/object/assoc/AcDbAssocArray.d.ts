import type { AcGeMatrix3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import type { AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import type { AcDbEntity } from '../../entity/AcDbEntity.js';
import { AcDbAssocArrayActionBody } from './AcDbAssocArrayActionBody.js';
import type { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
import type { AcDbAssocArrayParameters } from './AcDbAssocArrayParameters.js';
/**
 * Convenience wrapper around an {@link AcDbAssocArrayActionBody}
 * (AutoCAD .NET `AssocArray`).
 */
export declare class AcDbAssocArray {
    private readonly _body;
    private constructor();
    get actionBody(): AcDbAssocArrayActionBody;
    get arrayEntityId(): AcDbObjectId;
    getParameters(): AcDbAssocArrayParameters | undefined;
    getItemTransform(locator: AcDbAssocArrayItemLocator): AcGeMatrix3d;
    static createArray(sourceEntities: readonly AcDbObjectId[], basePoint: AcGePoint3dLike, parameters: AcDbAssocArrayParameters, db: AcDbDatabase): AcDbAssocArray;
    static getAssociativeArray(entity: AcDbEntity, db?: AcDbDatabase): AcDbAssocArray | undefined;
    static isAssociativeArray(entity: AcDbEntity, db?: AcDbDatabase): boolean;
}
//# sourceMappingURL=AcDbAssocArray.d.ts.map