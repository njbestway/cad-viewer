import { AcGeMatrix3d } from '@mlightcad/geometry-engine';
import type { AcDbObjectId } from '../../base/AcDbObject.js';
import { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
/** Item flag: the transform is stored (always set by AutoCAD). */
export declare const ACDB_ASSOC_ARRAY_ITEM_HAS_TRANSFORM = 8;
/** Item flag: the transform is a full matrix rather than a translation. */
export declare const ACDB_ASSOC_ARRAY_ITEM_FULL_MATRIX = 4;
/** Item flag: a relative transform follows (individually edited item). */
export declare const ACDB_ASSOC_ARRAY_ITEM_HAS_RELATIVE_TRANSFORM = 2;
/** Item flag: a second entity handle follows. */
export declare const ACDB_ASSOC_ARRAY_ITEM_HAS_SECONDARY_ENTITY = 16;
/**
 * Transform and metadata of one item of an associative array
 * (ObjectARX `AcDbAssocArrayItem`). Owned by the
 * {@link AcDbAssocArrayActionBody} and persisted with it.
 *
 * DXF layout (inside the body record): `100 AcDbAssocArrayItem, 90 0,
 * 90 itemIndex, 90 rowIndex, 90 levelIndex, 90 flags,
 * (40×16 row-major matrix | 11/21/31 translation), 330 item entity`.
 */
export declare class AcDbAssocArrayItem {
    locator: AcDbAssocArrayItemLocator;
    classVersion: number;
    /** Raw flag bits; transform-shape bits are recomputed on write. */
    flags: number;
    /** Item transform: source block space → array block space. */
    transform: AcGeMatrix3d;
    /** The item INSERT inside the array block. */
    entityId: AcDbObjectId;
    /**
     * Relative transform of an individually edited item (AutoCAD flags & 2).
     * Kept as read; not applied by evaluation.
     */
    relativeTransform: AcGeMatrix3d | undefined;
    /** Second entity handle (AutoCAD flags & 0x10), kept as read. */
    secondaryEntityId: AcDbObjectId;
    constructor(locator?: AcDbAssocArrayItemLocator, transform?: AcGeMatrix3d, entityId?: AcDbObjectId);
    /** True when the transform is a pure translation. */
    get isTranslationOnly(): boolean;
    /**
     * Flags to persist: the bits describing which data follows always match
     * the data this item holds.
     */
    get persistedFlags(): number;
}
//# sourceMappingURL=AcDbAssocArrayItem.d.ts.map