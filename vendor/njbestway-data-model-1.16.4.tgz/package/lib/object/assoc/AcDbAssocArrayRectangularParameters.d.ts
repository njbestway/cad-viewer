import { AcGeMatrix3d } from '@mlightcad/geometry-engine';
import { AcDbAssocArrayCommonParameters } from './AcDbAssocArrayCommonParameters.js';
import { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
import type { AcDbAssocArrayValueParamSpec } from './AcDbAssocArrayParameters.js';
/**
 * Rectangular associative-array parameters
 * (ObjectARX `AcDbAssocArrayRectangularParameters`).
 *
 * AutoCAD value parameters: `AlignItems`, `AxesAngle`, `ItemSpacing`
 * (column spacing), `Items` (columns), `LevelSpacing`, `Levels`,
 * `RowElevation`, `RowSpacing`, `Rows`.
 *
 * @remarks Do not subclass — AutoCAD does not support further derivation.
 */
export declare class AcDbAssocArrayRectangularParameters extends AcDbAssocArrayCommonParameters {
    private _axesAngle;
    private _alignItems;
    /**
     * @param columnSpacing - Distance between columns.
     * @param rowSpacing - Distance between rows.
     * @param levelSpacing - Distance between levels.
     * @param columnCount - Number of columns.
     * @param rowCount - Number of rows.
     * @param levelCount - Number of levels.
     * @param rowElevation - Incremental Z per row.
     * @param axesAngle - Angle between row and column axes in **radians**
     *   (ObjectARX ctor takes degrees; this TS API uses radians consistently
     *   with the rest of the geometry engine — convert at the command layer).
     */
    constructor(columnSpacing?: number, rowSpacing?: number, levelSpacing?: number, columnCount?: number, rowCount?: number, levelCount?: number, rowElevation?: number, axesAngle?: number);
    get axesAngle(): number;
    set axesAngle(value: number);
    /** AutoCAD `AlignItems` (unused by the rectangular layout; persisted). */
    get alignItems(): boolean;
    set alignItems(value: boolean);
    get parameterType(): 'rectangular';
    get className(): string;
    getItemLocators(): AcDbAssocArrayItemLocator[];
    getItemTransform(locator: AcDbAssocArrayItemLocator): AcGeMatrix3d;
    toValueParams(): AcDbAssocArrayValueParamSpec[];
    fromValueParams(get: (name: string) => number | undefined): void;
}
//# sourceMappingURL=AcDbAssocArrayRectangularParameters.d.ts.map