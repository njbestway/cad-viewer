import type { AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbAssocNetwork } from './AcDbAssocNetwork.js';
/**
 * Entry points for the associative framework (ObjectARX `AcDbAssocManager`).
 */
export declare class AcDbAssocManager {
    private constructor();
    /**
     * Returns the top-level {@link AcDbAssocNetwork} for `db` (NOD →
     * `ACAD_ASSOCNETWORK`), creating it when missing.
     */
    static getTopLevelNetwork(db: AcDbDatabase, createIfMissing?: boolean): AcDbAssocNetwork | undefined;
    /**
     * Returns every network reachable from the top-level network and from the
     * block table records' extension dictionaries.
     */
    static getAllNetworks(db: AcDbDatabase): AcDbAssocNetwork[];
    /**
     * Evaluates all dirty actions in the associative networks of `db`.
     */
    static evaluateTopLevelNetwork(db: AcDbDatabase): boolean;
    /**
     * Notifies the dependencies attached to `objectId` that the object changed
     * (they are its persistent reactors). Callers should later invoke
     * {@link evaluateTopLevelNetwork}.
     */
    static notifyObjectChanged(db: AcDbDatabase, objectId: AcDbObjectId, transitive?: boolean): void;
    /**
     * Links associative objects after a file was loaded: makes sure every
     * attached dependency is a persistent reactor of its object. DXF carries
     * the reactors; the DWG converter does not.
     */
    static linkLoadedObjects(db: AcDbDatabase): void;
}
//# sourceMappingURL=AcDbAssocManager.d.ts.map