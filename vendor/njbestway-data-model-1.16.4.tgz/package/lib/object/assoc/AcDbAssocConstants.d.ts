/**
 * Dictionary key of AutoCAD associative networks (`ACAD_ASSOCNETWORK`). Used
 * both in the named-object dictionary (top-level network) and in a space
 * block's extension dictionary (that space's network).
 */
export declare const ACDB_ASSOC_NETWORK_DICT = "ACAD_ASSOCNETWORK";
//# sourceMappingURL=AcDbAssocConstants.d.ts.map