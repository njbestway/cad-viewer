import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import { AcDbObject, type AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbAssocActionBody } from './AcDbAssocActionBody.js';
import { AcDbAssocActionParam } from './AcDbAssocActionParam.js';
import { AcDbAssocDependency } from './AcDbAssocDependency.js';
import { AcDbAssocDxfCursor } from './acdbAssocDxf.js';
import { AcDbAssocStatus } from './AcDbAssocStatus.js';
/**
 * Unit type of an action value parameter (ObjectARX `AcValue::UnitType`).
 */
export declare enum AcDbAssocValueUnitType {
    Unitless = 0,
    Distance = 1,
    Angle = 2,
    Area = 4,
    Volume = 8
}
/**
 * One value of an action value parameter. `code` is the DXF group code of
 * the value (AutoCAD stores `AcDbEvalVariant` values with their resbuf type:
 * 40 = real, 90 = int32, 1 = string, …); `code` 0 means a null value.
 */
export interface AcDbAssocValueParamValue {
    code: number;
    value: number | string;
    /** Optional `AcDbAssocVariable` id driving this value (expression). */
    variableId: AcDbObjectId;
}
/**
 * Named value parameter of an {@link AcDbAssocAction} (ObjectARX
 * `AcDbAssocAction::getValueParam` / `setValueParam`).
 */
export interface AcDbAssocValueParam {
    classVersion: number;
    name: string;
    unitType: AcDbAssocValueUnitType;
    values: AcDbAssocValueParamValue[];
    /** Dependency on the object controlling the value, if any. */
    controlledObjectDependencyId: AcDbObjectId;
}
/**
 * Fields of an {@link AcDbAssocAction} decoded from a DWG record.
 */
export interface AcDbAssocActionData {
    classVersion: number;
    status: number;
    owningNetworkId: AcDbObjectId;
    actionBodyId: AcDbObjectId;
    actionIndex: number;
    maxDependencyIndex: number;
    dependencies: {
        id: AcDbObjectId;
        isOwned: boolean;
    }[];
    ownedParamIds: AcDbObjectId[];
    valueParams: AcDbAssocValueParam[];
}
/**
 * Associative action that owns an {@link AcDbAssocActionBody}, a set of
 * {@link AcDbAssocDependency} objects, action parameters and named value
 * parameters (ObjectARX `AcDbAssocAction`).
 *
 * External code should not subclass this class; put custom logic in an
 * {@link AcDbAssocActionBody} subclass.
 *
 * DXF layout (`AcDbAssocAction` subclass, class version 2):
 * `90 ver, 90 status, 330 owningNetwork, 360 actionBody, 90 actionIndex,
 * 90 maxDependencyIndex, 90 n, (360 owned | 330 soft dependency)×n, 90 0,
 * 90 m, 360 ownedParam×m, 90 0, 90 k, valueParam×k` where a value param is
 * `90 ver, 1 name, 90 unitType, 90 v, (value, 330 variable)×v,
 * 330 controlledObjectDependency`.
 */
export declare class AcDbAssocAction extends AcDbObject {
    /** DXF/DWG record name. */
    static readonly DXF_NAME: string;
    private _classVersion;
    private _status;
    private _owningNetworkId;
    private _actionBodyId;
    private _actionIndex;
    private _maxDependencyIndex;
    private _dependencies;
    private _ownedParamIds;
    private _valueParams;
    /**
     * Verbatim `AcDbAssocAction` pairs of a record that did not match the
     * layout this reader knows (e.g. an action of another AutoCAD feature with
     * value types not modeled here). Written back unchanged until the action is
     * modified, so foreign actions survive a round trip.
     */
    private _rawActionItems;
    get actionBodyId(): AcDbObjectId;
    set actionBodyId(value: AcDbObjectId);
    get dependencyIds(): readonly AcDbObjectId[];
    get status(): AcDbAssocStatus;
    set status(value: AcDbAssocStatus);
    /** Drops the verbatim record once the action is edited. */
    private markModified;
    /** Sets the status (ObjectARX `setStatus`). */
    setStatus(value: AcDbAssocStatus): void;
    /** Network this action belongs to (soft pointer). */
    get owningNetworkId(): AcDbObjectId;
    set owningNetworkId(value: AcDbObjectId);
    /** Index of this action in its owning network. */
    get actionIndex(): number;
    set actionIndex(value: number);
    get maxDependencyIndex(): number;
    get ownedParamIds(): readonly AcDbObjectId[];
    get needsEvaluation(): boolean;
    /** True when the action body reports its driven objects are gone. */
    get isOrphaned(): boolean;
    setDirty(transitive?: boolean): void;
    setUpToDate(): void;
    /**
     * Returns the owned action body, if present in the database.
     */
    actionBody(db?: AcDbDatabase): AcDbAssocActionBody | undefined;
    /**
     * Makes `body` the action body owned by this action
     * (ObjectARX `setActionBody`). This action must be database-resident.
     */
    setActionBody(body: AcDbAssocActionBody): void;
    /**
     * Adds a dependency (ObjectARX `addDependency`). A new dependency object is
     * made database-resident and owned by this action; it receives the next
     * dependency index.
     *
     * @param dependency - Dependency object, or the id of an existing one.
     * @param setThisActionAsOwningAction - Own the dependency (DXF 360).
     */
    addDependency(dependency: AcDbAssocDependency | AcDbObjectId, setThisActionAsOwningAction?: boolean): AcDbObjectId;
    /** Low-level: records a dependency id without touching the object. */
    addDependencyId(id: AcDbObjectId, isOwned?: boolean): void;
    /** True when the action owns the dependency `id`. */
    isOwnedDependency(id: AcDbObjectId): boolean;
    /**
     * Removes a dependency (ObjectARX `removeDependency`).
     *
     * @param alsoEraseIt - Also detach and erase the dependency object.
     */
    removeDependency(id: AcDbObjectId, alsoEraseIt?: boolean): void;
    /** Low-level alias kept for callers that only track ids. */
    removeDependencyId(id: AcDbObjectId): void;
    /**
     * Returns dependencies present in the database
     * (ObjectARX `getDependencies`).
     *
     * @param readDependenciesWanted - Include read dependencies.
     * @param writeDependenciesWanted - Include write dependencies.
     */
    getDependencies(readDependenciesWanted?: boolean, writeDependenciesWanted?: boolean, db?: AcDbDatabase): AcDbAssocDependency[];
    /**
     * Returns all dependencies present in the database.
     */
    dependencies(db?: AcDbDatabase): AcDbAssocDependency[];
    /**
     * Adds an owned action parameter (ObjectARX `addParam`).
     */
    addParam(param: AcDbAssocActionParam): AcDbObjectId;
    /** Removes and erases an owned action parameter. */
    removeParam(id: AcDbObjectId): void;
    /** Owned action parameters present in the database. */
    ownedParams(db?: AcDbDatabase): AcDbAssocActionParam[];
    /** Returns the owned action parameter named `name` (ObjectARX `paramAtName`). */
    paramAtName(name: string, db?: AcDbDatabase): AcDbAssocActionParam | undefined;
    /** Names of all value parameters (ObjectARX `valueParamNames`). */
    valueParamNames(): string[];
    /** Full value-parameter record, if present. */
    valueParam(name: string): AcDbAssocValueParam | undefined;
    /** All value parameters, in file order. */
    get valueParams(): readonly AcDbAssocValueParam[];
    /**
     * Returns the (first) value of a value parameter
     * (ObjectARX `getValueParam`).
     */
    getValueParam(name: string, valueIndex?: number): number | string | undefined;
    /**
     * Sets a value parameter (ObjectARX `setValueParam`). Creates the parameter
     * when missing. Integers are stored as group 90, other numbers as group 40,
     * strings as group 1, unless `code` is given.
     */
    setValueParam(name: string, value: number | string | boolean, unitType?: AcDbAssocValueUnitType, code?: number): void;
    /** Unit type of a value parameter (ObjectARX `valueParamUnitType`). */
    valueParamUnitType(name: string): AcDbAssocValueUnitType | undefined;
    /** Removes a value parameter (ObjectARX `removeValueParam`). */
    removeValueParam(name: string): void;
    /**
     * Evaluates this action by calling {@link AcDbAssocActionBody.evaluateOverride}.
     */
    evaluate(): void;
    /**
     * Erases this action together with its body, owned dependencies and owned
     * parameters, and removes it from its owning network.
     */
    eraseAction(): void;
    getHardOwnedObjectIds(): AcDbObjectId[];
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /** Reads the positional `AcDbAssocAction` subclass data. */
    protected readActionFields(c: AcDbAssocDxfCursor): void;
    /**
     * Restores fields decoded from a DWG record.
     *
     * @internal
     */
    setActionFromDwg(data: AcDbAssocActionData): void;
}
//# sourceMappingURL=AcDbAssocAction.d.ts.map