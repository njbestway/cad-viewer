import { AcGeMatrix3d, AcGePoint3d, type AcGePoint3dLike, type AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import type { AcDbObjectId } from '../../base/AcDbObject.js';
import { AcDbBlockTableRecord } from '../../database/AcDbBlockTableRecord.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbBlockReference } from '../../entity/AcDbBlockReference.js';
import { AcDbCurve } from '../../entity/AcDbCurve.js';
import { AcDbEntity } from '../../entity/AcDbEntity.js';
import { AcDbAssocAction } from './AcDbAssocAction.js';
import { AcDbAssocActionBody } from './AcDbAssocActionBody.js';
import { AcDbAssocArrayItem } from './AcDbAssocArrayItem.js';
import { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
import { AcDbAssocArrayParameters } from './AcDbAssocArrayParameters.js';
import { type AcDbAssocArrayPathEdgeRef } from './AcDbAssocArrayPathParameters.js';
import { AcDbAssocDependency } from './AcDbAssocDependency.js';
import { type AcDbAssocEdgeLineSegment } from './AcDbAssocVertexActionParam.js';
export interface AcDbAssocArrayCreateResult {
    arrayEntityId: AcDbObjectId;
    actionBodyId: AcDbObjectId;
    actionId: AcDbObjectId;
}
/**
 * Fields of an {@link AcDbAssocArrayActionBody} decoded from a DWG record.
 */
export interface AcDbAssocArrayActionBodyData {
    actionBodyClassVersion?: number;
    classVersion: number;
    parametersClassName: string;
    parametersVersion: number;
    items: {
        classVersion: number;
        itemIndex: number;
        rowIndex: number;
        levelIndex: number;
        flags: number;
        /** Row-major 4×4 matrix (16 values). */
        matrix: number[];
        entityId: AcDbObjectId;
        /** Row-major 4×4 relative transform (flags & 2). */
        relativeMatrix?: number[];
        /** Second entity handle (flags & 0x10). */
        secondaryEntityId?: AcDbObjectId;
    }[];
    /** Row-major 4×4 array transform (16 values). */
    arrayTransform: number[];
}
/**
 * Returns the WCS transform of an array INSERT (block space → world).
 */
export declare function acdbAssocArrayInsertTransform(ref: AcDbBlockReference): AcGeMatrix3d;
/**
 * Associative action body that evaluates an array of items from parameters
 * (ObjectARX `AcDbAssocArrayActionBody`).
 *
 * The array is an INSERT of an anonymous *array block* whose entities are
 * item INSERTs of an anonymous *source block*. The body's action depends on:
 * - the array block (write),
 * - the source block (read),
 * - the array INSERT (read + write, order `-2147483648`),
 * - the path curve, for path arrays (read).
 *
 * Parameter values live on the owning action (value parameters and
 * `Origin` / `BaseNormal` / `basePoint` / `RowProfile` action parameters).
 *
 * DXF layout (`AcDbAssocArrayActionBody` subclass): `90 1,
 * 1 <parameters class name>, 90 0, 90 itemCount, 1 AcDbAssocArrayItem,
 * item×itemCount, 40×16 array transform (row-major)`.
 */
export declare class AcDbAssocArrayActionBody extends AcDbAssocActionBody {
    static readonly DXF_NAME = "ACDBASSOCARRAYACTIONBODY";
    private _classVersion;
    private _parametersClassName;
    private _parametersVersion;
    private _items;
    /** Array INSERT transform at the last evaluation (column-major). */
    private _arrayTransform;
    /** Lazily built from the owning action; see {@link parameters}. */
    private _parameters;
    /** Owning action, if resident. */
    get action(): AcDbAssocAction | undefined;
    private findDependency;
    /** Dependency on the array INSERT (read + write). */
    get arrayEntityDependency(): AcDbAssocDependency | undefined;
    /** True when the array INSERT no longer exists (erased). */
    isOrphaned(): boolean;
    /** Object id of the array INSERT (ObjectARX `getArrayEntity`). */
    get arrayEntityId(): AcDbObjectId;
    /** The array INSERT, if resident. */
    getArrayEntity(): AcDbBlockReference | undefined;
    /** The source block (read-only block dependency). */
    get sourceBlock(): AcDbBlockTableRecord | undefined;
    /** The array block (write-only block dependency). */
    get arrayBlock(): AcDbBlockTableRecord | undefined;
    get sourceBlockName(): string;
    get arrayBlockName(): string;
    /** Entities of the source block (ObjectARX `getSourceEntities`). */
    get sourceEntityIds(): AcDbObjectId[];
    /** Path curve of a path array, if resident. */
    getPathCurve(): AcDbCurve | undefined;
    /** Items of the last evaluation. */
    get items(): readonly AcDbAssocArrayItem[];
    /** Item at `locator` (ObjectARX `getItemAt`). */
    getItemAt(locator: AcDbAssocArrayItemLocator): AcDbAssocArrayItem | undefined;
    /** C++ class name of the parameters stored in DXF/DWG. */
    get parametersClassName(): string;
    /** Array INSERT transform recorded at the last evaluation. */
    get arrayTransform(): AcGeMatrix3d;
    /**
     * Array parameters (ObjectARX `parameters`). Built from the owning action's
     * value and point parameters on first access.
     */
    get parameters(): AcDbAssocArrayParameters | undefined;
    /**
     * Replaces the parameters and writes them to the owning action
     * (ObjectARX `setParameters`).
     */
    setParameters(parameters: AcDbAssocArrayParameters): void;
    private loadParametersFromAction;
    /**
     * Writes the parameters into the owning action's value and point
     * parameters (AutoCAD's persistent form).
     */
    syncParametersToAction(): void;
    /**
     * Returns whether `entity` is the INSERT of an associative array
     * (ObjectARX `isAssociativeArray`).
     */
    static isAssociativeArray(entity: AcDbEntity, db?: AcDbDatabase): boolean;
    /**
     * Returns the action body controlling the associative-array INSERT
     * `entity`, found through the entity's persistent reactors (its
     * dependencies), like AutoCAD.
     */
    static getAssociativeArray(entity: AcDbEntity, db?: AcDbDatabase): AcDbAssocArrayActionBody | undefined;
    /** Alias of {@link getAssociativeArray} (ObjectARX naming). */
    static getControllingActionBody(entity: AcDbEntity, db?: AcDbDatabase): AcDbAssocArrayActionBody | undefined;
    /**
     * Creates an associative array from source entities
     * (`AcDbAssocArrayActionBody::createInstance`), in AutoCAD's layout.
     *
     * - Rectangular: the array INSERT sits at `basePoint`.
     * - Polar: the INSERT is at the origin; set `parameters.center` (WCS)
     *   first. Radius and start angle are derived from `basePoint`.
     * - Path: the INSERT is at the origin; call `parameters.setPath` first.
     *   Item 0 lands on the path start; with aligned items the source block is
     *   authored in the tangent frame there.
     *
     * @returns Object ids of the array INSERT and the new action body / action.
     */
    static createInstance(sourceEntityIds: readonly AcDbObjectId[], basePoint: AcGePoint3dLike, parameters: AcDbAssocArrayParameters, db: AcDbDatabase): AcDbAssocArrayCreateResult;
    /** WCS → array block transform of the array INSERT. */
    private worldToArray;
    private bindPathCurve;
    /**
     * Returns the transform for one array item (source block → array block).
     */
    getTransform(locator: AcDbAssocArrayItemLocator): AcGeMatrix3d;
    /**
     * Rebuilds every item INSERT inside the array block and the item list.
     */
    evaluateOverride(): void;
    /**
     * Updates common count/spacing and marks the owning action dirty.
     */
    setRowColumnLevel(rows?: number, columns?: number, levels?: number): void;
    markDirty(): void;
    /**
     * Grip indices for associative-array INSERTs:
     * - `0` — base point (first item)
     * - `1` — primary-axis count grip (columns / items)
     * - `2` — secondary-axis count grip (rows), rectangular only
     */
    static readonly GRIP_BASE = 0;
    static readonly GRIP_PRIMARY = 1;
    static readonly GRIP_SECONDARY = 2;
    private itemWorldPoint;
    /**
     * Returns WCS grip points for the associative-array INSERT `ref`.
     */
    getGripPoints(ref: AcDbBlockReference): AcGePoint3d[];
    /**
     * Applies a grip drag to array parameters or the INSERT position, then
     * re-evaluates the array block.
     */
    moveGripPointsAt(ref: AcDbBlockReference, indices: number[], offset: AcGeVector3dLike): void;
    /**
     * Explodes this associative array into independent entity copies (AutoCAD
     * EXPLODE on an associative array). Erasing the INSERT afterwards orphans
     * the action, which is then dropped from evaluation and DXF export.
     *
     * @param _ref - The array INSERT being exploded (reserved for future use).
     * @param insertTransform - WCS transform of the array INSERT
     *   (`AcDbBlockReference.getExplodeTransform`).
     * @returns Leaf entities in WCS, or `undefined` on failure.
     */
    explodeToEntities(_ref: AcDbBlockReference, insertTransform: AcGeMatrix3d): AcDbEntity[] | undefined;
    /**
     * Erases this action body with its action, dependencies and parameters,
     * detaching the dependencies from the array INSERT, blocks and path.
     */
    disassociate(): void;
    getHardOwnedObjectIds(): AcDbObjectId[];
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Restores fields decoded from a DWG record.
     *
     * @internal
     */
    setFromDwg(data: AcDbAssocArrayActionBodyData): void;
}
/**
 * Returns the line segments of `curve` (WCS) when it is made only of straight
 * segments, for the `RowProfile` cached curve; otherwise `undefined`.
 */
export declare function acdbAssocLineSegmentsOf(curve: AcDbCurve): AcDbAssocEdgeLineSegment[] | undefined;
export type { AcDbAssocArrayPathEdgeRef };
//# sourceMappingURL=AcDbAssocArrayActionBody.d.ts.map