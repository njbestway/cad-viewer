import { AcGeMatrix3d } from '@mlightcad/geometry-engine';
import type { AcDbCurve } from '../../entity/AcDbCurve.js';
import { AcDbAssocArrayCommonParameters } from './AcDbAssocArrayCommonParameters.js';
import { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
import type { AcDbAssocArrayValueParamSpec } from './AcDbAssocArrayParameters.js';
/**
 * Path-array distribution method (ObjectARX
 * `AcDbAssocArrayPathParameters::Method`).
 */
export declare enum AcDbAssocArrayPathMethod {
    /** Place items at a fixed spacing along the path. */
    kMeasure = 0,
    /** Divide the path into equal segments for the item count. */
    kDivide = 1
}
/**
 * Soft reference to a path curve entity.
 */
export interface AcDbAssocArrayPathEdgeRef {
    entityId: string;
}
/**
 * Path associative-array parameters
 * (ObjectARX `AcDbAssocArrayPathParameters`).
 *
 * AutoCAD value parameters: `ItemSpacing`, `Items`, `LevelSpacing`,
 * `Levels`, `RowElevation`, `RowSpacing`, `Rows`, `AlignItems`, `FillPath`,
 * `MaintainZ`, `Orientation`, `TangentOrientationAngle`. The path is the
 * `RowProfile` edge parameter and its dependency.
 *
 * Item i is placed at the path point at distance `dᵢ`; with
 * {@link alignItems} it is rotated to the path tangent there. The source
 * block is authored in the frame of item 0, as in AutoCAD.
 *
 * AutoCAD persists the measure method only: a divide array is written as a
 * measure array whose spacing is `length / (n - 1)`.
 *
 * @remarks Do not subclass — AutoCAD does not support further derivation.
 */
export declare class AcDbAssocArrayPathParameters extends AcDbAssocArrayCommonParameters {
    private _method;
    private _itemSpacing;
    private _alignItems;
    private _maintainZ;
    private _fillPath;
    private _orientation;
    private _tangentOrientationAngle;
    private _path;
    /**
     * Runtime path curve used when evaluating transforms. Not persisted; the
     * action body resolves it from the path dependency before evaluation.
     */
    private _pathCurve;
    /** World → array-block transform applied to path geometry. */
    private _worldToArray;
    constructor(itemSpacing?: number, rowSpacing?: number, levelSpacing?: number, itemCount?: number, rowCount?: number, levelCount?: number, rowElevation?: number);
    get method(): AcDbAssocArrayPathMethod;
    set method(value: AcDbAssocArrayPathMethod);
    get itemSpacing(): number;
    set itemSpacing(value: number);
    get alignItems(): boolean;
    set alignItems(value: boolean);
    get maintainZ(): boolean;
    set maintainZ(value: boolean);
    /**
     * AutoCAD `FillPath`: with the measure method, the item count follows the
     * path length (`floor(length / spacing) + 1`).
     */
    get fillPath(): boolean;
    set fillPath(value: boolean);
    /** AutoCAD `Orientation` (persisted as-is). */
    get orientation(): number;
    set orientation(value: number);
    /** AutoCAD `TangentOrientationAngle`, radians (persisted as-is). */
    get tangentOrientationAngle(): number;
    set tangentOrientationAngle(value: number);
    get path(): AcDbAssocArrayPathEdgeRef | undefined;
    setPath(edge: AcDbAssocArrayPathEdgeRef): void;
    /**
     * Binds the live curve used by {@link getItemTransform}.
     *
     * @param worldToArray - Transform from world to array-block coordinates
     *   (inverse of the array INSERT transform). Identity when omitted.
     */
    setPathCurve(curve: AcDbCurve | undefined, worldToArray?: AcGeMatrix3d): void;
    get parameterType(): 'path';
    get className(): string;
    /** Path length, or 0 when no curve is bound. */
    pathLength(): number;
    /** Item count actually placed on the bound path. */
    effectiveItemCount(): number;
    getItemLocators(): AcDbAssocArrayItemLocator[];
    private toArray;
    private pointAtDistance;
    private tangentAtDistance;
    /** Distance along the path of item `index`. */
    distanceOfItem(index: number): number;
    /**
     * Item frame on the path (array-block coordinates) without the source
     * offset: translation to the path point, rotated to the tangent when
     * aligned. Item 0's frame is how the source block is authored.
     */
    getItemTransform(locator: AcDbAssocArrayItemLocator): AcGeMatrix3d;
    /**
     * Frame of item 0 (used to author the source block when the array is
     * created).
     */
    getFirstItemFrame(): AcGeMatrix3d;
    toValueParams(): AcDbAssocArrayValueParamSpec[];
    fromValueParams(get: (name: string) => number | undefined): void;
}
//# sourceMappingURL=AcDbAssocArrayPathParameters.d.ts.map