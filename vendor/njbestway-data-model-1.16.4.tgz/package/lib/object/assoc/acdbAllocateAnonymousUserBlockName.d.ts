import { AcDbBlockTableRecord } from '../../database/AcDbBlockTableRecord.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
/**
 * Allocates the next free anonymous user block name (`*U{n}`).
 *
 * @param db - Database whose block table is scanned.
 * @returns A `*U{n}` name one greater than the largest existing one.
 */
export declare function acdbAllocateAnonymousUserBlockName(db: AcDbDatabase): string;
/**
 * Creates a new anonymous `*U` {@link AcDbBlockTableRecord} and adds it to
 * the block table.
 */
export declare function acdbCreateAnonymousUserBlock(db: AcDbDatabase, name?: string): AcDbBlockTableRecord;
//# sourceMappingURL=acdbAllocateAnonymousUserBlockName.d.ts.map