import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import { AcDbObject, type AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbTypedValue } from '../../base/AcDbTypedValue.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbAssocDependency } from './AcDbAssocDependency.js';
/**
 * Base class of named parameters owned by an {@link AcDbAssocAction}
 * (ObjectARX `AcDbAssocActionParam`).
 *
 * DXF layout (`AcDbAssocActionParam` subclass): `90 classVersion (1),
 * 90 0, 1 name`.
 */
export declare class AcDbAssocActionParam extends AcDbObject {
    /** DXF/DWG record name. */
    static readonly DXF_NAME: string;
    private _paramClassVersion;
    private _paramFlags;
    private _name;
    constructor(name?: string);
    /** Parameter name (e.g. `Origin`, `BaseNormal`, `RowProfile`). */
    get name(): string;
    set name(value: string);
    /** Owning action id (the DXF owner handle). */
    get owningActionId(): AcDbObjectId;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /** @internal Restores base fields decoded from DWG. */
    setParamFromDwg(data: {
        classVersion: number;
        flags: number;
        name: string;
    }): void;
}
/**
 * Action parameter that keeps one {@link AcDbAssocDependency}
 * (ObjectARX `AcDbAssocSingleDependencyActionParam`).
 *
 * DXF layout: `100 AcDbAssocSingleDependencyActionParam, 90 0,
 * 330 dependency`.
 */
export declare class AcDbAssocSingleDependencyActionParam extends AcDbAssocActionParam {
    static readonly DXF_NAME: string;
    private _singleDepClassVersion;
    private _dependencyId;
    /** Id of the dependency this parameter uses (may be empty). */
    get dependencyId(): AcDbObjectId;
    set dependencyId(value: AcDbObjectId);
    /** The dependency object, if resident. */
    dependency(db?: AcDbDatabase): AcDbAssocDependency | undefined;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /** @internal Restores single-dependency fields decoded from DWG. */
    setSingleDependencyFromDwg(data: {
        classVersion: number;
        dependencyId: AcDbObjectId;
    }): void;
}
/**
 * Writes raw pairs captured by {@link AcDbAssocDxfCursor.rest}.
 *
 * @internal
 */
export declare function acdbAssocWriteRawItems(filer: AcDbDxfFiler, items: readonly AcDbTypedValue[]): void;
//# sourceMappingURL=AcDbAssocActionParam.d.ts.map