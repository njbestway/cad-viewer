/**
 * Indexes one item in an associative array
 * (ObjectARX `AcDbItemLocator` / .NET `ItemLocator`).
 *
 * - Rectangular: item = column, row, level
 * - Polar: item = angular index, row, level
 * - Path: item = path index, row, level
 */
export declare class AcDbAssocArrayItemLocator {
    itemIndex: number;
    rowIndex: number;
    levelIndex: number;
    constructor(itemIndex?: number, rowIndex?: number, levelIndex?: number);
    equals(other: AcDbAssocArrayItemLocator): boolean;
    clone(): AcDbAssocArrayItemLocator;
    toKey(): string;
    static fromKey(key: string): AcDbAssocArrayItemLocator;
}
//# sourceMappingURL=AcDbAssocArrayItemLocator.d.ts.map