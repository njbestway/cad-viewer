import { AcGeMatrix3d, AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbAssocArrayCommonParameters } from './AcDbAssocArrayCommonParameters.js';
import { AcDbAssocArrayItemLocator } from './AcDbAssocArrayItemLocator.js';
import type { AcDbAssocArrayValueParamSpec } from './AcDbAssocArrayParameters.js';
/**
 * Polar associative-array parameters
 * (ObjectARX `AcDbAssocArrayPolarParameters`).
 *
 * AutoCAD value parameters: `FillAngle`, `ItemSpacing` (angle between items),
 * `Items`, `LevelSpacing`, `Levels`, `RowElevation`, `RowSpacing`, `Rows`,
 * `Radius`, `StartAngle`; the center is the `Origin` point parameter.
 * Clockwise arrays store negative angles.
 *
 * Item 0 is placed at `center + radius·(cos startAngle, sin startAngle)`;
 * item i is item 0 rotated by `i · angleBetweenItems` about the center.
 *
 * @remarks Do not subclass — AutoCAD does not support further derivation.
 */
export declare class AcDbAssocArrayPolarParameters extends AcDbAssocArrayCommonParameters {
    private _angleBetweenItems;
    private _fillAngle;
    private _rotateItems;
    private _direction;
    private _radius;
    private _startAngle;
    /**
     * @param angleBetweenItems - Angle between items in radians
     *   (ObjectARX ctor first arg is degrees).
     * @param rowSpacing - Radial row spacing.
     * @param levelSpacing - Level spacing.
     * @param itemCount - Number of items around the center.
     * @param rowCount - Number of radial rows.
     * @param levelCount - Number of levels.
     * @param rowElevation - Z elevation per row.
     */
    constructor(angleBetweenItems?: number, rowSpacing?: number, levelSpacing?: number, itemCount?: number, rowCount?: number, levelCount?: number, rowElevation?: number);
    /** Positive angle between adjacent items, in radians. */
    get angleBetweenItems(): number;
    set angleBetweenItems(value: number);
    /**
     * Total angle filled by the array, in radians. A full circle (2π) spaces
     * items by `fill / n`; any other fill by `fill / (n - 1)` (AutoCAD).
     */
    get fillAngle(): number;
    set fillAngle(value: number);
    get itemCount(): number;
    set itemCount(value: number);
    private get isFullCircle();
    private updateSpacingFromFill;
    get rotateItems(): boolean;
    set rotateItems(value: boolean);
    /** `1` = CCW, `-1` = CW. */
    get direction(): number;
    set direction(value: number);
    /** Array center in array-block coordinates (AutoCAD `Origin`). */
    get center(): AcGePoint3d;
    set center(value: AcGePoint3d);
    /** Distance from the center to item 0 (AutoCAD `Radius`). */
    get radius(): number;
    set radius(value: number);
    /** Angle of item 0 around the center, in radians (AutoCAD `StartAngle`). */
    get startAngle(): number;
    set startAngle(value: number);
    /**
     * Sets {@link radius} and {@link startAngle} so item 0 sits at `point`
     * (array-block coordinates).
     */
    setFirstItemPosition(point: {
        x: number;
        y: number;
    }): void;
    get parameterType(): 'polar';
    get className(): string;
    getItemLocators(): AcDbAssocArrayItemLocator[];
    getItemTransform(locator: AcDbAssocArrayItemLocator): AcGeMatrix3d;
    toValueParams(): AcDbAssocArrayValueParamSpec[];
    fromValueParams(get: (name: string) => number | undefined): void;
}
//# sourceMappingURL=AcDbAssocArrayPolarParameters.d.ts.map