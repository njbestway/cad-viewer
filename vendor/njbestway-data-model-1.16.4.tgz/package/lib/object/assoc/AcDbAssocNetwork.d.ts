import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import type { AcDbObject, AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbAssocAction } from './AcDbAssocAction.js';
/**
 * Network of associative actions (ObjectARX `AcDbAssocNetwork`).
 *
 * Itself an {@link AcDbAssocAction}, so networks nest. AutoCAD keeps:
 * - a database (top-level) network:
 *   NOD → `ACAD_ASSOCNETWORK` dictionary → `ACAD_ASSOCNETWORK` → network;
 * - one network per space block:
 *   BTR extension dictionary → `ACAD_ASSOCNETWORK` dictionary →
 *   `ACAD_ASSOCNETWORK` → network. It owns the actions of that space and is
 *   referenced (not owned) by the top-level network.
 *
 * DXF layout (`AcDbAssocNetwork` subclass): `90 0, 90 maxActionIndex, 90 n,
 * (360 owned | 330 soft action)×n, 90 m, (330 owned action)×m`.
 */
export declare class AcDbAssocNetwork extends AcDbAssocAction {
    static readonly DXF_NAME: string;
    private _networkClassVersion;
    private _maxActionIndex;
    private _actions;
    private _ownedActionIds;
    get actionIds(): readonly AcDbObjectId[];
    get maxActionIndex(): number;
    /**
     * Returns the network stored under `dictionaryKey` in the extension
     * dictionary of `owner` (usually a space block table record), creating it
     * when requested (ObjectARX `AcDbAssocNetwork::getInstanceFromObject`).
     *
     * @param addToTopLevelNetwork - Reference a new network from the
     *   database's top-level network.
     */
    static getInstanceFromObject(owner: AcDbObject, createIfDoesNotExist?: boolean, addToTopLevelNetwork?: boolean, dictionaryKey?: string): AcDbAssocNetwork | undefined;
    /**
     * Returns the database's top-level network
     * (ObjectARX `AcDbAssocNetwork::getInstanceFromDatabase`).
     */
    static getInstanceFromDatabase(db: AcDbDatabase, createIfDoesNotExist?: boolean, dictionaryKey?: string): AcDbAssocNetwork | undefined;
    private static getOrCreateInDictionary;
    /**
     * Adds an action to this network (ObjectARX `addAction`).
     *
     * @param action - The action (or its id when already resident).
     * @param alsoSetAsDatabaseOwner - Own the action (DXF 360). Pass `false`
     *   for an action owned elsewhere, e.g. a space network referenced by the
     *   top-level network.
     */
    addAction(action: AcDbAssocAction | AcDbObjectId, alsoSetAsDatabaseOwner?: boolean): void;
    /**
     * Removes an action (ObjectARX `removeAction`).
     *
     * @param alsoEraseIt - Also erase the action with its body and owned
     *   dependencies.
     */
    removeAction(actionId: AcDbObjectId, alsoEraseIt?: boolean): void;
    /** Actions of this network that are resident (ObjectARX `getActions`). */
    actions(db?: AcDbDatabase): AcDbAssocAction[];
    /** Alias of {@link actions} matching ObjectARX naming. */
    getActions(db?: AcDbDatabase): AcDbAssocAction[];
    /**
     * Evaluates owned actions that need evaluation (depth-first for nested
     * networks).
     */
    evaluate(): void;
    getHardOwnedObjectIds(): AcDbObjectId[];
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Restores network fields decoded from a DWG record.
     *
     * @internal
     */
    setNetworkFromDwg(data: {
        networkClassVersion: number;
        maxActionIndex: number;
        actions: {
            id: AcDbObjectId;
            isOwned: boolean;
        }[];
        ownedActionIds: AcDbObjectId[];
    }): void;
}
//# sourceMappingURL=AcDbAssocNetwork.d.ts.map