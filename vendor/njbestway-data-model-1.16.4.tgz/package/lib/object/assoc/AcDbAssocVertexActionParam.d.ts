import { AcGePoint3d, type AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import { AcDbAssocSingleDependencyActionParam } from './AcDbAssocActionParam.js';
/**
 * Action parameter that holds a point
 * (ObjectARX `AcDbAssocVertexActionParam`). Associative arrays use it for
 * `Origin`, `BaseNormal` and `basePoint`.
 *
 * DXF layout: `100 AcDbAssocVertexActionParam, 90 0, 10/20/30 point`.
 */
export declare class AcDbAssocVertexActionParam extends AcDbAssocSingleDependencyActionParam {
    static readonly DXF_NAME: string;
    private _vertexClassVersion;
    private _point;
    constructor(name?: string, point?: AcGePoint3dLike);
    get point(): AcGePoint3d;
    set point(value: AcGePoint3dLike);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /** @internal Restores vertex fields decoded from DWG. */
    setVertexFromDwg(data: {
        classVersion: number;
        point: AcGePoint3dLike;
    }): void;
}
/** AcGe entity id of a 3d line segment (`AcGe::kLineSeg3d`). */
export declare const ACGE_LINE_SEG_3D = 23;
/** AcGe entity id of a 3d composite curve (`AcGe::kCompositeCrv3d`). */
export declare const ACGE_COMPOSITE_CRV_3D = 47;
/** Line segment of an edge parameter's cached curve. */
export interface AcDbAssocEdgeLineSegment {
    start: AcGePoint3d;
    end: AcGePoint3d;
}
/**
 * Action parameter that references an edge (curve) and caches its geometry
 * (ObjectARX `AcDbAssocEdgeActionParam`). Path arrays use it as
 * `RowProfile`.
 *
 * DXF layout: `100 AcDbAssocEdgeActionParam, 90 0, 330 0, 290 hasCurve,
 * [cached AcGe curve]`. A cached composite curve of line segments is
 * `90 47, 90 n, (90 23, 10 start, 10 direction)×n`. Other cached curve kinds
 * are preserved verbatim.
 */
export declare class AcDbAssocEdgeActionParam extends AcDbAssocSingleDependencyActionParam {
    static readonly DXF_NAME: string;
    private _edgeClassVersion;
    private _edgeRefId;
    private _hasCachedCurve;
    /** Raw cached-curve pairs (after the `290` flag). */
    private _curveItems;
    /** True when the parameter carries a cached curve. */
    get hasCachedCurve(): boolean;
    /**
     * Returns the cached curve as line segments when it is a composite curve of
     * line segments (or a single line segment); otherwise `undefined`.
     */
    getCachedLineSegments(): AcDbAssocEdgeLineSegment[] | undefined;
    /**
     * Caches a composite curve made of line segments. Pass `undefined` (or an
     * empty list) to clear the cache.
     */
    setCachedLineSegments(segments: readonly AcDbAssocEdgeLineSegment[] | undefined): void;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /** @internal Restores edge fields decoded from DWG. */
    setEdgeFromDwg(data: {
        classVersion: number;
        segments?: AcDbAssocEdgeLineSegment[];
    }): void;
}
//# sourceMappingURL=AcDbAssocVertexActionParam.d.ts.map