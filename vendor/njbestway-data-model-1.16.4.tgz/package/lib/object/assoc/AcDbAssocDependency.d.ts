import { AcDbDxfFiler } from '../../base/AcDbDxfFiler.js';
import { AcDbObject, type AcDbObjectId } from '../../base/AcDbObject.js';
import type { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbAssocStatus } from './AcDbAssocStatus.js';
/**
 * Fields of an {@link AcDbAssocDependency} decoded from a DWG record.
 */
export interface AcDbAssocDependencyData {
    classVersion: number;
    status: number;
    isReadDependency: boolean;
    isWriteDependency: boolean;
    isAttachedToObject: boolean;
    isDelegatingToOwningAction: boolean;
    order: number;
    name: string;
    dependentOnObjectId: AcDbObjectId;
    prevDependencyOnObjectId?: AcDbObjectId;
    nextDependencyOnObjectId?: AcDbObjectId;
    dependencyBodyId: AcDbObjectId;
    dependencyIndex: number;
}
/**
 * Records that an {@link AcDbAssocAction} reads and/or writes an `AcDbObject`
 * (ObjectARX `AcDbAssocDependency`).
 *
 * The dependency is owned by its action (DXF owner handle). When attached to
 * its object it is a persistent reactor of that object, which is how AutoCAD
 * finds the actions that depend on an entity (`102 {ACAD_REACTORS`).
 *
 * DXF layout (`AcDbAssocDependency` subclass, class version 2):
 * `90 ver, 90 status, 290 isRead, 290 isWrite, 290 isAttached,
 * 290 isDelegating, 90 order, 330 dependentOn, 290 hasName, [1 name],
 * 330 prevDependencyOnObject, 330 nextDependencyOnObject, 360 dependencyBody,
 * 90 dependencyIndex`.
 */
export declare class AcDbAssocDependency extends AcDbObject {
    /** DXF/DWG record name. */
    static readonly DXF_NAME = "ACDBASSOCDEPENDENCY";
    private _classVersion;
    private _status;
    private _isReadDependency;
    private _isWriteDependency;
    private _isAttachedToObject;
    private _isDelegatingToOwningAction;
    private _order;
    private _dependentOnObjectId;
    private _name;
    private _prevDependencyOnObjectId;
    private _nextDependencyOnObjectId;
    private _dependencyBodyId;
    private _dependencyIndex;
    /** Object id of the object this dependency depends on. */
    get dependentOnObjectId(): AcDbObjectId;
    set dependentOnObjectId(value: AcDbObjectId);
    get isReadDependency(): boolean;
    set isReadDependency(value: boolean);
    get isWriteDependency(): boolean;
    set isWriteDependency(value: boolean);
    /** True when this dependency is a persistent reactor of its object. */
    get isAttachedToObject(): boolean;
    get isDelegatingToOwningAction(): boolean;
    set isDelegatingToOwningAction(value: boolean);
    /**
     * Evaluation order among dependencies on the same object. AutoCAD uses
     * `-2147483648` for the array INSERT dependency of an associative array.
     */
    get order(): number;
    set order(value: number);
    get name(): string;
    set name(value: string);
    get status(): AcDbAssocStatus;
    set status(value: AcDbAssocStatus);
    /** Index assigned by the owning action ({@link AcDbAssocAction.addDependency}). */
    get dependencyIndex(): number;
    set dependencyIndex(value: number);
    get dependencyBodyId(): AcDbObjectId;
    set dependencyBodyId(value: AcDbObjectId);
    get prevDependencyOnObjectId(): AcDbObjectId;
    get nextDependencyOnObjectId(): AcDbObjectId;
    /** Owning action id (the DXF owner handle). */
    get owningActionId(): AcDbObjectId;
    set owningActionId(value: AcDbObjectId);
    get needsEvaluation(): boolean;
    /**
     * Returns the object this dependency depends on, if resident.
     */
    dependentOnObject(db?: AcDbDatabase): AcDbObject | undefined;
    /**
     * Makes this dependency depend on `objectId` and attaches it to the object
     * as a persistent reactor (ObjectARX `attachToObject`).
     */
    attachToObject(objectId: AcDbObjectId, object?: AcDbObject): void;
    /** Removes this dependency from its object's persistent reactors. */
    detachFromObject(): void;
    /**
     * Re-adds the persistent reactor on the dependent-on object after loading
     * (the DWG converter does not carry reactors; DXF does).
     */
    relinkReactor(): void;
    /**
     * Marks this dependency dirty.
     */
    setDirty(transitive?: boolean): void;
    setUpToDate(): void;
    getHardOwnedObjectIds(): AcDbObjectId[];
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Restores fields decoded from a DWG record.
     *
     * @internal
     */
    setFromDwg(data: AcDbAssocDependencyData): void;
}
//# sourceMappingURL=AcDbAssocDependency.d.ts.map