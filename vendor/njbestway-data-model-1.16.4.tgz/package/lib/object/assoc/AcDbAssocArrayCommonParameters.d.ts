import { AcGePoint3d, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcDbAssocValueUnitType } from './AcDbAssocAction.js';
import { AcDbAssocArrayParameters, type AcDbAssocArrayValueParamSpec } from './AcDbAssocArrayParameters.js';
/**
 * Parameters shared by rectangular, polar, and path arrays
 * (ObjectARX `AcDbAssocArrayCommonParameters`).
 *
 * AutoCAD value-parameter names: `Items`, `ItemSpacing`, `Rows`,
 * `RowSpacing`, `RowElevation`, `Levels`, `LevelSpacing`; point parameters
 * `Origin`, `BaseNormal`, `basePoint`.
 */
export declare abstract class AcDbAssocArrayCommonParameters extends AcDbAssocArrayParameters {
    protected _rowCount: number;
    protected _columnCount: number;
    protected _levelCount: number;
    protected _rowSpacing: number;
    protected _columnSpacing: number;
    protected _levelSpacing: number;
    protected _rowElevation: number;
    /** Array origin in array-block coordinates (`Origin` action param). */
    protected _origin: AcGePoint3d;
    /** Array plane normal (`BaseNormal` action param). */
    protected _baseNormal: AcGeVector3d;
    /** Base point in source-block coordinates (`basePoint` action param). */
    protected _basePoint: AcGePoint3d;
    get rowCount(): number;
    set rowCount(value: number);
    get columnCount(): number;
    set columnCount(value: number);
    get levelCount(): number;
    set levelCount(value: number);
    get rowSpacing(): number;
    set rowSpacing(value: number);
    get columnSpacing(): number;
    set columnSpacing(value: number);
    get levelSpacing(): number;
    set levelSpacing(value: number);
    get rowElevation(): number;
    set rowElevation(value: number);
    /** Item count along the primary axis (columns / polar items / path items). */
    get itemCount(): number;
    set itemCount(value: number);
    /**
     * Array origin in array-block coordinates (AutoCAD `Origin` parameter).
     * For polar arrays this is the center.
     */
    get origin(): AcGePoint3d;
    set origin(value: AcGePoint3d);
    get baseNormal(): AcGeVector3d;
    set baseNormal(value: AcGeVector3d);
    /** Base point in source-block coordinates (AutoCAD `basePoint`). */
    get basePoint(): AcGePoint3d;
    set basePoint(value: AcGePoint3d);
    /**
     * Common value parameters in AutoCAD's order. `itemSpacing` is the
     * type-specific `ItemSpacing` value (distance or angle).
     */
    protected commonValueParams(itemSpacing: number, itemSpacingUnit: AcDbAssocValueUnitType): AcDbAssocArrayValueParamSpec[];
    /**
     * Restores common values; returns the `ItemSpacing` value, if present.
     */
    protected commonFromValueParams(get: (name: string) => number | undefined): number | undefined;
}
//# sourceMappingURL=AcDbAssocArrayCommonParameters.d.ts.map