import { AcDbDuplicateRecordCloning } from '../base/AcDbDuplicateRecordCloning.js';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
import { AcDbResultBuffer } from '../base/AcDbResultBuffer.js';
export { AcDbDuplicateRecordCloning };
/**
 * Represents an Xrecord object used to store arbitrary
 * application-defined data.
 *
 * @remarks
 * An Xrecord is typically stored in an extension dictionary
 * and contains an {@link AcDbResultBuffer}.
 */
export declare class AcDbXrecord extends AcDbObject {
    private _data;
    /** Duplicate-record cloning flag read from/written to DXF group 280. */
    private _cloningFlag?;
    /**
     * Gets or sets the data stored in this Xrecord.
     *
     * @remarks
     * Equivalent to the Xrecord.Data property in AutoCAD .NET.
     */
    get data(): AcDbResultBuffer | null;
    set data(value: AcDbResultBuffer | null);
    /**
     * Removes all data from this Xrecord.
     */
    clear(): void;
    /**
     * Creates a deep copy of this Xrecord.
     *
     * @remarks
     * The cloned Xrecord contains a cloned ResultBuffer.
     */
    clone(): this;
    /**
     * Returns the duplicate record cloning behavior for this Xrecord.
     *
     * @remarks
     * This method exists for API parity with ObjectARX.
     */
    getDuplicateRecordCloning(): AcDbDuplicateRecordCloning;
    /**
     * Sets the duplicate record cloning behavior for this Xrecord
     * (DXF group 280).
     */
    setDuplicateRecordCloning(value: AcDbDuplicateRecordCloning): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbXrecord.d.ts.map