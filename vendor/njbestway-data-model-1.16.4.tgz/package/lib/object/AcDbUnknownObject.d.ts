import type { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
import { type AcDbDxfRawTags } from '../dxf/AcDbDxfRawTags.js';
/**
 * An OBJECTS-section record whose DXF type has no native implementation
 * (for example `PLOTSETTINGS`, `MATERIAL`, `VISUALSTYLE`, `TABLESTYLE`,
 * `ACDBPLACEHOLDER`, `RASTERVARIABLES`, `DIMASSOC` or third-party classes).
 *
 * Like ezdxf's `DXFTagStorage`, the record's tags are kept verbatim and
 * written back by `dxfOut` so references to it (dictionary entries, entity
 * material / plot-style handles, …) stay valid after a round trip.
 */
export declare class AcDbUnknownObject extends AcDbObject {
    private _dxfTypeName;
    private _rawTags;
    constructor(dxfTypeName?: string);
    /** DXF record type name (group 0), e.g. `MATERIAL`. */
    get dxfTypeName(): string;
    /** Tags captured from the source DXF, excluding handle, owner and XData. */
    get rawTags(): Readonly<AcDbDxfRawTags>;
    dxfIn(filer: AcDbDxfFiler): this;
    dxfOut(...args: unknown[]): unknown;
}
//# sourceMappingURL=AcDbUnknownObject.d.ts.map