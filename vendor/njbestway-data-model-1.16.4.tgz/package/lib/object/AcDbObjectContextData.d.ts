import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbObject } from '../base/AcDbObject.js';
import { type AcDbDxfRawTags } from '../dxf/AcDbDxfRawTags.js';
/**
 * Base class for per-context representation data
 * (`AcDbObjectContextData` in AutoCAD ObjectARX).
 */
export declare class AcDbObjectContextData extends AcDbObject {
    private _classVersion;
    private _isDefault;
    private _dxfRecordName?;
    private _dxfRawTags?;
    /**
     * DXF record type name this object was read as, e.g.
     * `ACDB_ALDIMOBJECTCONTEXTDATA_CLASS`. Several record types share one
     * class, so the name is kept for export.
     */
    get dxfRecordName(): string | undefined;
    set dxfRecordName(value: string | undefined);
    /**
     * Keeps the tags read from DXF so export reproduces them verbatim, like
     * ezdxf does for context data. Only part of each context-data subclass is
     * modeled; rewriting it natively would drop the rest.
     *
     * @internal Used by the DXF OBJECTS reader.
     */
    setDxfRawTags(tags: AcDbDxfRawTags | undefined): void;
    /** True when export replays the tags read from DXF. @internal */
    get hasDxfRawTags(): boolean;
    dxfOut(...args: unknown[]): unknown;
    get classVersion(): number;
    set classVersion(value: number);
    /** True when this representation matches the entity record (DXF 290). */
    get isDefault(): boolean;
    set isDefault(value: boolean);
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Reads `AcDbObjectContextData` fields. Returns the next subclass marker
     * when present so subclasses can continue the section walk.
     */
    protected dxfInObjectContextData(filer: AcDbDxfFiler): string | undefined;
}
//# sourceMappingURL=AcDbObjectContextData.d.ts.map