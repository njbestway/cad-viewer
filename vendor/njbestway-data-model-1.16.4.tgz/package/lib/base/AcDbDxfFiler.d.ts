import { AcCmColor, AcCmTransparency } from '@mlightcad/common';
import { AcGePoint2d, AcGePoint2dLike, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import type { AcDbDatabase } from '../database/AcDbDatabase.js';
import { AcDbDwgVersion } from '../database/AcDbDwgVersion.js';
import type { AcDbDxfPair } from './AcDbDxfPair.js';
import { type AcDbDxfPairReader } from './AcDbDxfPairReader.js';
import { AcDbResultBuffer } from './AcDbResultBuffer.js';
import type { AcDbTypedValue } from './AcDbTypedValue.js';
/** Filer direction, mirroring ObjectARX usage of AcDbDxfFiler for in vs out. */
export type AcDbDxfFilerMode = 'read' | 'write';
/** DXF text vs binary output for write-mode filers. */
export type AcDbDxfOutputFormat = 'ascii' | 'binary';
/**
 * Lightweight status codes for DXF filing (ObjectARX-inspired).
 */
export declare enum AcDbDxfFilerStatus {
    Ok = 0,
    EndOfFile = 1,
    EndOfObject = 2,
    InvalidDxfCode = 3,
    BadDxfSequence = 4,
    NotThatKindOfClass = 5,
    WrongMode = 6
}
export interface AcDbDxfFilerOptions {
    database?: AcDbDatabase;
    precision?: number;
    version?: string | number | AcDbDwgVersion;
    /** When set, constructs a read-mode filer over this pair stream. */
    reader?: AcDbDxfPairReader;
    /** Write-mode output format (default ASCII). */
    outputFormat?: AcDbDxfOutputFormat;
    /**
     * Read-mode text encoding override for `fromBuffer`.
     *
     * When omitted, the encoding is auto-detected from `$DWGCODEPAGE`.
     * Common aliases such as `'cp949'` are normalized to a supported
     * `TextDecoder` label (`'euc-kr'`). Ignored when `reader` is provided.
     */
    encoding?: string;
}
/**
 * DXF filer that mirrors the ObjectARX {@link AcDbDxfFiler} API.
 *
 * - **Write mode** (default): accumulates classic group-code ASCII DXF text,
 *   or binary DXF bytes when `outputFormat` is `'binary'`.
 * - **Read mode**: pulls typed pairs from an {@link AcDbDxfPairReader} with
 *   `readItem` / `pushBackItem` / `atEndOfObject` / `atSubclassData`.
 */
export declare class AcDbDxfFiler {
    private _database?;
    private _precision;
    private _version?;
    private readonly _mode;
    private readonly _outputFormat;
    private readonly _lines;
    private readonly _binaryChunks;
    private _binaryLength;
    private readonly _handleMap;
    private _nextHandle;
    /** Index of the `$HANDSEED` value line in ASCII output; patched on finalize. */
    private _handseedValueLine;
    private _reader?;
    /**
     * Pushback stack for read mode (ObjectARX `pushBackItem`).
     * LIFO: nested pushBacks are supported so a second push does not clobber
     * the first.
     */
    private _pushed;
    private _status;
    private _errorMessage;
    private _lastRead;
    constructor(options?: AcDbDxfFilerOptions);
    /** Create a read-mode filer from an existing pair reader. */
    static forReading(reader: AcDbDxfPairReader, options?: Omit<AcDbDxfFilerOptions, 'reader'>): AcDbDxfFiler;
    /** Create a read-mode filer from DXF bytes (ASCII or binary). */
    static fromBuffer(data: ArrayBuffer | Uint8Array, options?: Omit<AcDbDxfFilerOptions, 'reader'>): AcDbDxfFiler;
    /** Create a read-mode filer from an already-decoded ASCII DXF string. */
    static fromString(text: string, options?: Omit<AcDbDxfFilerOptions, 'reader'>): AcDbDxfFiler;
    get mode(): AcDbDxfFilerMode;
    get database(): AcDbDatabase | undefined;
    set database(value: AcDbDatabase | undefined);
    get precision(): number;
    setPrecision(value: number): this;
    get version(): AcDbDwgVersion | undefined;
    get nextHandle(): number;
    get filerStatus(): AcDbDxfFilerStatus;
    get errorMessage(): string;
    setVersion(value: string | number | AcDbDwgVersion): this;
    setError(status: AcDbDxfFilerStatus, message?: string): this;
    resetStatus(): this;
    toString(): string;
    /** Finalize binary DXF bytes (includes magic prefix). */
    toBinary(): Uint8Array;
    /**
     * Upper-case handles of the OBJECTS-section records the current export
     * writes. When set, an object only emits its extension-dictionary pointer
     * if the dictionary is among them, so the output has no dangling 360.
     * Unset for ad-hoc writers (every pointer is written).
     */
    writtenObjectIds?: ReadonlySet<string>;
    /** True when `id` is (or may be) written; see {@link writtenObjectIds}. */
    isObjectIdWritten(id?: string): boolean;
    /**
     * Adds a record created while the OBJECTS section is being written (e.g.
     * the Layer Manager filter tree) to {@link writtenObjectIds}.
     */
    markObjectIdWritten(id?: string): this;
    /**
     * Writes an extension-dictionary pointer. Per the DXF reference (and
     * ezdxf / ODA output) the 360 handle is wrapped in `102 {ACAD_XDICTIONARY`
     * … `102 }` and precedes the owner handle (330); a bare 360 there is read
     * by AutoCAD as garbage. Skipped when the dictionary is not exported.
     */
    writeExtensionDictionary(id?: string): this;
    registerHandle(key: string): string;
    /**
     * Next unused handle based on every value registered in {@link _handleMap}
     * and the sequential allocator.
     */
    private computeHandseed;
    /**
     * Writes `$HANDSEED` as a placeholder and remembers its value line so
     * {@link finalizeHandseed} can patch it after all handles are assigned.
     */
    writeHandseedPlaceholder(): this;
    /**
     * Patches the ASCII `$HANDSEED` value to the next unused handle after the
     * full drawing has been written.
     */
    finalizeHandseed(): this;
    resolveHandle(key?: string): string | undefined;
    /** True if no more pairs are available. */
    get atEof(): boolean;
    /**
     * Current read position in the underlying pair stream.
     * Useful for byte-based parse progress while streaming a DXF.
     */
    position(): {
        line?: number;
        byteOffset: number;
    };
    /**
     * True if the next pair starts a new object (group code 0) or EOF.
     * Does not consume the pair.
     */
    get atEndOfObject(): boolean;
    /** True if the next pair is XDATA start (1001) or similar extended data. */
    get atExtendedData(): boolean;
    /**
     * Advance past subclass marker (100, name) if present.
     * Returns true when positioned at the named subclass data.
     */
    atSubclassData(name: string): boolean;
    /** Peek the next pair without consuming it. */
    peekItem(): AcDbTypedValue | undefined;
    /**
     * Read one DXF item into a typed value (ObjectARX `readItem`).
     * Returns undefined at EOF and sets {@link filerStatus} to EndOfFile.
     */
    readItem(): AcDbTypedValue | undefined;
    /**
     * Push the last-read (or provided) pair back so the next read returns it.
     * Multiple pushbacks form a LIFO stack (nested readers can push without
     * overwriting a prior push).
     */
    pushBackItem(item?: AcDbTypedValue | AcDbDxfPair): void;
    /** Skip pairs until the next object boundary (code 0) without consuming it. */
    skipToEndOfObject(): void;
    readString(expectedCode?: number): string | undefined;
    readInt16(expectedCode?: number): number | undefined;
    readInt32(expectedCode?: number): number | undefined;
    readInt64(expectedCode?: number): number | bigint | undefined;
    readDouble(expectedCode?: number): number | undefined;
    readBoolean(expectedCode?: number): boolean | undefined;
    readHandle(expectedCode?: number): string | undefined;
    readObjectId(expectedCode?: number): string | undefined;
    /**
     * Read a 2D point starting at `code` (x), then `code+10` (y).
     * Tolerates missing Y (defaults to 0) when the next code is not code+10.
     */
    readPoint2d(code: number): AcGePoint2d | undefined;
    /**
     * Read a 3D point starting at `code` (x), then `code+10` / `code+20`.
     * Missing Y/Z default to 0 when those group codes are absent.
     */
    readPoint3d(code: number): AcGePoint3d | undefined;
    readVector3d(code: number): AcGeVector3d | undefined;
    /**
     * Apply color group codes (62 ACI / 420 true color) onto `color` when the
     * current pair matches. Returns true if a color code was consumed.
     */
    readCmColorInto(color: AcCmColor, aciCode?: number, trueColorCode?: number): boolean;
    writeGroup(code: number, value: unknown): this;
    writeStart(value: string): this;
    /**
     * DXF dialect capabilities for the target write version.
     * When version is unset (ad-hoc writers / unit tests), treat as latest.
     */
    get capabilities(): import("../database/AcDbDwgVersion.js").AcDbDxfVersionCapabilities;
    writeSubclassMarker(value: string): this;
    writeString(code: number, value?: string): this;
    /**
     * Write MTEXT (or embedded-MTEXT) contents using AutoCAD's group 3 / group 1
     * 250-character chunking rules.
     */
    writeMTextContents(text: string): this;
    writeInt8(code: number, value?: number): this;
    writeInt16(code: number, value?: number): this;
    writeInt32(code: number, value?: number): this;
    writeInt64(code: number, value?: number): this;
    writeUInt16(code: number, value?: number): this;
    writeUInt32(code: number, value?: number): this;
    writeBoolean(code: number, value?: boolean): this;
    writeBool(code: number, value?: boolean): this;
    writeDouble(code: number, value?: number): this;
    writeAngle(code: number, radians?: number): this;
    writeHandle(code: number, key?: string): this;
    writeObjectId(code: number, objectId?: string): this;
    /** Lineweight (group 370). Omitted for DXF targets before AutoCAD 2000. */
    writeLineWeight(code: number, value?: number): this;
    writePoint2d(code: number, point?: AcGePoint2dLike): this;
    writePoint3d(code: number, point?: AcGePoint3dLike): this;
    writeVector3d(code: number, vector?: AcGeVector3dLike): this;
    writeCmColor(color?: AcCmColor, aciCode?: number, trueColorCode?: number): this;
    writeTransparency(transparency?: AcCmTransparency, code?: number): this;
    writeResultBuffer(data?: AcDbResultBuffer | null): this;
    /**
     * Replays tags captured verbatim from a DXF file (unknown entities/objects,
     * unknown HEADER variables). Unlike {@link writeString}, empty string values
     * are kept as empty value lines because their presence is significant.
     */
    writeRawPairs(pairs: Iterable<AcDbTypedValue>): this;
    /**
     * Writes any typed-value iterable using the same XData chunking rules as
     * ResultBuffer output. This lets compact imported XData stream directly.
     */
    writeTypedValues(data?: Iterable<AcDbTypedValue> | null): this;
    startSection(name: string): this;
    endSection(): this;
    startTable(name: string): this;
    endTable(): this;
    private assertWriteMode;
    private appendBinary;
    private writeBinaryCode;
    private writeBinaryGroup;
    private assertReadMode;
    private peekPair;
    private readPair;
    private pushBackPair;
    private readNumber;
    private pairToTypedValue;
    private typedValueToPair;
    private formatValue;
    /** Removes characters that must not appear on a single DXF value line. */
    private sanitizeStringForDxfLine;
    /**
     * Sanitize a string for DXF output, escaping non-ASCII as `\U+nnnn` when the
     * target version predates UTF-8 `$DWGCODEPAGE` (R2007 / AC1021).
     */
    private encodeStringForWrite;
}
//# sourceMappingURL=AcDbDxfFiler.d.ts.map