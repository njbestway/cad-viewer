import { AcGeChamfer2dError, AcGeChamferMode, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbLine } from './AcDbLine.js';
import { AcDbPolyline } from './AcDbPolyline.js';
import { AcDbRay } from './AcDbRay.js';
import { AcDbXline } from './AcDbXline.js';
/**
 * Options for {@link acdbChamferTwoEntities}.
 */
export interface AcDbChamferOptions {
    mode: AcGeChamferMode;
    /** When true, trim/extend operands to the chamfer ends (default true). */
    trim?: boolean;
}
/**
 * Result of chamfering two linear entities.
 */
export interface AcDbChamferTwoResult {
    created: AcDbEntity[];
    erase: AcDbEntity[];
    modified: AcDbEntity[];
}
/**
 * Result of chamfering every eligible polyline vertex.
 */
export interface AcDbChamferPolylineResult {
    chamfered: number;
    skipped: number;
}
export type AcDbChamferableEntity = AcDbLine | AcDbPolyline | AcDbRay | AcDbXline;
/**
 * Returns true when the entity can participate in CHAMFER (linear only).
 */
export declare function acdbIsChamferableEntity(entity: AcDbEntity): entity is AcDbChamferableEntity;
/**
 * Builds transient chamfer preview geometry without mutating the drawing.
 *
 * Used when COMMANDPREVIEW is on: returns the would-be chamfer segment
 * (empty for a sharp corner / zero distances / no solution).
 */
export declare function acdbPreviewChamferTwoEntities(e1: AcDbEntity, pick1: AcGePoint3dLike, e2: AcDbEntity, pick2: AcGePoint3dLike, options: AcDbChamferOptions): AcDbEntity[];
/**
 * Chamfers two linear entities.
 */
export declare function acdbChamferTwoEntities(e1: AcDbEntity, pick1: AcGePoint3dLike, e2: AcDbEntity, pick2: AcGePoint3dLike, options: AcDbChamferOptions): {
    ok: true;
    result: AcDbChamferTwoResult;
} | {
    ok: false;
    error: AcGeChamfer2dError;
};
/**
 * Inserts chamfers at every vertex of a 2D polyline where two straight segments meet.
 *
 * @param pline - Polyline to mutate
 * @param options - Distance/angle mode
 * @param onlyCorner - When set, chamfer only this vertex index
 */
export declare function acdbChamferPolyline(pline: AcDbPolyline, options: AcDbChamferOptions, onlyCorner?: number): AcDbChamferPolylineResult;
//# sourceMappingURL=AcDbChamferHelpers.d.ts.map