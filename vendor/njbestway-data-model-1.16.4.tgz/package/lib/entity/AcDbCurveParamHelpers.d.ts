import { AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import type { AcDbCurve } from './AcDbCurve.js';
import type { AcDbEntity } from './AcDbEntity.js';
/**
 * Returns the distance tolerance used to decide whether a point lies on a
 * curve (or on its natural extension).
 *
 * It is a little looser than {@link DEFAULT_TOL} so that intersection points
 * computed by `intersectWith` (refined to a few `equalPointTol` for splines)
 * are accepted, and grows with the coordinate magnitude so drawings far from
 * the origin still work.
 *
 * @param scale - Typical coordinate magnitude of the curve
 * @returns Distance tolerance in drawing units
 */
export declare function acdbCurveOnTol(scale?: number): number;
/**
 * Normalizes split parameters following ObjectARX `getSplitCurves` rules.
 *
 * - Open curves: parameters not strictly inside `(start, end)` are dropped.
 * - Closed curves: parameters are wrapped into `[start, end)`.
 * - The result is sorted ascending and de-duplicated with `paramTol`.
 *
 * @param params - Raw split parameters
 * @param start - Start parameter of the curve
 * @param end - End parameter of the curve
 * @param closed - Whether the curve is periodic over `[start, end]`
 * @param paramTol - Parameter tolerance
 * @returns Valid, sorted, unique parameters
 */
export declare function acdbNormalizeSplitParams(params: readonly number[], start: number, end: number, closed: boolean, paramTol: number): number[];
/**
 * Splits a curve into pieces using {@link acdbNormalizeSplitParams} and the
 * ObjectARX ordering rules.
 *
 * - Open curve, `n` params: `[start,p1], [p1,p2], ..., [pn,end]`.
 * - Closed curve, `n >= 2` params: `[p1,p2], ..., [pn, p1 + period]` — the last
 *   piece wraps through the start/end seam, so its end parameter is larger
 *   than `end`.
 *
 * @param params - Raw split parameters
 * @param start - Start parameter of the curve
 * @param end - End parameter of the curve
 * @param closed - Whether the curve is periodic over `[start, end]`
 * @param paramTol - Parameter tolerance
 * @param makePiece - Builds one piece for `[from, to]`; returns `undefined`
 *   for a degenerate piece, which is dropped
 * @returns Pieces in curve order
 */
export declare function acdbSplitCurveByParams(params: readonly number[], start: number, end: number, closed: boolean, paramTol: number, makePiece: (from: number, to: number) => AcDbCurve | undefined): AcDbCurve[];
/**
 * Detaches a cloned split piece from its source's database identity: the
 * owner and extension dictionary references are removed (the clone already
 * received a fresh temporary object id).
 *
 * @param entity - Freshly cloned entity
 * @returns The same entity
 */
export declare function acdbDetachSplitPiece<T extends AcDbEntity>(entity: T): T;
/** Normalizes an angle into `[0, 2π)`. */
export declare function acdbNormalizeAngle(angle: number): number;
/**
 * Decomposes `point` in the plane frame `(center, xAxis, normal)` of a circle
 * or ellipse.
 *
 * @returns Local `x` / `y` coordinates and the signed distance to the plane
 */
export declare function acdbPlaneCoords(center: AcGePoint3dLike, xAxis: AcGeVector3dLike, normal: AcGeVector3dLike, point: AcGePoint3dLike): {
    x: number;
    y: number;
    h: number;
};
/**
 * Polar angle (around `normal`, measured from `refVec`, in `[0, 2π)`) of
 * `point` relative to a circle, plus the distance from the point to the
 * circle.
 *
 * @param center - Circle center
 * @param radius - Circle radius
 * @param refVec - Direction of angle 0
 * @param normal - Circle normal
 * @param point - Query point
 */
export declare function acdbCircleAngleOf(center: AcGePoint3dLike, radius: number, refVec: AcGeVector3dLike, normal: AcGeVector3dLike, point: AcGePoint3dLike): {
    angle: number;
    dist: number;
    rho: number;
};
/**
 * Maps WCS points to the coordinate system of an {@link AcDbCurvePath}
 * (OCS relative to the elevation for 2D polylines) and back. The mapping
 * must be a rigid motion so distances are preserved.
 */
export interface AcDbCurvePathFrame {
    toPath(point: AcGePoint3dLike): AcGePoint3dLike;
    fromPath(point: AcGePoint3dLike): AcGePoint3d;
}
/** Identity {@link AcDbCurvePathFrame} (3D polylines). */
export declare const ACDB_IDENTITY_PATH_FRAME: AcDbCurvePathFrame;
/**
 * WCS-level parameter, split and extend operations of a polyline-like curve
 * built on an {@link AcDbCurvePath}. Shared by `AcDbPolyline`,
 * `AcDb2dPolyline` and `AcDb3dPolyline`.
 *
 * @internal
 */
export declare class AcDbCurvePathOps {
    readonly path: AcDbCurvePath;
    readonly frame: AcDbCurvePathFrame;
    /** Distance tolerance. */
    readonly tol: number;
    /** Parameter tolerance (vertex-index units). */
    readonly paramTol: number;
    constructor(vertices: readonly AcDbCurvePathVertex[], closed: boolean, frame: AcDbCurvePathFrame, extraScale?: number);
    get endParam(): number;
    paramAtPoint(point: AcGePoint3dLike): number | undefined;
    pointAtParam(param: number): AcGePoint3d | undefined;
    closestPoint(point: AcGePoint3dLike, extend: boolean): AcGePoint3d;
    distAtParam(param: number): number | undefined;
    /**
     * Splits the path; `makePiece` receives the open vertex list of each piece
     * (in path coordinates).
     */
    split(params: readonly number[], makePiece: (vertices: AcDbCurvePathVertex[]) => AcDbCurve | undefined): AcDbCurve[];
    /** Vertices after extending to `newParam`, or `undefined`. */
    extendedVertices(newParam: number): AcDbCurvePathVertex[] | undefined;
    /** Parameter of a point on the extension beyond the start / end. */
    extensionParam(extendStart: boolean, point: AcGePoint3dLike): number | undefined;
}
/** Vertex of an {@link AcDbCurvePath}. */
export interface AcDbCurvePathVertex {
    x: number;
    y: number;
    z?: number;
    bulge?: number;
    startWidth?: number;
    endWidth?: number;
}
interface PathSegment {
    ax: number;
    ay: number;
    az: number;
    bx: number;
    by: number;
    bz: number;
    /** Included angle (signed, CCW positive); 0 for a straight segment. */
    theta: number;
    cx: number;
    cy: number;
    r: number;
    /** Polar angle of the start point around the center. */
    a0: number;
    length: number;
    startWidth?: number;
    endWidth?: number;
}
/**
 * Vertex-index parameterization of a (possibly bulged) polyline path, as used
 * by ObjectARX for `AcDbPolyline`, `AcDb2dPolyline` and `AcDb3dPolyline`.
 *
 * The parameter is `vertexIndex + fraction`; the fraction is the arc-length
 * fraction of that segment (equal to the angle fraction for bulge arcs).
 * Arcs are evaluated in the XY plane of the path coordinates (OCS for 2D
 * polylines); straight segments are full 3D.
 *
 * @internal
 */
export declare class AcDbCurvePath {
    readonly closed: boolean;
    readonly vertices: readonly AcDbCurvePathVertex[];
    readonly segments: PathSegment[];
    constructor(vertices: readonly AcDbCurvePathVertex[], closed: boolean);
    /** Number of segments (end parameter). */
    get segmentCount(): number;
    /**
     * Index of the segment whose natural extension continues the start (first
     * non-degenerate segment) or the end (last non-degenerate segment) of an
     * open path. Duplicated end vertices are common in imported drawings and
     * must not block extension.
     */
    private endSegmentIndex;
    /** Characteristic coordinate magnitude used for tolerances. */
    get scale(): number;
    /**
     * Splits `param` into a segment index and a fraction. Parameters before
     * the start / after the end of an open path map onto the first / last
     * non-degenerate segment with a fraction `< 0` / `> 1` (natural extension).
     */
    locate(param: number): {
        index: number;
        f: number;
    } | undefined;
    /** Point at `param` (open paths extend along their end segments). */
    pointAt(param: number): AcGePoint3d | undefined;
    /** Distance along the path from the start to `param`. */
    distAt(param: number): number | undefined;
    /** Total length. */
    get length(): number;
    /**
     * Parameter of a point on the path. For open paths, a point on the natural
     * extension of the first segment (param `< 0`) or of the last segment
     * (param `> segmentCount`) is also accepted.
     */
    paramAt(point: AcGePoint3dLike, tol: number): number | undefined;
    /**
     * Parameter of a point on the natural extension beyond the start
     * (`atStart`, param `< 0`) or the end (param `> segmentCount`) of an open
     * path, or `undefined`.
     */
    extensionParamAt(atStart: boolean, point: AcGePoint3dLike, tol: number): number | undefined;
    /** Closest point on the path, optionally on its natural end extensions. */
    closestPoint(point: AcGePoint3dLike, extend: boolean): AcGePoint3d;
    /**
     * Open vertex list tracing the path from `from` to `to` (`from < to`;
     * `to` may exceed `segmentCount` on closed paths to wrap through the
     * seam). Bulges of partial arc segments become `tan(subSweep / 4)` and
     * widths are interpolated linearly at the cut points. Zero-length segments
     * (duplicated vertices) are left out so pieces have no coincident vertices.
     */
    subVertices(from: number, to: number): AcDbCurvePathVertex[];
    /**
     * Vertex list of this open path extended to `newParam` (`< 0` extends the
     * start, `> segmentCount` the end), or `undefined` when not possible
     * (closed path, `newParam` inside the range, or an arc that would reach a
     * full turn).
     */
    extendedVertices(newParam: number, paramTol: number): AcDbCurvePathVertex[] | undefined;
}
export {};
//# sourceMappingURL=AcDbCurveParamHelpers.d.ts.map