import { AcGeLine3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGePointLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/index.js';
import { AcDbEntityProperties } from '../AcDbEntityProperties.js';
import { AcDbDimension } from './AcDbDimension.js';
/**
 * Represents an aligned dimension entity in AutoCAD.
 *
 * An aligned dimension measures the distance between two points located anywhere in space.
 * The dimension's normal vector must be perpendicular to the line between the two points.
 * The two selected points are also used as the definition points for the start of the
 * two dimension extension lines.
 *
 * Aligned dimensions are commonly used to measure distances that are not parallel to
 * the X or Y axes, providing accurate measurements regardless of the orientation.
 *
 * @example
 * ```typescript
 * // Create an aligned dimension
 * const alignedDim = new AcDbAlignedDimension(
 *   new AcGePoint3d(0, 0, 0),    // First extension line point
 *   new AcGePoint3d(10, 5, 0),   // Second extension line point
 *   new AcGePoint3d(5, 2.5, 0),  // Dimension line point
 *   "10.0",                      // Dimension text
 *   "Standard"                   // Dimension style
 * );
 *
 * // Access dimension properties
 * console.log(`Dimension line point: ${alignedDim.dimLinePoint}`);
 * console.log(`Extension line 1 point: ${alignedDim.xLine1Point}`);
 * console.log(`Extension line 2 point: ${alignedDim.xLine2Point}`);
 * ```
 */
export declare class AcDbAlignedDimension extends AcDbDimension {
    /** The entity type name */
    static typeName: string;
    /** The definition point that specifies where the dimension line will be */
    private _dimLinePoint;
    /** The start point for the first extension line */
    private _xLine1Point;
    /** The start point for the second extension line */
    private _xLine2Point;
    /** The extension line obliquing angle in radians */
    private _oblique;
    /** The dimension's rotation angle in radians */
    private _rotation;
    /**
     * Creates a new aligned dimension entity.
     *
     * This constructor initializes an aligned dimension using the specified points.
     * The extension line obliquing angle is set to 0.0 by default.
     *
     * @param xLine1Point - Start point (in WCS coordinates) of first extension line
     * @param xLine2Point - Start point (in WCS coordinates) of second extension line
     * @param dimLinePoint - Point (in WCS coordinates) on dimension line itself
     * @param dimText - Text string to use as the dimension annotation (optional)
     * @param dimStyle - String name of dimension style table record to use (optional)
     *
     * @example
     * ```typescript
     * // Create an aligned dimension with default text and style
     * const alignedDim = new AcDbAlignedDimension(
     *   new AcGePoint3d(0, 0, 0),
     *   new AcGePoint3d(10, 5, 0),
     *   new AcGePoint3d(5, 2.5, 0)
     * );
     *
     * // Create an aligned dimension with custom text and style
     * const alignedDim2 = new AcDbAlignedDimension(
     *   new AcGePoint3d(0, 0, 0),
     *   new AcGePoint3d(15, 10, 0),
     *   new AcGePoint3d(7.5, 5, 0),
     *   "15.0",
     *   "Architectural"
     * );
     * ```
     */
    constructor(xLine1Point: AcGePointLike, xLine2Point: AcGePointLike, dimLinePoint: AcGePointLike, dimText?: string | null, dimStyle?: string | null);
    /**
     * Gets the definition point that specifies where the dimension line will be.
     *
     * This point will be somewhere on the dimension line and determines the position
     * of the dimension text and arrows.
     *
     * @returns The dimension line point in WCS coordinates
     *
     * @example
     * ```typescript
     * const dimLinePoint = alignedDim.dimLinePoint;
     * console.log(`Dimension line point: ${dimLinePoint.x}, ${dimLinePoint.y}, ${dimLinePoint.z}`);
     * ```
     */
    get dimLinePoint(): AcGePoint3d;
    /**
     * Sets the definition point that specifies where the dimension line will be.
     *
     * @param value - The new dimension line point
     *
     * @example
     * ```typescript
     * alignedDim.dimLinePoint = new AcGePoint3d(5, 2.5, 0);
     * ```
     */
    set dimLinePoint(value: AcGePoint3dLike);
    /**
     * Gets the start point for the first extension line of the dimension.
     *
     * @returns The first extension line point in WCS coordinates
     *
     * @example
     * ```typescript
     * const xLine1Point = alignedDim.xLine1Point;
     * console.log(`Extension line 1 point: ${xLine1Point.x}, ${xLine1Point.y}, ${xLine1Point.z}`);
     * ```
     */
    get xLine1Point(): AcGePoint3d;
    /**
     * Sets the start point for the first extension line of the dimension.
     *
     * @param value - The new first extension line point
     *
     * @example
     * ```typescript
     * alignedDim.xLine1Point = new AcGePoint3d(0, 0, 0);
     * ```
     */
    set xLine1Point(value: AcGePoint3dLike);
    /**
     * Gets the start point for the second extension line of the dimension.
     *
     * @returns The second extension line point in WCS coordinates
     *
     * @example
     * ```typescript
     * const xLine2Point = alignedDim.xLine2Point;
     * console.log(`Extension line 2 point: ${xLine2Point.x}, ${xLine2Point.y}, ${xLine2Point.z}`);
     * ```
     */
    get xLine2Point(): AcGePoint3d;
    /**
     * Sets the start point for the second extension line of the dimension.
     *
     * @param value - The new second extension line point
     *
     * @example
     * ```typescript
     * alignedDim.xLine2Point = new AcGePoint3d(10, 5, 0);
     * ```
     */
    set xLine2Point(value: AcGePoint3dLike);
    /**
     * Gets the dimension's rotation angle.
     *
     * @returns The rotation angle in radians
     *
     * @example
     * ```typescript
     * const rotation = alignedDim.rotation;
     * console.log(`Rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
     * ```
     */
    get rotation(): number;
    /**
     * Sets the dimension's rotation angle.
     *
     * @param value - The new rotation angle in radians
     *
     * @example
     * ```typescript
     * alignedDim.rotation = Math.PI / 4; // 45 degrees
     * ```
     */
    set rotation(value: number);
    /**
     * Gets the extension line obliquing angle.
     *
     * @returns The obliquing angle in radians
     *
     * @example
     * ```typescript
     * const oblique = alignedDim.oblique;
     * console.log(`Oblique angle: ${oblique} radians`);
     * ```
     */
    get oblique(): number;
    /**
     * Sets the extension line obliquing angle.
     *
     * @param value - The new obliquing angle in radians
     *
     * @example
     * ```typescript
     * alignedDim.oblique = Math.PI / 6; // 30 degrees
     * ```
     */
    set oblique(value: number);
    get properties(): AcDbEntityProperties;
    /**
     * Angle (radians) of the dimension line direction.
     *
     * An aligned dimension measures along the chord between the extension line
     * origins; {@link AcDbRotatedDimension} overrides this with its fixed
     * {@link rotation}.
     */
    protected get dimLineAngle(): number;
    /**
     * Whether grip edits keep the dimension line direction. `false` for aligned
     * dimensions (the line follows the extension line origins), `true` for
     * rotated (linear) dimensions.
     */
    protected get hasFixedDimLineAngle(): boolean;
    /** Unit vector along the dimension line. */
    private dimLineDirection;
    /** Unit normal of the dimension line (direction of the extension lines). */
    private dimLineNormal;
    /** Projects `point` onto the dimension line along the extension direction. */
    private projectOntoDimLine;
    /**
     * Grips match AutoCAD: both extension line origins, both dimension line
     * ends (where the arrows sit), then the text grip added by the base class.
     *
     * @inheritdoc
     */
    protected collectDimensionDefinitionGripPoints(): AcGePoint3d[];
    /**
     * Both dimension-line end grips control the same line. When a stretch
     * selects both, apply the normal move once so the line does not jump
     * twice as far as the drag.
     *
     * @inheritdoc
     */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * - Extension line origin grips move the measured point. A rotated
     *   dimension keeps its dimension line; an aligned dimension keeps the
     *   dimension line's distance from the measured points.
     * - Dimension line grips only move the line along its normal.
     *
     * @inheritdoc
     */
    protected moveDefinitionGripAt(index: number, offset: AcGeVector3dLike): void;
    /**
     * DIMTMOVE 0 moves the dimension line with the text; otherwise only the
     * text moves.
     *
     * @inheritdoc
     */
    protected moveTextGrip(offset: AcGeVector3dLike): void;
    private moveDimLineAlongNormal;
    /**
     * Keeps the dimension line point where AutoCAD stores it (DXF group 10):
     * on the dimension line, at the second extension line.
     */
    private normalizeDimLinePoint;
    /**
     * @inheritdoc
     */
    protected subTransformBy(matrix: AcGeMatrix3d): void;
    /** @inheritdoc */
    protected computeMeasurement(): number;
    /**
     * @inheritdoc
     */
    get geometricExtents(): import("@mlightcad/geometry-engine").AcGeBox3d;
    /**
     * @inheritdoc
     */
    protected get isAppendArrow(): boolean;
    createDimBlock(blockName: string): import("../../index.js").AcDbBlockTableRecord;
    /**
     * Adds the geometry AutoCAD draws for text moved off its home position:
     * with DIMTMOVE 0 the dimension line extends under text placed beyond the
     * extension lines; with DIMTMOVE 1 a leader joins the dimension line to
     * text moved away from it.
     */
    private appendUserTextGeometry;
    /**
     * Return one array which contains three lines of the alinged dimension.
     * - The first line in the array is dimension line.
     * - The second line and the third line in the array are extension lines.
     * @returns Return three lines of the alinged dimension
     */
    protected createLines(): AcGeLine3d[];
    private createExtensionLine;
    /**
     * Compute the intersection point between a line 'line1' and a line 'line2' that passes through
     * a given point 'p' and is perpendicular to line 'line1'.
     *
     * @param line The 'line1'.
     * @param p The point through which the perpendicular 'line2' passes.
     * @returns Returns the intersection point of 'line1' and 'line2'.
     */
    private findIntersectionPoint;
    private calculateRotation;
    /**
     * DXF subclass marker written for this dimension subtype.
     */
    protected get dxfSubclassMarker(): string;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private finishAlignedDxfIn;
}
//# sourceMappingURL=AcDbAlignedDimension.d.ts.map