import { AcDbAlignedDimension } from './AcDbAlignedDimension.js';
/**
 * Represents a rotated linear dimension entity in AutoCAD.
 *
 * A rotated dimension is similar to an aligned dimension, but its dimension line
 * direction is controlled by an explicit rotation angle.
 */
export declare class AcDbRotatedDimension extends AcDbAlignedDimension {
    /** The entity type name */
    static typeName: string;
    /**
     * The dimension line follows the explicit {@link rotation}, not the chord
     * between the extension line origins.
     *
     * @inheritdoc
     */
    protected get dimLineAngle(): number;
    /** @inheritdoc */
    protected get hasFixedDimLineAngle(): boolean;
    /**
     * Distance between the extension line origins projected onto the dimension
     * line direction.
     *
     * @inheritdoc
     */
    protected computeMeasurement(): number;
    /**
     * @inheritdoc
     */
    protected get dxfSubclassMarker(): string;
}
//# sourceMappingURL=AcDbRotatedDimension.d.ts.map