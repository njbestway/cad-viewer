import { AcGeLine3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiMTextAttachmentPoint } from '@mlightcad/graphic-interface';
import type { AcDbObject } from '../../base/AcDbObject.js';
import { AcDbBlockTableRecord } from '../../database/AcDbBlockTableRecord.js';
import { AcDbDatabase } from '../../database/AcDbDatabase.js';
import { AcDbDimStyleTableRecord } from '../../database/AcDbDimStyleTableRecord.js';
import { AcDbArc } from '../AcDbArc.js';
import { AcDbBlockReference } from '../AcDbBlockReference.js';
import { AcDbLine } from '../AcDbLine.js';
import { AcDbMText } from '../AcDbMText.js';
import { acdbDimFeatureScale } from './AcDbDimFeatureScale.js';
export { acdbDimFeatureScale };
/** Closed filled uses empty dimblk in AutoCAD; we store geometry under this BTR name. */
export declare const CLOSED_FILLED_ARROW_BLOCK = "_CLOSEDFILLED";
export declare function acdbResolveArrowBlockName(dimblk: string | undefined | null): string;
export declare function acdbEnsureDimArrowBlocks(db: AcDbDatabase, style: AcDbDimStyleTableRecord): void;
export declare function acdbCreateDimLineEntity(start: AcGePoint3dLike, end: AcGePoint3dLike, style: AcDbDimStyleTableRecord, kind?: 'dimension' | 'extension'): AcDbLine;
export declare function acdbCreateDimArrowInsert(pos: AcGePoint3dLike, rotation: number, scale: number, blockName: string): AcDbBlockReference | null;
export declare function acdbArrowScaleFromStyle(style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
export declare function acdbTextHeightFromStyle(style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
export declare function acdbCreateDimMText(options: {
    contents: string;
    position: AcGePoint3dLike;
    rotation: number;
    style: AcDbDimStyleTableRecord;
    attachmentPoint?: AcGiMTextAttachmentPoint;
    entity?: AcDbObject;
}): AcDbMText | null;
/**
 * Offset text position along the normal of the dimension line based on dimtad/dimgap.
 */
export declare function acdbOffsetTextAlongNormal(mid: AcGePoint3dLike, rotation: number, style: AcDbDimStyleTableRecord, entity?: AcDbObject): AcGePoint3d;
export declare function acdbAppendCenterMark(block: AcDbBlockTableRecord, center: AcGePoint3dLike, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
export declare function acdbCreateEmptyDimBlock(blockName: string): AcDbBlockTableRecord;
export declare function acdbBuildAnnotationText(measured: number, dimensionText: string | null | undefined, style: AcDbDimStyleTableRecord, kind: 'linear' | 'angular' | 'radial' | 'diametric'): string;
/**
 * Create a dimension-line arc for angular dimensions.
 */
export declare function acdbCreateDimArcEntity(center: AcGePoint3dLike, radius: number, startAngle: number, endAngle: number, style: AcDbDimStyleTableRecord): AcDbArc;
export declare function acdbUnitVectorFromAngle(angle: number): AcGeVector3d;
export declare function acdbAngleOfPoints(from: AcGePoint3dLike, to: AcGePoint3dLike): number;
/**
 * Resolve the CCW angular sweep from ray1→ray2 that contains `arcPoint`.
 * When the arc point lies on the complementary (major) arc, the start/end
 * rays are swapped so measurement matches drawn geometry.
 */
export declare function acdbResolveAngularSweep(options: {
    center: AcGePoint3dLike;
    xLine1: AcGePoint3dLike;
    xLine2: AcGePoint3dLike;
    arcPoint: AcGePoint3dLike;
}): {
    start: number;
    end: number;
    sweep: number;
};
export declare function acdbPointAt(origin: AcGePoint3dLike, angle: number, distance: number): AcGePoint3d;
export declare function acdbMidPoint(a: AcGePoint3dLike, b: AcGePoint3dLike): AcGePoint3d;
export declare function acdbExtendLineByDimDle(line: AcGeLine3d, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
/**
 * Allocates the next free anonymous dimension block name (`*D{n}`).
 *
 * @param db - Database whose block table is scanned.
 * @returns A `*D{n}` name one greater than the largest existing one.
 */
export declare function acdbAllocateDimBlockName(db: AcDbDatabase): string;
/**
 * Removes an anonymous dimension block and erases its entities.
 *
 * `blockTable.remove` alone leaves the child entities registered in the
 * database, so they are removed from the block record first.
 *
 * @param db - Database owning the block.
 * @param blockName - Name of the block to drop. Missing blocks are ignored.
 */
export declare function acdbDisposeDimBlock(db: AcDbDatabase, blockName: string): void;
/**
 * Normalizes a text angle into (-π/2, π/2] so dimension text never reads
 * upside down, matching AutoCAD's aligned dimension text.
 */
export declare function acdbReadableTextAngle(angle: number): number;
/**
 * Returns the point where a leader from `from` should stop before reaching
 * dimension text centered at `text`, leaving the DIMGAP clearance.
 */
export declare function acdbLeaderEndBeforeText(from: AcGePoint3dLike, text: AcGePoint3dLike, style: AcDbDimStyleTableRecord, entity?: AcDbObject): AcGePoint3d;
/**
 * Re-places the dimension arc point of an angular or arc length dimension
 * so the dimension arc runs under text dragged to `text` (DIMTMOVE 0).
 *
 * @param center - Center of the dimension arc.
 * @param arcPoint - Arc point updated in place.
 * @param text - New text position.
 * @param textRadialOffset - Distance from the arc to the text center.
 */
export declare function acdbMoveArcPointUnderText(center: AcGePoint3dLike, arcPoint: AcGePoint3d, text: AcGePoint3dLike, textRadialOffset: number): void;
/**
 * Appends a leader line from `from` to text placed at a user-defined
 * position (DIMTMOVE 1), when the text is farther than one arrow size away.
 */
export declare function acdbAppendLeaderToText(block: AcDbBlockTableRecord, from: AcGePoint3dLike, text: AcGePoint3dLike, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
/**
 * Appends the dimension line AutoCAD draws for radius and diameter text kept
 * at a user position as horizontal text (DIMTIH / DIMTOH): from the arrowhead
 * along the dimension line to the knee level with the text, then a
 * horizontal landing one arrow size long toward the text.
 *
 * @param block - Dimension block receiving the lines.
 * @param arrowPoint - Arrowhead tip on the measured curve.
 * @param direction - Direction of the dimension line through `arrowPoint`.
 * @param text - User text position.
 * @param style - Effective dimension style.
 * @param entity - Dimension owning the block (annotation scale lookup).
 */
export declare function acdbAppendRadialTextLanding(block: AcDbBlockTableRecord, arrowPoint: AcGePoint3dLike, direction: AcGeVector3dLike, text: AcGePoint3dLike, style: AcDbDimStyleTableRecord, entity?: AcDbObject): void;
/**
 * Swings `point` around `center` toward `toward`, keeping its distance from
 * the center (radius and diameter chord grips stay on the circle).
 *
 * @param center - Circle center.
 * @param point - Point on the circle, updated in place.
 * @param toward - Location that sets the new direction from the center.
 */
export declare function acdbRotatePointAroundCenter(center: AcGePoint3dLike, point: AcGePoint3d, toward: AcGePoint3dLike): void;
/**
 * Leader length for radius/diameter text dragged `distance` from the center
 * of a circle of `radius`: zero inside the circle, otherwise the part of the
 * drag beyond the circle minus the horizontal landing drawn before the text.
 */
export declare function acdbLeaderLengthToText(distance: number, radius: number, style: AcDbDimStyleTableRecord, entity?: AcDbObject): number;
//# sourceMappingURL=AcDbDimBlockBuilder.d.ts.map