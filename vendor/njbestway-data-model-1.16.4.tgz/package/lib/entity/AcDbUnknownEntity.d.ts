import type { AcGeMatrix3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { type AcDbDxfRawTags } from '../dxf/AcDbDxfRawTags.js';
import { AcDbProxyEntity } from './AcDbProxyEntity.js';
/**
 * An entity whose DXF type has no native implementation (for example `HELIX`,
 * `MESH`, `REGION`, `PDFUNDERLAY` or a third-party class).
 *
 * Mirrors ezdxf's `DXFTagStorage` / ODA's handling of unknown classes: all
 * tags are kept verbatim and written back unchanged by `dxfOut`, so opening
 * and saving a drawing no longer silently deletes such entities. Common
 * entity properties (layer, color, …) are parsed for display and filtering,
 * and an embedded proxy graphic (AcDbEntity groups 92/160 + 310), when
 * present, is rendered through {@link AcDbProxyEntity}.
 *
 * Geometry edits cannot be expressed in the preserved tags: the entity cannot
 * be transformed, and only the layer is patched on output.
 */
export declare class AcDbUnknownEntity extends AcDbProxyEntity {
    static typeName: string;
    private _dxfTypeName;
    private _rawTags;
    constructor(dxfTypeName?: string);
    get dxfTypeName(): string;
    /** Tags captured from the source DXF, excluding handle, owner and XData. */
    get rawTags(): Readonly<AcDbDxfRawTags>;
    dxfIn(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    dxfOut(...args: unknown[]): unknown;
    /** Raw tags with the AcDbEntity layer (group 8) set to the current one. */
    private patchedTags;
    /**
     * True when the preserved tags use subclass markers (R13+ layout), i.e.
     * they can be written to an R13+ DXF.
     */
    get hasSubclassData(): boolean;
    /**
     * Geometry lives in tags this class does not understand, so it cannot be
     * transformed (ezdxf raises for the same reason). Moving only the display
     * would make the saved file disagree with what the user saw.
     */
    transformBy(_matrix: AcGeMatrix3d): this;
    subGetGripPoints(): never[];
    private loadEmbeddedProxyGraphic;
}
//# sourceMappingURL=AcDbUnknownEntity.d.ts.map