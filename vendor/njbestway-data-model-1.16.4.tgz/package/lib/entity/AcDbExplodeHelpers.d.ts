import { AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcDbCurve } from './AcDbCurve.js';
import { AcDbLine } from './AcDbLine.js';
/**
 * One vertex of a planar bulge path, in OCS.
 */
export interface AcDbBulgePathVertex {
    /** OCS X coordinate */
    x: number;
    /** OCS Y coordinate */
    y: number;
    /**
     * Bulge of the segment that starts at this vertex: `tan(θ / 4)` where `θ`
     * is the included angle, positive for a counter-clockwise arc.
     */
    bulge?: number;
}
/**
 * Options of {@link acdbExplodeBulgePath}.
 */
export interface AcDbExplodeBulgePathOptions {
    /** Whether the path has a closing segment from the last to the first vertex. */
    closed: boolean;
    /** Elevation of the path plane along `normal`. */
    elevation: number;
    /** Plane normal (extrusion direction) of the path. */
    normal: AcGeVector3dLike;
    /** Thickness copied to every generated line / arc. Defaults to `0`. */
    thickness?: number;
}
/**
 * Breaks a planar bulge path (the geometry of LWPOLYLINE and 2D POLYLINE) into
 * one {@link AcDbLine} or {@link AcDbArc} per segment, the way AutoCAD
 * EXPLODE does. Segment widths are not represented: AutoCAD discards them as
 * well.
 *
 * Zero-length segments are skipped. The generated entities are in WCS, share
 * the plane normal of the path and carry no entity properties; callers copy
 * those with {@link AcDbEntity.setPropertiesFrom}.
 *
 * @param vertices - Path vertices in OCS.
 * @param options - Plane and closure of the path.
 * @returns The generated lines and arcs, in path order.
 */
export declare function acdbExplodeBulgePath(vertices: readonly AcDbBulgePathVertex[], options: AcDbExplodeBulgePathOptions): AcDbCurve[];
/**
 * Breaks a 3D vertex path into one {@link AcDbLine} per non-degenerate
 * segment, the way AutoCAD EXPLODE handles 3D polylines.
 *
 * @param points - Path vertices in WCS.
 * @param closed - Whether the path has a closing segment.
 * @returns The generated lines, in path order.
 */
export declare function acdbExplodePointPath(points: readonly AcGePoint3dLike[], closed: boolean): AcDbLine[];
/**
 * Returns the two in-plane axes (OCS X and Y) of the plane with `normal`,
 * following the AutoCAD arbitrary axis algorithm.
 *
 * @param normal - Plane normal.
 * @returns The OCS X and Y axes as unit vectors.
 */
export declare function acdbGetOcsAxes(normal: AcGeVector3dLike): {
    xAxis: AcGeVector3d;
    yAxis: AcGeVector3d;
};
/**
 * Converts MTEXT contents into plain-text paragraphs, the text that remains
 * when AutoCAD EXPLODE turns multiline text into single-line text.
 *
 * Paragraph breaks (`\P`) and column breaks (`\N`) start a new paragraph,
 * formatting codes (`\F`, `\H`, `\C`, `\L`, ...) and grouping braces are
 * dropped, escaped characters (`\\`, `\{`, `\}`), non-breaking spaces
 * (`\~`) and Unicode escapes (`\U+XXXX`) are decoded, and stacked fractions
 * (`\S1^2;`) are written inline as `1/2`.
 *
 * @param contents - Raw MTEXT contents.
 * @returns The plain-text paragraphs, in order.
 */
export declare function acdbMTextToPlainParagraphs(contents: string): string[];
/**
 * Wraps one plain-text paragraph to the given width, breaking at spaces (or
 * anywhere between full-width characters), the way MTEXT word wrap lays out
 * a paragraph. Character widths are estimated, so the line breaks
 * approximate the ones AutoCAD computes from the actual font.
 *
 * @param paragraph - Plain-text paragraph.
 * @param width - Wrapping width; `0` or less disables wrapping.
 * @param height - Text height.
 * @returns The wrapped lines (at least one, possibly empty).
 */
export declare function acdbWrapPlainParagraph(paragraph: string, width: number, height: number): string[];
//# sourceMappingURL=AcDbExplodeHelpers.d.ts.map