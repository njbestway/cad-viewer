import type { AcGePoint2dLike } from '@mlightcad/geometry-engine';
import type { AcGiHatchPatternLine } from '@mlightcad/graphic-interface';
/** One generated pattern segment; a dot has identical end points. */
export type AcDbHatchPatternSegment = [AcGePoint2dLike, AcGePoint2dLike];
/**
 * Generates the line segments of a hatch pattern clipped to its boundary,
 * the geometry AutoCAD EXPLODE turns a pattern hatch into.
 *
 * The layout matches the hatch renderers (pattern line offsets in
 * line-local space, `patternAngle` applied on top of the definition lines),
 * so the exploded lines coincide with the displayed pattern. Boundaries use
 * the even-odd rule.
 *
 * @param loops - Tessellated boundary loops in the hatch plane (OCS).
 * @param definitionLines - Pattern definition lines.
 * @param patternAngle - Extra rotation applied to the definition lines.
 * @returns The pattern segments in the hatch plane; dots are returned as
 *          segments with identical end points.
 */
export declare function acdbTessellateHatchPattern(loops: readonly (readonly AcGePoint2dLike[])[], definitionLines: readonly AcGiHatchPatternLine[], patternAngle?: number): AcDbHatchPatternSegment[];
//# sourceMappingURL=AcDbHatchPatternHelpers.d.ts.map