import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcGiMTextAttachmentPoint, AcGiMTextFlowDirection } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { type AcDbAnnotationScaleContext, type AcDbAnnotationScaleDrawInfo } from '../misc/AcDbAnnotationScale.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbEntityProperties } from './AcDbEntityProperties.js';
/**
 * Represents a multiline text (mtext) entity in AutoCAD.
 *
 * A multiline text entity is a 2D geometric object that displays formatted text
 * with support for multiple lines, word wrapping, and rich text formatting.
 * MText entities are more advanced than regular text entities and support
 * features like background fills, line spacing, and attachment points.
 *
 * @example
 * ```typescript
 * // Create a multiline text entity
 * const mtext = new AcDbMText();
 * mtext.contents = "This is a\nmultiline text\nwith formatting";
 * mtext.height = 2.5;
 * mtext.width = 20;
 * mtext.location = new AcGePoint3d(0, 0, 0);
 * mtext.attachmentPoint = AcGiMTextAttachmentPoint.TopLeft;
 *
 * // Access mtext properties
 * console.log(`Contents: ${mtext.contents}`);
 * console.log(`Height: ${mtext.height}`);
 * console.log(`Width: ${mtext.width}`);
 * ```
 */
export declare class AcDbMText extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The height of the text */
    private _height;
    /** The maximum width for word wrap formatting */
    private _width;
    /** Cached actual text extents width from the source drawing, when available */
    private _extentsWidth;
    /** The text contents */
    private _contents;
    /** The line spacing style */
    private _lineSpacingStyle;
    /** The line spacing factor */
    private _lineSpacingFactor;
    /** Whether background fill / mask is enabled (DXF group 90 ≠ 0) */
    private _backgroundFill;
    /**
     * When true, the mask uses the drawing / layout background colour
     * (DXF group 90 = 2 or 3) instead of {@link backgroundFillColor}.
     */
    private _useBackgroundColor;
    /** The background fill color (RGB integer, or ACI when ≤ 255) */
    private _backgroundFillColor;
    /** The background scale factor */
    private _backgroundScaleFactor;
    /** The background fill transparency */
    private _backgroundFillTransparency;
    /** The rotation angle in radians */
    private _rotation;
    /** The text style name */
    private _styleName;
    /** The location point of the text */
    private _location;
    /** The attachment point for the text */
    private _attachmentPoint;
    /** The direction vector of the text */
    private _direction;
    /** The drawing direction of the text */
    private _drawingDirection;
    /** Extrusion / plane normal (DXF group 210). */
    private _normal;
    /** Annotation height when embedded in ATTRIB (DXF group 46). */
    private _annotationHeight;
    /** Column type (DXF group 75). */
    private _columnType;
    /** Column count (DXF group 76). */
    private _columnCount;
    /** Column flow reversed (DXF group 78). */
    private _columnFlowReversed;
    /** Column auto height (DXF group 79). */
    private _columnAutoHeight;
    /** Column width (DXF group 48). */
    private _columnWidth;
    /** Column gutter (DXF group 49). */
    private _columnGutter;
    /**
     * Creates a new multiline text entity.
     *
     * This constructor initializes an mtext entity with default values.
     * The contents are empty, height and width are 0, and the location is at the origin.
     *
     * @example
     * ```typescript
     * const mtext = new AcDbMText();
     * mtext.contents = "Sample multiline text";
     * mtext.height = 3.0;
     * mtext.width = 15;
     * ```
     */
    constructor();
    /**
     * Gets the contents of the mtext object.
     *
     * This returns a string that contains the contents of the mtext object.
     * Formatting data used for word wrap calculations is removed.
     *
     * @returns The text contents
     *
     * @example
     * ```typescript
     * const contents = mtext.contents;
     * console.log(`Text contents: ${contents}`);
     * ```
     */
    get contents(): string;
    /**
     * Sets the contents of the mtext object.
     *
     * @param value - The new text contents
     *
     * @example
     * ```typescript
     * mtext.contents = "New multiline\ntext content";
     * ```
     */
    set contents(value: string);
    /**
     * Gets the height of the text.
     *
     * @returns The text height
     *
     * @example
     * ```typescript
     * const height = mtext.height;
     * console.log(`Text height: ${height}`);
     * ```
     */
    get height(): number;
    /**
     * Sets the height of the text.
     *
     * @param value - The new text height
     *
     * @example
     * ```typescript
     * mtext.height = 5.0;
     * ```
     */
    set height(value: number);
    /**
     * Whether this MTEXT is annotative (AcadAnnotative XDATA and/or scale contexts).
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    /**
     * Gets the maximum width setting used by the MText object for word wrap formatting.
     *
     * It is possible that none of the lines resulting from word wrap formatting will
     * reach this width value. Words which exceed this width value will not be broken,
     * but will extend beyond the given width.
     *
     * @returns The maximum width for word wrap
     *
     * @example
     * ```typescript
     * const width = mtext.width;
     * console.log(`Text width: ${width}`);
     * ```
     */
    get width(): number;
    /**
     * Sets the maximum width setting used by the MText object for word wrap formatting.
     *
     * @param value - The new maximum width for word wrap
     *
     * @example
     * ```typescript
     * mtext.width = 25;
     * ```
     */
    set width(value: number);
    /**
     * Gets the cached actual text extents width from the source file.
     *
     * When present, this reflects the rendered width of the MTEXT content and is
     * preferred over {@link width} (reference/wrap width) for layout calculations.
     */
    get extentsWidth(): number;
    set extentsWidth(value: number);
    /**
     * Gets the rotation angle of the text.
     *
     * The rotation angle is relative to the X axis of the text's OCS, with positive
     * angles going counterclockwise when looking down the Z axis toward the origin.
     *
     * @returns The rotation angle in radians
     *
     * @example
     * ```typescript
     * const rotation = mtext.rotation;
     * console.log(`Rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
     * ```
     */
    get rotation(): number;
    set rotation(value: number);
    /**
     * The line spacing factor (DXF group 44).
     *
     * Ratio of actual baseline spacing to AutoCAD single spacing
     * (`5/3` of text height). Valid range is typically 0.25–4.00; default is 1.0.
     */
    get lineSpacingFactor(): number;
    set lineSpacingFactor(value: number);
    /**
     * The line spacing style.
     */
    get lineSpacingStyle(): number;
    set lineSpacingStyle(value: number);
    /**
     * Toggle the background fill / mask on or off.
     *
     * Matches ObjectARX `AcDbMText::setBackgroundFill`: enabling fill without a
     * previously assigned colour leaves the default RGB (200,200,200). The colour
     * is not reset on every assignment so DXF / converter round-trips keep group
     * 63 / 421 values when group 90 is applied first or last.
     */
    get backgroundFill(): boolean;
    set backgroundFill(value: boolean);
    /**
     * When true, the mask uses the drawing window / layout background colour
     * (DXF group 90 = 2 or 3) instead of {@link backgroundFillColor}.
     */
    get useBackgroundColor(): boolean;
    set useBackgroundColor(value: boolean);
    /**
     * The background fill color. Valid only when background fill is enabled and
     * {@link useBackgroundColor} is false. Stored as an RGB integer; ACI indices
     * 1–255 are also accepted and resolved at draw / DXF-out time.
     */
    get backgroundFillColor(): number;
    set backgroundFillColor(value: number);
    /**
     * The background fill transparency. This property is valid only if background fill is enable.
     */
    get backgroundFillTransparency(): number;
    set backgroundFillTransparency(value: number);
    /**
     * Background mask border offset factor (DXF group 45).
     * `1.0` fits the text; values above `1` extend the mask by
     * `(factor - 1) × textHeight` on each side.
     */
    get backgroundScaleFactor(): number;
    set backgroundScaleFactor(value: number);
    /**
     * The style name stored in text ttyle table record and used by this text entity
     */
    get styleName(): string;
    set styleName(value: string);
    /**
     * The insertion point of this mtext entity.
     */
    get location(): AcGePoint3dLike;
    set location(value: AcGePoint3dLike);
    /**
     * The attachment point value which determines how the text will be oriented around the insertion point
     * of the mtext object. For example, if the attachment point is AcGiAttachmentPoint.MiddleCenter, then
     * the text body will be displayed such that the insertion point appears at the geometric center of the
     * text body.
     */
    get attachmentPoint(): AcGiMTextAttachmentPoint;
    set attachmentPoint(value: AcGiMTextAttachmentPoint);
    /**
     * Represent the X axis ("horizontal") for the text. This direction vector is used to determine the text
     * flow direction.
     */
    get direction(): AcGeVector3d;
    set direction(value: AcGeVector3dLike);
    get drawingDirection(): AcGiMTextFlowDirection;
    set drawingDirection(value: AcGiMTextFlowDirection);
    /** Extrusion / plane normal (DXF group 210). */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /** Annotation height when MTEXT is embedded in ATTRIB (DXF group 46). */
    get annotationHeight(): number;
    set annotationHeight(value: number);
    /** Column type (DXF group 75). */
    get columnType(): number;
    set columnType(value: number);
    /** Column count (DXF group 76). */
    get columnCount(): number;
    set columnCount(value: number);
    /** Whether column flow is reversed (DXF group 78). */
    get columnFlowReversed(): boolean;
    set columnFlowReversed(value: boolean);
    /** Whether columns use auto height (DXF group 79). */
    get columnAutoHeight(): boolean;
    set columnAutoHeight(value: boolean);
    /** Column width (DXF group 48). */
    get columnWidth(): number;
    set columnWidth(value: number);
    /** Column gutter (DXF group 49). */
    get columnGutter(): number;
    set columnGutter(value: number);
    /**
     * Resolves height / width / insertion / orientation for the active
     * annotation scale (CANNOSCALE), matching {@link subWorldDraw}.
     */
    resolveAnnotativePresentation(): {
        height: number;
        width: number;
        extentsWidth: number;
        position: AcGePoint3d;
        direction: AcGeVector3d;
        attachmentPoint: AcGiMTextAttachmentPoint;
        preferred?: AcDbAnnotationScaleContext;
        annotationScale?: AcDbAnnotationScaleDrawInfo;
    };
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this mtext entity.
     *
     * @returns Array containing the mtext location (insertion point).
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this mtext.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this mtext by the specified matrix.
     *
     * When `matrix` is a mirror, **MIRRTEXT** controls whether the paragraph
     * stays readable (`0`, default) or is truly mirrored (`1`).
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns a transformed copy, applying **MIRRTEXT** from this entity's
     * database (not the detached clone's).
     */
    getTransformedCopy(matrix: AcGeMatrix3d): this;
    /**
     * Geometric MTEXT transform plus an explicit MIRRTEXT policy value.
     */
    private transformByWithMirrtext;
    /**
     * Explodes this multiline text into one single-line {@link AcDbText} per
     * displayed line, like AutoCAD EXPLODE.
     *
     * Paragraphs are split at paragraph breaks and wrapped to the defined
     * width, lines are spaced with the line-spacing factor and justified
     * according to the attachment point (left / center / right). Inline
     * formatting (fonts, colors, heights inside the text) is not kept, and
     * wrapping uses estimated character widths, so line breaks approximate the
     * font-accurate breaks AutoCAD computes. Empty lines produce no text.
     */
    protected subExplode(): AcDbEntity[];
    /**
     * Returns the full property definition for this mtext entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the mtext in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    private getTextStyle;
    /**
     * Draws this entity using the specified renderer.
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true.
     * @returns The rendered entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): import("@mlightcad/graphic-interface").AcGiEntity | undefined;
    /**
     * Draws the object-level MTEXT background mask (DXF groups 90 / 63 / 45 / 421).
     *
     * The mask covers the whole MTEXT rectangle — AutoCAD does not support
     * per-run masking inside a single MTEXT entity.
     */
    private drawBackgroundMask;
    /**
     * Resolves the mask fill colour from the stored RGB / ACI integer.
     *
     * ACI indices stay as ByACI so ACI 7 remains foreground and the renderer
     * can contrast it against the current canvas / layout background.
     */
    private resolveBackgroundFillColor;
    private encodeMTextContentsForDxf;
    /**
     * Adds the text style this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Translates the text style name of a cloned entity.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private finishMTextDxfIn;
}
//# sourceMappingURL=AcDbMText.d.ts.map