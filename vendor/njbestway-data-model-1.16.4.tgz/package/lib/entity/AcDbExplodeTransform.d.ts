import { AcGeMatrix3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import type { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord.js';
import { AcDbEntity } from './AcDbEntity.js';
/**
 * Returns whether `matrix` maps the plane with `normal` conformally, i.e.
 * without non-uniform scaling or shear inside that plane. Circles and arcs in
 * such a plane stay circles and arcs under `matrix`.
 *
 * Only the in-plane behavior matters: a block inserted with scale
 * `(2, 2, 1)` is conformal for the planar entities drawn in its XY plane.
 *
 * @param matrix - Transformation matrix.
 * @param normal - Normal of the plane to test.
 * @returns `true` when the plane is scaled uniformly (rotation, mirror and
 *          uniform scale only).
 */
export declare function acdbIsConformalInPlane(matrix: AcGeMatrix3d, normal: AcGeVector3dLike): boolean;
/**
 * Returns a transformed copy of `entity` for exploding a block-like container
 * (INSERT, dimension, table, ...) whose content is mapped by `matrix`.
 *
 * Most entities are simply cloned and passed to
 * {@link AcDbEntity.transformBy}. When the transform scales the entity plane
 * non-uniformly, entities that cannot represent the result are converted
 * exactly, the way AutoCAD EXPLODE does for non-uniformly scaled blocks:
 *
 * - circles and arcs become ellipses / elliptical arcs
 * - ellipses get correct principal axes
 * - polylines with arc segments are exploded first and their arcs become
 *   elliptical arcs (a polyline cannot hold an elliptical segment)
 *
 * Other entities (text, nested block references, hatches, ...) fall back to
 * their own `transformBy`, which approximates a non-uniform scale.
 *
 * @param entity - Source entity, typically owned by a block table record. It
 *   is not modified.
 * @param matrix - Transform from the container's local space to WCS.
 * @returns The transformed, non-database-resident entities.
 */
export declare function acdbTransformForExplode(entity: AcDbEntity, matrix: AcGeMatrix3d): AcDbEntity[];
/**
 * Explodes the content of a block table record mapped into WCS by `matrix`:
 * every entity of the block is transformed with
 * {@link acdbTransformForExplode}.
 *
 * @param block - Block whose entities are exploded.
 * @param matrix - Transform from block space to WCS (including the block base
 *   point compensation).
 * @param filter - Optional predicate that skips entities returning `false`.
 * @returns The transformed, non-database-resident entities.
 */
export declare function acdbExplodeBlockContent(block: AcDbBlockTableRecord, matrix: AcGeMatrix3d, filter?: (entity: AcDbEntity) => boolean): AcDbEntity[];
/**
 * Resolves the layer-0 / ByBlock properties of an entity exploded out of an
 * annotation object (dimension, leader, table, ...) against that object.
 *
 * The anonymous blocks of annotation objects are drawn with layer `0` and
 * ByBlock properties so that they follow the owning object. AutoCAD EXPLODE
 * keeps the look of such objects: the parts end up on the object's layer with
 * its color, linetype, lineweight and transparency.
 *
 * Block references are deliberately not resolved this way: exploding an
 * INSERT keeps layer `0` and ByBlock values unchanged, as in AutoCAD.
 *
 * @param entity - Exploded entity to update.
 * @param owner - Annotation object it was exploded from.
 * @returns The updated entity.
 */
export declare function acdbResolveByBlockProperties<T extends AcDbEntity>(entity: T, owner: AcDbEntity): T;
//# sourceMappingURL=AcDbExplodeTransform.d.ts.map