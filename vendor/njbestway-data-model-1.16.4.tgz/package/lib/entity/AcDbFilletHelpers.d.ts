import { AcGeFillet2dError, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbArc } from './AcDbArc.js';
import { AcDbCircle } from './AcDbCircle.js';
import { AcDbEllipse } from './AcDbEllipse.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbLine } from './AcDbLine.js';
import { AcDbPolyline } from './AcDbPolyline.js';
import { AcDbRay } from './AcDbRay.js';
import { AcDbSpline } from './AcDbSpline.js';
import { AcDbXline } from './AcDbXline.js';
/**
 * Options for {@link acdbFilletTwoEntities}.
 */
export interface AcDbFilletOptions {
    /** Fillet radius (0 = sharp corner). */
    radius: number;
    /** When true, trim/extend the operands to the fillet ends (default true). */
    trim?: boolean;
    /**
     * When true (AutoCAD FILLETPOLYARC default), FILLET Polyline also fillets
     * corners that involve arc (bulge) segments. When false, only straight–straight
     * corners are filleted (legacy AutoCAD 2014 and earlier).
     */
    filletPolyArc?: boolean;
}
/**
 * Result of filleting two entities.
 */
export interface AcDbFilletTwoResult {
    /** Newly created entities (fillet arc, and replacements for xline→ray/line). */
    created: AcDbEntity[];
    /** Entities that should be erased (e.g. converted xlines). */
    erase: AcDbEntity[];
    /** Entities that were mutated in place. */
    modified: AcDbEntity[];
}
/**
 * Result of filleting every eligible vertex of a polyline.
 */
export interface AcDbFilletPolylineResult {
    /** Number of vertices successfully filleted. */
    filleted: number;
    /** Number of vertices skipped (too short, parallel, arc segment, …). */
    skipped: number;
}
export type AcDbFilletableEntity = AcDbLine | AcDbArc | AcDbCircle | AcDbEllipse | AcDbPolyline | AcDbSpline | AcDbRay | AcDbXline;
/**
 * Returns true when the entity can participate in FILLET.
 */
export declare function acdbIsFilletableEntity(entity: AcDbEntity): entity is AcDbFilletableEntity;
/**
 * Builds transient fillet preview geometry without mutating the drawing.
 *
 * Used when COMMANDPREVIEW is on: returns the would-be fillet arc
 * (empty when radius is 0 or no solution exists).
 */
export declare function acdbPreviewFilletTwoEntities(e1: AcDbEntity, pick1: AcGePoint3dLike, e2: AcDbEntity, pick2: AcGePoint3dLike, options: AcDbFilletOptions): AcDbEntity[];
/**
 * Fillets two entities (or two polyline segments) using AutoCAD-like rules.
 *
 * Mutates operands in place when possible. Circles are never trimmed. Xlines
 * may be converted to rays or lines (returned in `created` / `erase`).
 *
 * @param e1 - First selected entity
 * @param pick1 - Pick point on the first entity
 * @param e2 - Second selected entity
 * @param pick2 - Pick point on the second entity
 * @param options - Radius and trim mode
 */
export declare function acdbFilletTwoEntities(e1: AcDbEntity, pick1: AcGePoint3dLike, e2: AcDbEntity, pick2: AcGePoint3dLike, options: AcDbFilletOptions): {
    ok: true;
    result: AcDbFilletTwoResult;
} | {
    ok: false;
    error: AcGeFillet2dError;
};
/**
 * Inserts fillets at every eligible vertex of a 2D polyline.
 *
 * When {@link AcDbFilletOptions.filletPolyArc} is false (FILLETPOLYARC = 0),
 * only straight–straight corners are filleted. When true (default), corners
 * involving bulge arcs are also attempted.
 *
 * @param pline - Polyline to mutate
 * @param options - Radius, trim, and FILLETPOLYARC policy
 * @param onlyCorner - When set, fillet only this vertex index (AutoCAD two-segment pick)
 */
export declare function acdbFilletPolyline(pline: AcDbPolyline, options: AcDbFilletOptions, onlyCorner?: number): AcDbFilletPolylineResult;
//# sourceMappingURL=AcDbFilletHelpers.d.ts.map