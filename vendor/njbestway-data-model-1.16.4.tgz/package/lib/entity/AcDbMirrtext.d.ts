import { AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import type { AcDbObject } from '../base/AcDbObject.js';
/** Axis-aligned bounds in a text entity's local frame. */
export interface AcDbTextLocalBounds {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}
/**
 * Resolves **MIRRTEXT** for an entity: `1` means truly mirror text, anything
 * else (including missing database) means keep text readable (AutoCAD default).
 */
export declare function acdbResolveMirrtext(entity: AcDbObject): number;
/**
 * Computes the readable-text insertion anchor after a mirror so the glyphs
 * occupy the mirrored image of the pre-transform text box.
 *
 * AutoCAD **MIRRTEXT = 0** keeps justification/attachment and reading
 * direction, but relocates the anchor into the mirrored box (e.g. left
 * TEXT at x=10 with width w ends at −(10+w), not −10).
 *
 * @param matrix - Mirroring transform applied to the entity.
 * @param oldAnchor - Pre-transform drawing anchor (insertion / alignment).
 * @param oldRotation - Pre-transform rotation in radians.
 * @param oldDirection - Optional pre-transform direction (MTEXT).
 * @param bounds - Local box relative to `oldAnchor` before the transform.
 * @param newRotation - Post-policy readable rotation.
 * @param newDirection - Optional post-policy readable direction (MTEXT).
 * @returns World-space anchor for the same attachment in the mirrored box.
 */
export declare function acdbComputeMirroredReadableAnchor(matrix: AcGeMatrix3d, oldAnchor: AcGePoint3dLike, oldRotation: number, oldDirection: AcGeVector3dLike | undefined, bounds: AcDbTextLocalBounds, newRotation: number, newDirection?: AcGeVector3dLike): AcGePoint3d;
/**
 * Applies AutoCAD MIRRTEXT policy to a TEXT-like entity after its geometric
 * axes have already been transformed by a mirroring matrix.
 *
 * - **MIRRTEXT = 0**: reorient so glyphs stay readable (clear generation
 *   flags; add π to rotation when the baseline was reversed). TEXT callers
 *   then swap Left↔Right justification; MTEXT callers rematch the anchor
 *   with {@link acdbComputeMirroredReadableAnchor}.
 * - **MIRRTEXT = 1**: encode the mirror into `isBackward` / `isUpsideDown`.
 *
 * Also updates `normal` via {@link acdbTransformNormal}.
 */
export declare function acdbApplyTextMirrtextPolicy(text: {
    rotation: number;
    isBackward: boolean;
    isUpsideDown: boolean;
    normal: AcGeVector3d;
}, matrix: AcGeMatrix3d, xAxis: AcGeVector3d, yAxis: AcGeVector3d, mirrtext: number): void;
/**
 * Applies AutoCAD MIRRTEXT policy to MTEXT after its geometric transform.
 *
 * - **MIRRTEXT = 0**: if the direction was flipped into a mirrored orientation,
 *   add π so the paragraph stays readable. Callers must then rematch the
 *   insertion point with {@link acdbComputeMirroredReadableAnchor}.
 * - **MIRRTEXT = 1**: leave the geometrically mirrored direction as-is.
 *
 * Normal is already updated by MTEXT `transformBy` via `acdbTransformNormal`.
 */
export declare function acdbApplyMTextMirrtextPolicy(mtext: {
    rotation: number;
    direction: AcGeVector3d;
}, matrix: AcGeMatrix3d, xAxis: AcGeVector3d, yAxis: AcGeVector3d, mirrtext: number): void;
//# sourceMappingURL=AcDbMirrtext.d.ts.map