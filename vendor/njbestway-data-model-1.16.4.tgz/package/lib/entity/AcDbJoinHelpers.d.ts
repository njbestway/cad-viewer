import { AcGePoint3d, AcGeTol } from '@mlightcad/geometry-engine';
import { AcDbArc } from './AcDbArc.js';
import { AcDbCircle } from './AcDbCircle.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbLine } from './AcDbLine.js';
import { AcDbPolyline } from './AcDbPolyline.js';
/**
 * One successfully merged group from {@link acdbJoinAllEntities}.
 */
export interface AcDbJoinGroup {
    /** Newly created join result (non-database-resident). */
    result: AcDbEntity;
    /** Source entities merged into `result` (≥2). */
    sources: AcDbEntity[];
}
/**
 * Result of {@link acdbJoinAllEntities}: one entry per merged group.
 */
export interface AcDbJoinAllResult {
    /** Successfully joined groups. */
    groups: AcDbJoinGroup[];
    /** Flattened list of every source entity that was consumed. */
    consumed: AcDbEntity[];
}
/** Open curve that JOIN can consider in this v1. */
export type AcDbJoinableCurve = AcDbLine | AcDbArc | AcDbPolyline;
interface AcDbJoinEndpoints {
    start: AcGePoint3d;
    end: AcGePoint3d;
}
/**
 * Returns true when `entity` is an open Line, Arc, or LWPOLYLINE that JOIN
 * may attempt to merge.
 */
export declare function acdbIsJoinableEntity(entity: AcDbEntity): entity is AcDbJoinableCurve;
/**
 * Start / end points of an open joinable curve in WCS.
 */
export declare function acdbJoinEndpointsOf(entity: AcDbJoinableCurve): AcDbJoinEndpoints;
/**
 * Joins collinear open lines into one line spanning their union. Gaps between
 * endpoints are filled, matching AutoCAD JOIN for lines. Returns `undefined`
 * when fewer than two lines are collinear with `primary`.
 */
export declare function acdbJoinCollinearLines(primary: AcDbLine, others: readonly AcDbEntity[], tol?: AcGeTol): AcDbLine | undefined;
/**
 * Joins coplanar arcs that share center and radius into one arc, or a circle
 * when the joined span covers a full turn. Gaps are filled by lengthening
 * counter-clockwise from `primary`, matching AutoCAD JOIN.
 */
export declare function acdbJoinConcentricArcs(primary: AcDbArc, others: readonly AcDbEntity[], tol?: AcGeTol): AcDbArc | AcDbCircle | undefined;
/**
 * Joins contiguous coplanar lines, arcs and open polylines that share
 * endpoints with `primary` into one LWPOLYLINE. Non-touching candidates are
 * ignored. Returns `undefined` when nothing can be chained onto `primary`.
 */
export declare function acdbJoinToPolyline(primary: AcDbJoinableCurve, others: readonly AcDbEntity[], tol?: AcGeTol): AcDbPolyline | undefined;
/**
 * AutoCAD-style multi-select JOIN over a set of entities with no designated
 * source object. Produces one result per mergeable group:
 * - collinear lines → line
 * - concentric arcs → arc / circle
 * - contiguous mixed curves → polyline
 *
 * Sources that cannot join remain unconsumed.
 */
export declare function acdbJoinAllEntities(entities: readonly AcDbEntity[], tol?: AcGeTol): AcDbJoinAllResult;
export {};
//# sourceMappingURL=AcDbJoinHelpers.d.ts.map