import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiMTextAttachmentPoint, AcGiRenderer, AcGiTextStyle } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { type AcDbAnnotationScaleContext, type AcDbAnnotationScaleDrawInfo } from '../misc/AcDbAnnotationScale.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbEntityProperties } from './AcDbEntityProperties.js';
/**
 * Defines the horizontal alignment mode for text entities.
 */
export declare enum AcDbTextHorizontalMode {
    /** Left-aligned text */
    LEFT = 0,
    /** Center-aligned text */
    CENTER = 1,
    /** Right-aligned text */
    RIGHT = 2,
    /** Aligned text (fits between two points) */
    ALIGNED = 3,
    /** Middle-aligned text */
    MIDDLE = 4,
    /** Fit text (scales to fit between two points) */
    FIT = 5
}
/**
 * Defines the vertical alignment mode for text entities.
 */
export declare enum AcDbTextVerticalMode {
    /** Baseline-aligned text */
    BASELINE = 0,
    /** Bottom-aligned text */
    BOTTOM = 1,
    /** Middle-aligned text */
    MIDDLE = 2,
    /** Top-aligned text */
    TOP = 3
}
/**
 * Represents a text entity in AutoCAD.
 *
 * A text entity is a 2D geometric object that displays text strings in drawings.
 * Text entities can have various properties including position, height, rotation,
 * alignment, and style. Text is always drawn in the plane defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a text entity
 * const text = new AcDbText();
 * text.textString = "Hello, World!";
 * text.position = new AcGePoint3d(0, 0, 0);
 * text.height = 2.5;
 * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
 * text.verticalMode = AcDbTextVerticalMode.BASELINE;
 *
 * // Access text properties
 * console.log(`Text: ${text.textString}`);
 * console.log(`Position: ${text.position}`);
 * console.log(`Height: ${text.height}`);
 * ```
 */
export declare class AcDbText extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The text string content */
    private _textString;
    /** The thickness (extrusion) of the text */
    private _thickness;
    /** The height of the text */
    private _height;
    /** The insertion point of the text (DXF group 10). */
    private _position;
    /**
     * The alignment point of the text (DXF group 11).
     *
     * Used when {@link horizontalMode} is not LEFT or {@link verticalMode} is
     * not BASELINE. Mirrors `AcDbText::alignmentPoint` in ObjectARX.
     */
    private _alignmentPoint;
    /**
     * Whether the alignment point was explicitly provided by the source file
     * (DXF group 11 / DWG) or set through the API.
     *
     * Parse paths mirror {@link _position} into {@link _alignmentPoint} when
     * group 11 is absent, so coordinate equality cannot tell "unset" apart
     * from a spec-compliant file whose group 11 happens to equal group 10
     * (e.g. everything written by ezdxf's `Text.set_placement`). This flag is
     * the source of truth used by {@link resolveTextAnchor}.
     */
    private _hasAlignmentPoint;
    /** The rotation angle of the text */
    private _rotation;
    /** The oblique angle of the text */
    private _oblique;
    /** The horizontal alignment mode */
    private _horizontalMode;
    /** The vertical alignment mode */
    private _verticalModel;
    /** The text style name */
    private _styleName;
    /** The width factor (scale) of the text */
    private _widthFactor;
    /**
     * Text generation flags (DXF group 71).
     * Bit 2 = backward (mirrored in X); bit 4 = upside down (mirrored in Y).
     */
    private _generationFlag;
    /** Extrusion / plane normal (DXF group 210). */
    private _normal;
    /**
     * Creates a new text entity.
     *
     * This constructor initializes a text entity with default values.
     * The text string is empty, height is 0, and position is at the origin.
     *
     * @example
     * ```typescript
     * const text = new AcDbText();
     * text.textString = "Sample Text";
     * text.position = new AcGePoint3d(10, 20, 0);
     * text.height = 3.0;
     * ```
     */
    constructor();
    /**
     * Gets the text string content of this entity.
     *
     * @returns The text string
     *
     * @example
     * ```typescript
     * const content = text.textString;
     * console.log(`Text content: ${content}`);
     * ```
     */
    get textString(): string;
    /**
     * Sets the text string content of this entity.
     *
     * @param value - The new text string
     *
     * @example
     * ```typescript
     * text.textString = "New text content";
     * ```
     */
    set textString(value: string);
    /**
     * Gets the thickness of the text.
     *
     * The thickness is the text's dimension along its normal vector direction
     * (sometimes called the extrusion direction).
     *
     * @returns The thickness value
     *
     * @example
     * ```typescript
     * const thickness = text.thickness;
     * console.log(`Text thickness: ${thickness}`);
     * ```
     */
    get thickness(): number;
    /**
     * Sets the thickness of the text.
     *
     * @param value - The new thickness value
     *
     * @example
     * ```typescript
     * text.thickness = 2.0;
     * ```
     */
    set thickness(value: number);
    /**
     * Gets the height of the text.
     *
     * The height value is used as a scale factor for both height and width
     * of the text.
     *
     * @returns The height value
     *
     * @example
     * ```typescript
     * const height = text.height;
     * console.log(`Text height: ${height}`);
     * ```
     */
    get height(): number;
    /**
     * Whether this TEXT is annotative (AcadAnnotative XDATA and/or scale contexts).
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    /**
     * Sets the height of the text.
     *
     * @param value - The new height value
     *
     * @example
     * ```typescript
     * text.height = 5.0;
     * ```
     */
    set height(value: number);
    /**
     * Gets the insertion point of the text in WCS coordinates.
     *
     * @returns The insertion point as a 3D point
     *
     * @example
     * ```typescript
     * const position = text.position;
     * console.log(`Text position: ${position.x}, ${position.y}, ${position.z}`);
     * ```
     */
    get position(): AcGePoint3d;
    /**
     * Sets the insertion point of the text in WCS coordinates.
     *
     * @param value - The new insertion point
     *
     * @example
     * ```typescript
     * text.position = new AcGePoint3d(15, 25, 0);
     * ```
     */
    set position(value: AcGePoint3d);
    /**
     * Gets the alignment point of the text in WCS coordinates.
     *
     * The alignment point is the placement anchor used when
     * {@link horizontalMode} is not {@link AcDbTextHorizontalMode.LEFT} or
     * {@link verticalMode} is not {@link AcDbTextVerticalMode.BASELINE}. For
     * a Middle/Center text, for example, this is the centroid of the text's
     * bounding box. Mirrors `AcDbText::alignmentPoint` in ObjectARX and maps
     * to DXF group code 11.
     *
     * When the horizontal/vertical modes are at their defaults, the alignment
     * point is unused and typically equals {@link position}.
     *
     * @returns The alignment point as a 3D point
     */
    get alignmentPoint(): AcGePoint3d;
    /**
     * Sets the alignment point of the text in WCS coordinates.
     *
     * Setting an alignment point through the API marks it as explicitly
     * provided (see {@link hasAlignmentPoint}).
     *
     * @param value - The new alignment point
     */
    set alignmentPoint(value: AcGePoint3d);
    /**
     * Whether the alignment point was explicitly provided by the source file
     * or through the API, as opposed to mirrored from {@link position} by a
     * parse-time fallback when group 11 is absent.
     */
    get hasAlignmentPoint(): boolean;
    /**
     * Marks whether the alignment point is explicitly provided. Parse paths
     * (DXF/DWG converters) set this after assigning {@link alignmentPoint}.
     */
    set hasAlignmentPoint(value: boolean);
    /**
     * Gets the rotation angle of the text.
     *
     * The rotation angle is relative to the X axis of the text's OCS,
     * with positive angles going counterclockwise when looking down the Z axis
     * toward the origin.
     *
     * @returns The rotation angle in radians
     *
     * @example
     * ```typescript
     * const rotation = text.rotation;
     * console.log(`Text rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
     * ```
     */
    get rotation(): number;
    /**
     * Sets the rotation angle of the text.
     *
     * @param value - The new rotation angle in radians
     *
     * @example
     * ```typescript
     * text.rotation = Math.PI / 4; // 45 degrees
     * ```
     */
    set rotation(value: number);
    /**
     * Gets the oblique angle of the text.
     *
     * The oblique angle is the angle from the text's vertical; that is, the top
     * of the text "slants" relative to the bottom, similar to italic text.
     * Positive angles slant characters forward at their tops.
     *
     * @returns The oblique angle in radians
     *
     * @example
     * ```typescript
     * const oblique = text.oblique;
     * console.log(`Text oblique angle: ${oblique} radians`);
     * ```
     */
    get oblique(): number;
    /**
     * Sets the oblique angle of the text.
     *
     * @param value - The new oblique angle in radians
     *
     * @example
     * ```typescript
     * text.oblique = Math.PI / 6; // 30 degrees
     * ```
     */
    set oblique(value: number);
    /**
     * Gets the horizontal alignment mode of the text.
     *
     * @returns The horizontal alignment mode
     *
     * @example
     * ```typescript
     * const horizontalMode = text.horizontalMode;
     * console.log(`Horizontal mode: ${horizontalMode}`);
     * ```
     */
    get horizontalMode(): AcDbTextHorizontalMode;
    /**
     * Sets the horizontal alignment mode of the text.
     *
     * @param value - The new horizontal alignment mode
     *
     * @example
     * ```typescript
     * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
     * ```
     */
    set horizontalMode(value: AcDbTextHorizontalMode);
    /**
     * Gets the vertical alignment mode of the text.
     *
     * @returns The vertical alignment mode
     *
     * @example
     * ```typescript
     * const verticalMode = text.verticalMode;
     * console.log(`Vertical mode: ${verticalMode}`);
     * ```
     */
    get verticalMode(): AcDbTextVerticalMode;
    /**
     * Sets the vertical alignment mode of the text.
     *
     * @param value - The new vertical alignment mode
     *
     * @example
     * ```typescript
     * text.verticalMode = AcDbTextVerticalMode.BASELINE;
     * ```
     */
    set verticalMode(value: AcDbTextVerticalMode);
    /**
     * Gets the style name used by this text entity.
     *
     * @returns The text style name
     *
     * @example
     * ```typescript
     * const styleName = text.styleName;
     * console.log(`Text style: ${styleName}`);
     * ```
     */
    get styleName(): string;
    /**
     * Sets the style name for this text entity.
     *
     * @param value - The new text style name
     *
     * @example
     * ```typescript
     * text.styleName = DEFAULT_TEXT_STYLE;
     * ```
     */
    set styleName(value: string);
    /**
     * Gets the width factor of the text.
     *
     * The width factor is applied to the text's width to allow the width to be
     * adjusted independently of the height. For example, if the widthFactor value
     * is 0.8, then the text is drawn with a width that is 80% of its normal width.
     *
     * @returns The width factor value
     *
     * @example
     * ```typescript
     * const widthFactor = text.widthFactor;
     * console.log(`Width factor: ${widthFactor}`);
     * ```
     */
    get widthFactor(): number;
    /**
     * Sets the width factor of the text.
     *
     * @param value - The new width factor value
     *
     * @example
     * ```typescript
     * text.widthFactor = 0.8; // 80% width
     * ```
     */
    set widthFactor(value: number);
    /**
     * Text generation flags (DXF group 71).
     * Bit 2 = backward; bit 4 = upside down.
     */
    get generationFlag(): number;
    set generationFlag(value: number);
    /** True when the text is mirrored in X (generation flag bit 2). */
    get isBackward(): boolean;
    set isBackward(value: boolean);
    /** True when the text is mirrored in Y (generation flag bit 4). */
    get isUpsideDown(): boolean;
    set isUpsideDown(value: boolean);
    /** Extrusion / plane normal (DXF group 210). */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the geometric extents (bounding box) of this text.
     *
     * @returns The bounding box that encompasses the text
     *
     * @example
     * ```typescript
     * const extents = text.geometricExtents;
     * console.log(`Text bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this text entity.
     *
     * Uses the same WCS anchor as drawing / extents ({@link resolveTextAnchor}):
     * group 10 for LEFT+BASELINE, otherwise group 11 (`alignmentPoint`) when set.
     * Returning only group 10 made Middle/Center TEXT show the grip inside the
     * glyph run (near the DXF second point) instead of at the visible attachment.
     *
     * @returns Array containing the text placement anchor.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this text.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this text by the specified matrix.
     *
     * When `matrix` is a mirror, **MIRRTEXT** controls whether glyphs stay
     * readable (`0`, default) or are truly mirrored (`1`).
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns a transformed copy, applying **MIRRTEXT** from this entity's
     * database (not the detached clone's).
     */
    getTransformedCopy(matrix: AcGeMatrix3d): this;
    /**
     * Geometric TEXT transform plus an explicit MIRRTEXT policy value.
     *
     * Prefer {@link transformBy} / {@link getTransformedCopy} so MIRRTEXT is
     * taken from the entity database. Use this when the policy must be supplied
     * explicitly (for example a detached clone that no longer sees the drawing
     * sysvar).
     *
     * @param matrix - WCS transform.
     * @param mirrtext - `0` readable, `1` true mirror.
     */
    transformByWithMirrtext(matrix: AcGeMatrix3d, mirrtext: number): this;
    /**
     * Swaps Left↔Right justification after a readable mirror whose baseline
     * points the opposite way (vertical-ish mirror line).
     */
    private applyReadableMirrorJustification;
    /**
     * Returns the full property definition for this text entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the text in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Justified text is drawn from {@link alignmentPoint}. Before switching
     * away from LEFT/BASELINE, give text without one an alignment point at its
     * insertion point so it does not jump to the origin.
     */
    private ensureAlignmentPoint;
    /**
     * Builds text/geometry property groups shared by TEXT, ATTRIB, and ATTDEF.
     */
    protected getTextProperties(): AcDbEntityProperties;
    /**
     * Gets the text style for this text entity.
     *
     * This method retrieves the text style from the text style table.
     * If the specified style is not found, it falls back to the 'STANDARD' style.
     *
     * @returns The text style object
     *
     * @example
     * ```typescript
     * const textStyle = text.getTextStyle();
     * ```
     */
    protected getTextStyle(): AcGiTextStyle;
    /**
     * Draws this text using the specified renderer.
     *
     * This method renders the text as a multiline text entity using the text's
     * current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true.
     * @returns The rendered text entity, or undefined if drawing failed
     */
    /**
     * Resolves height / anchor / rotation for the active CANNOSCALE when this
     * TEXT is annotative.
     */
    resolveAnnotativePresentation(): {
        height: number;
        position: AcGePoint3d;
        attachmentPoint: AcGiMTextAttachmentPoint;
        rotation: number;
        preferred?: AcDbAnnotationScaleContext;
        annotationScale?: AcDbAnnotationScaleDrawInfo;
    };
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Maps an OCS text point into WCS using {@link normal}.
     */
    private pointToWcs;
    /**
     * Plan-view drawing adjustments for entity extrusion and generation flags.
     *
     * For extrusion (0,0,-1) the flat WCS equivalent is an XY mirror: negate
     * rotation and width factor (see issue #226). Other extrusions map the OCS
     * X axis into WCS for rotation only.
     *
     * Entity generation flags (DXF group 71) are applied here because the
     * mtext renderer has no separate glyph-mirror path: `isBackward` negates
     * `widthFactor` (X mirror along the baseline); `isUpsideDown` adds π and
     * another widthFactor flip (Y mirror about the baseline).
     */
    private extrusionDrawingAdjust;
    /**
     * Resolves the anchor point and attachment used for rendering and extents.
     *
     * For default LEFT + BASELINE, `position` (group 10) is the anchor.
     * For other alignments, `alignmentPoint` (group 11) is used when set.
     * When group 11 is missing, falls back to LEFT/BASELINE at `position`.
     */
    private resolveTextAnchor;
    /**
     * Maps the (horizontal, vertical) DXF alignment modes of this TEXT/ATTRIB
     * to the matching {@link AcGiMTextAttachmentPoint}.
     *
     * The DXF spec uses two orthogonal axes (group 72 + group 73), with the
     * special-case `halign=MIDDLE (4)` collapsing both to a single centroid
     * placement. The renderer accepts the standard 3×3 + Baseline matrix
     * (TopLeft … BaselineRight). This function translates between the two.
     *
     * For default LEFT + BASELINE we return `BaselineLeft` and the caller
     * uses `position` (group 10) as the anchor. For every other case we
     * return the matching attachment and the caller passes
     * `alignmentPoint` (group 11) — the DXF placement anchor — to the
     * renderer.
     */
    private resolveAttachmentPoint;
    /**
     * Adds the text style this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Translates the text style name of a cloned entity.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private finishTextDxfIn;
}
//# sourceMappingURL=AcDbText.d.ts.map