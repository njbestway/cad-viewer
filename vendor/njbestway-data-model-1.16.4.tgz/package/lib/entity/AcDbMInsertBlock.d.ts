import { AcGeMatrix3d, AcGeVector2d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbBlockReference } from './AcDbBlockReference.js';
import { AcDbEntityRuntimeProperty } from './AcDbEntityProperties.js';
/**
 * Represents a MINSERT entity (multiple block reference) in AutoCAD.
 *
 * A MINSERT is a block reference that displays its block table record as a
 * rectangular array of `rows × columns` instances. The array is laid out in
 * the block reference's OCS and is rotated together with the reference by
 * {@link rotation}: instance `(row, column)` is displaced by
 * `column * columnSpacing` along the rotated X axis and `row * rowSpacing`
 * along the rotated Y axis. The spacing values are expressed in drawing units
 * and are not affected by {@link scaleFactors}.
 *
 * This class mirrors `AcDbMInsertBlock` in ObjectARX. Like AutoCAD, it is
 * written to DXF as an `INSERT` entity with the `AcDbMInsertBlock` subclass
 * marker.
 *
 * @example
 * ```typescript
 * // Create a 3 x 4 array of "Desk" blocks
 * const minsert = new AcDbMInsertBlock('Desk', 4, 3, 1200, 800)
 * minsert.position = new AcGePoint3d(0, 0, 0)
 * minsert.rotation = Math.PI / 2
 *
 * console.log(`Columns: ${minsert.columns}, rows: ${minsert.rows}`)
 * ```
 */
export declare class AcDbMInsertBlock extends AcDbBlockReference {
    /** The entity type name */
    static typeName: string;
    /** The number of columns in the array (DXF group 70) */
    private _columns;
    /** The number of rows in the array (DXF group 71) */
    private _rows;
    /** The distance between columns (DXF group 44) */
    private _columnSpacing;
    /** The distance between rows (DXF group 45) */
    private _rowSpacing;
    /**
     * Creates a new MINSERT entity.
     *
     * @param blockName - The name of the block table record to reference
     * @param columns - The number of columns (at least 1)
     * @param rows - The number of rows (at least 1)
     * @param columnSpacing - The distance between columns
     * @param rowSpacing - The distance between rows
     */
    constructor(blockName: string, columns?: number, rows?: number, columnSpacing?: number, rowSpacing?: number);
    /**
     * Gets the number of columns in the array.
     *
     * @returns The column count (at least 1)
     */
    get columns(): number;
    /**
     * Sets the number of columns in the array. Values are truncated to an
     * integer and clamped to at least 1.
     *
     * @param value - The new column count
     */
    set columns(value: number);
    /**
     * Gets the number of rows in the array.
     *
     * @returns The row count (at least 1)
     */
    get rows(): number;
    /**
     * Sets the number of rows in the array. Values are truncated to an integer
     * and clamped to at least 1.
     *
     * @param value - The new row count
     */
    set rows(value: number);
    /**
     * Gets the distance between columns, measured along the X axis of the
     * rotated block reference OCS.
     *
     * @returns The column spacing in drawing units
     */
    get columnSpacing(): number;
    /**
     * Sets the distance between columns.
     *
     * @param value - The new column spacing in drawing units
     */
    set columnSpacing(value: number);
    /**
     * Gets the distance between rows, measured along the Y axis of the rotated
     * block reference OCS.
     *
     * @returns The row spacing in drawing units
     */
    get rowSpacing(): number;
    /**
     * Sets the distance between rows.
     *
     * @param value - The new row spacing in drawing units
     */
    set rowSpacing(value: number);
    /**
     * Gets the offsets of all `rows × columns` instances, row by row.
     *
     * @inheritdoc
     */
    protected getInstanceOffsets(): AcGeVector2d[];
    /**
     * Always `false`: like AutoCAD, blocks inserted with MINSERT cannot be
     * exploded, so {@link explode} returns no entities.
     */
    get isExplodable(): boolean;
    /**
     * Transforms this MINSERT by an arbitrary world-space matrix.
     *
     * The placement is transformed by {@link AcDbBlockReference.transformBy};
     * the column and row spacing are then re-expressed in the new rotated OCS so
     * the array follows uniform scaling and mirroring.
     *
     * @param matrix - Transformation matrix in WCS.
     * @returns The current entity instance.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Gets the array parameters shown in the geometry group of
     * {@link AcDbBlockReference.properties}.
     *
     * @internal
     */
    protected getArrayProperties(): AcDbEntityRuntimeProperty[];
    /** @internal */
    protected get dxfSubclassName(): string;
    /** @internal */
    protected dxfOutArrayFields(filer: AcDbDxfFiler): void;
    /** @internal */
    protected dxfInArrayField(code: number, value: number): void;
    /**
     * Maps the array axes (rotated OCS) to WCS directions, excluding the
     * translation to the insertion point.
     */
    private getArrayAxesToWcs;
    /** Truncates a count to an integer that is at least 1. */
    private static normalizeCount;
}
//# sourceMappingURL=AcDbMInsertBlock.d.ts.map