import { AcGeMatrix3d, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
/**
 * Applies only the linear (rotation / scale / shear) part of `matrix` to
 * `vector`. Unlike {@link AcGeVector3d.transformDirection} the result keeps
 * its length, and unlike `applyMatrix4` the translation is ignored.
 *
 * @param vector - Vector to transform.
 * @param matrix - WCS transformation matrix.
 * @returns A new transformed vector.
 */
export declare function acdbTransformVector(vector: AcGeVector3dLike, matrix: AcGeMatrix3d): AcGeVector3d;
/**
 * Transforms a plane normal (extrusion direction) by `matrix` and returns a
 * unit vector.
 *
 * Normals are transformed by the inverse transpose of the linear part, so the
 * result stays perpendicular to the transformed plane even for non-uniform
 * scales. A mirror inside the plane keeps the normal (like AutoCAD MIRROR,
 * which keeps planar entities on +Z); the in-plane orientation flips instead.
 * Falls back to the input normal when the matrix is singular.
 *
 * @param normal - Unit normal to transform.
 * @param matrix - WCS transformation matrix.
 * @returns The transformed unit normal.
 */
export declare function acdbTransformNormal(normal: AcGeVector3dLike, matrix: AcGeMatrix3d): AcGeVector3d;
/**
 * Returns the uniform scale factor of `matrix`: the cube root of the absolute
 * determinant of its linear part. It is exactly `k` for
 * `T * R * S(k, k, k) * T⁻¹` and a volume-preserving average otherwise.
 *
 * Used for lengths that have no direction of their own (widths, sizes,
 * dash lengths) and therefore can only follow a uniform scale.
 *
 * @param matrix - WCS transformation matrix.
 * @returns The non-negative uniform scale factor.
 */
export declare function acdbUniformScaleFactor(matrix: AcGeMatrix3d): number;
/**
 * Returns how `matrix` scales a length measured along `normal` (thickness,
 * extrusion height), signed so that it stays positive when the normal is
 * transformed with {@link acdbTransformNormal}.
 *
 * @param normal - Unit normal the length is measured along.
 * @param matrix - WCS transformation matrix.
 * @returns The signed scale factor along the normal.
 */
export declare function acdbScaleAlongNormal(normal: AcGeVector3dLike, matrix: AcGeMatrix3d): number;
/**
 * Returns whether `matrix` reverses orientation (a mirror).
 *
 * @param matrix - WCS transformation matrix.
 */
export declare function acdbIsMirroring(matrix: AcGeMatrix3d): boolean;
//# sourceMappingURL=AcDbTransformHelpers.d.ts.map