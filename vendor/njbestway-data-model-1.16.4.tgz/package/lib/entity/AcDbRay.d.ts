import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbCurve } from './AcDbCurve.js';
import { AcDbEntityProperties } from './AcDbEntityProperties.js';
/**
 * Represents a ray entity in AutoCAD.
 *
 * A ray is a 3D geometric object that extends infinitely in one direction from a base point.
 * Rays are commonly used for construction lines, reference lines, and temporary geometry.
 * Unlike lines, rays have no end point and extend to infinity.
 *
 * @example
 * ```typescript
 * // Create a ray from origin in the positive X direction
 * const ray = new AcDbRay();
 * ray.basePoint = new AcGePoint3d(0, 0, 0);
 * ray.unitDir = new AcGeVector3d(1, 0, 0);
 *
 * // Access ray properties
 * console.log(`Base point: ${ray.basePoint}`);
 * console.log(`Unit direction: ${ray.unitDir}`);
 * ```
 */
export declare class AcDbRay extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The base point of the ray */
    private _basePoint;
    /** The unit direction vector of the ray */
    private _unitDir;
    /**
     * Creates a new ray entity.
     *
     * This constructor initializes a ray with default values.
     * The base point is at the origin and the unit direction is undefined.
     *
     * @example
     * ```typescript
     * const ray = new AcDbRay();
     * ray.basePoint = new AcGePoint3d(5, 10, 0);
     * ray.unitDir = new AcGeVector3d(0, 1, 0); // Positive Y direction
     * ```
     */
    constructor();
    /**
     * Gets the base point of this ray.
     *
     * The base point is the starting point from which the ray extends infinitely.
     *
     * @returns The base point as a 3D point
     *
     * @example
     * ```typescript
     * const basePoint = ray.basePoint;
     * console.log(`Ray base point: ${basePoint.x}, ${basePoint.y}, ${basePoint.z}`);
     * ```
     */
    get basePoint(): AcGePoint3d;
    /**
     * Sets the base point of this ray.
     *
     * @param value - The new base point
     *
     * @example
     * ```typescript
     * ray.basePoint = new AcGePoint3d(10, 20, 0);
     * ```
     */
    set basePoint(value: AcGePoint3d);
    /**
     * Gets the unit direction vector of this ray.
     *
     * The unit direction vector defines the direction in which the ray extends
     * infinitely from the base point.
     *
     * @returns The unit direction vector
     *
     * @example
     * ```typescript
     * const unitDir = ray.unitDir;
     * console.log(`Ray direction: ${unitDir.x}, ${unitDir.y}, ${unitDir.z}`);
     * ```
     */
    get unitDir(): AcGePoint3d;
    /**
     * Sets the unit direction vector of this ray.
     *
     * @param value - The new unit direction vector
     *
     * @example
     * ```typescript
     * ray.unitDir = new AcGeVector3d(0, 0, 1); // Positive Z direction
     * ```
     */
    set unitDir(value: AcGePoint3d);
    /**
     * Gets whether this ray is closed.
     *
     * Rays are always open entities, so this always returns false.
     *
     * @returns Always false for rays
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Gets the geometric extents (bounding box) of this ray.
     *
     * Since rays extend infinitely, this method returns a bounding box that
     * encompasses a finite portion of the ray for practical purposes.
     *
     * @returns The bounding box that encompasses a portion of the ray
     *
     * @example
     * ```typescript
     * const extents = ray.geometricExtents;
     * console.log(`Ray bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Returns the full property definition for this ray entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the ray in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this ray.
     *
     * Grip points are control points that can be used to modify the ray.
     * For a ray, the grip point is the base point.
     *
     * @returns Array of grip points (base point)
     *
     * @example
     * ```typescript
     * const gripPoints = ray.subGetGripPoints();
     * // gripPoints contains: [basePoint]
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this trace.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this ray by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * This ray always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * Draws this ray using the specified renderer.
     *
     * This method renders the ray as a line segment extending from the base point
     * in the direction of the unit vector. For practical purposes, the ray is
     * drawn with a finite length.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered ray entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Returns a parallel ray: the base point shifts perpendicular to the XY projection
     * of {@link unitDir} by `offsetDist`, while direction is unchanged. Fails when the
     * direction is degenerate in the XY plane.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Uses the 2D cross product of the ray direction with the vector from
     * {@link basePoint} to `point`, normalized by the XY length of the direction.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units (perpendicular in XY)
     * @returns Parallel ray, or `null` when {@link unitDir} has negligible XY component
     */
    private createOffsetCurve;
    /** Unit direction, or `undefined` when {@link unitDir} is degenerate. */
    private paramDir;
    private onTol;
    /**
     * Start parameter (`0`, at {@link basePoint}). The parameter of a ray is
     * the distance from its base point along {@link unitDir}.
     */
    get startParam(): number;
    /** End parameter (`Infinity`). */
    get endParam(): number;
    /**
     * Returns the signed distance from {@link basePoint} of a point on the
     * infinite line through this ray (points behind the base point give a
     * negative parameter).
     */
    getParamAtPoint(point: AcGePoint3dLike): number | undefined;
    /** Point at the given signed distance from {@link basePoint}. */
    getPointAtParam(param: number): AcGePoint3d | undefined;
    /** @inheritdoc */
    getClosestPointTo(point: AcGePoint3dLike, extend?: boolean): AcGePoint3d | undefined;
    /** The parameter itself (signed distance from {@link basePoint}). */
    getDistAtParam(param: number): number | undefined;
    /**
     * Splits into {@link AcDbLine} pieces followed by a final {@link AcDbRay}
     * starting at the last split parameter.
     */
    getSplitCurves(params: readonly number[]): AcDbCurve[];
}
//# sourceMappingURL=AcDbRay.d.ts.map