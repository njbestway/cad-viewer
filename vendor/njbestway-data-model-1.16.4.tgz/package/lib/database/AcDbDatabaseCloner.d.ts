import type { AcGeMatrix3d } from '@mlightcad/geometry-engine';
import { AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { AcDbEntity } from '../entity/AcDbEntity.js';
import { AcDbBlockTableRecord } from './AcDbBlockTableRecord.js';
import type { AcDbDatabase } from './AcDbDatabase.js';
/**
 * Deep-clone engine behind {@link AcDbDatabase.deepCloneObjects},
 * {@link AcDbDatabase.wblockCloneObjects}, {@link AcDbDatabase.wblock} and
 * {@link AcDbDatabase.insert}.
 *
 * It follows the ObjectARX deep-clone phases:
 * 1. collect every record and object the primary objects depend on,
 *    transitively (layer → linetype, INSERT → block → nested blocks, ...);
 * 2. decide the destination name of each dependency as it is found, applying
 *    the duplicate record cloning rule (anonymous blocks always get a fresh
 *    name). Records that resolve to an existing destination record are not
 *    cloned, so their own dependencies are not collected either;
 * 3. clone the dependencies, block contents and primary objects, giving each
 *    entity clone its final handle;
 * 4. translate references held by the clones through the id mapping, then
 *    append them, which records undo.
 *
 * @internal
 */
export declare class AcDbDatabaseCloner {
    private readonly source;
    private readonly dest;
    private readonly idMap;
    private readonly refs;
    private readonly reservedNames;
    /** Block table record that receives the primary clones. */
    private owner?;
    /**
     * @param source - Database that owns the objects to clone.
     * @param dest - Database that receives the clones.
     * @param idMap - Id mapping that records the translation.
     */
    constructor(source: AcDbDatabase, dest: AcDbDatabase, idMap: AcDbIdMapping);
    private get sameDatabase();
    private get isWblock();
    /**
     * Clones `entities` and their dependencies, appends the clones to `owner`
     * and returns them in the same order.
     *
     * @param entities - Entities of the source database.
     * @param owner - Block table record of the destination database.
     * @param transform - Optional transform applied to the primary clones.
     */
    cloneEntities(entities: AcDbEntity[], owner: AcDbBlockTableRecord, transform?: AcGeMatrix3d): AcDbEntity[];
    private collectDependencies;
    /** Resolves collected names and ids into refs; returns the new ones. */
    private addDependencyRefs;
    /** Finds the table or dictionary that owns a referenced object id. */
    private resolveId;
    private planRecord;
    private planDuplicate;
    private assignRefName;
    private orderedRefs;
    private lookupDest;
    private isNameTaken;
    private reserve;
    /** `$0$name`, `$1$name`, ... as AutoCAD's MangleName does. */
    private mangledName;
    private nextAnonymousName;
    private cloneRecords;
    /** Copies the contents of `clone` onto `existing`, keeping its identity. */
    private replaceRecord;
    /** Clones the entities of every block definition that was cloned. */
    private cloneBlockContents;
    private cloneEntity;
}
//# sourceMappingURL=AcDbDatabaseCloner.d.ts.map