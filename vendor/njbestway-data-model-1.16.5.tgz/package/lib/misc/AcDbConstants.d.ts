/**
 * Default line type used when no specific line type is specified.
 *
 * This constant represents the "Continuous" line type, which is the
 * standard solid line type used in AutoCAD drawings.
 */
export declare const DEFAULT_LINE_TYPE = "Continuous";
/**
 * Default text style name used when no specific text style is specified.
 *
 * This constant represents the standard text style used in AutoCAD drawings.
 */
export declare const DEFAULT_TEXT_STYLE = "Standard";
/**
 * Default multiline style name used when no specific MLINE style is specified.
 *
 * This constant represents the default current style used by the CMLSTYLE
 * system variable for newly created MLINE entities.
 */
export declare const DEFAULT_MLINE_STYLE = "Standard";
/**
 * Default multileader style name used when no specific MLEADER style is specified.
 *
 * This constant represents the default current style used by the CMLEADERSTYLE
 * system variable for newly created MLEADER entities.
 */
export declare const DEFAULT_MLEADER_STYLE = "Standard";
/**
 * Default hatch pattern name used by AutoCAD for imperial drawings.
 */
export declare const DEFAULT_HATCH_PATTERN_IMPERIAL = "ANSI31";
/**
 * Default hatch pattern name used by AutoCAD for metric drawings.
 */
export declare const DEFAULT_HATCH_PATTERN_METRIC = "ANGLE";
/**
 * Reserved hatch pattern name used for solid fills.
 */
export declare const HATCH_PATTERN_SOLID = "SOLID";
/**
 * Returns true when a hatch pattern name denotes a solid fill.
 *
 * LibreDWG (and some older writers) emit `_SOLID` instead of `SOLID`. Treat
 * both — and any leading-underscore / case variant — as solid so fill is not
 * dropped when `definitionLines` are empty.
 */
export declare function acdbIsSolidHatchPatternName(patternName: string | null | undefined): boolean;
/**
 * Default hatch pattern name used for user-defined hatch patterns in DXF output.
 */
export declare const HATCH_PATTERN_USER = "USER";
/**
 * Default gradient hatch name used when a gradient hatch has no explicit name.
 */
export declare const DEFAULT_GRADIENT_HATCH_NAME = "LINEAR";
/**
 * Special line type value that indicates the entity should use
 * the line type of its layer.
 *
 * When an entity has this line type, it will inherit the line type
 * from the layer it belongs to.
 */
export declare const ByLayer = "ByLayer";
/**
 * Special line type value that indicates the entity should use
 * the line type of its block.
 *
 * When an entity has this line type, it will inherit the line type
 * from the block it belongs to.
 */
export declare const ByBlock = "ByBlock";
/**
 * Name of the active viewport table record in AutoCAD.
 *
 * This reserved name identifies the current viewport configuration in the
 * VPORT symbol table.
 */
export declare const ACTIVE_VPORT_NAME = "*Active";
/**
 * Application ID for MLightCAD used in dictionaries and XData registration.
 */
export declare const MLIGHTCAD_APPID = "mlightcad";
/**
 * Built-in AutoCAD application ID used for standard XData registration.
 */
export declare const ACAD_APPID = "ACAD";
/**
 * Frozen 2D/3D placeholders when a VPORT table row omits geometry (partial DXF
 * groups, incomplete DWG decode). Used before `AcGePoint2d.copy` / `AcGePoint3d.copy`.
 */
export declare const VPORT_FALLBACK_CENTER_2D: Readonly<{
    x: 0;
    y: 0;
}>;
export declare const VPORT_FALLBACK_LLC: Readonly<{
    x: 0;
    y: 0;
}>;
export declare const VPORT_FALLBACK_URC: Readonly<{
    x: 1;
    y: 1;
}>;
export declare const VPORT_FALLBACK_VIEW_DIR: Readonly<{
    x: 0;
    y: 0;
    z: 1;
}>;
export declare const VPORT_FALLBACK_VIEW_TARGET: Readonly<{
    x: 0;
    y: 0;
    z: 0;
}>;
/** AutoCAD default ACI color index for the GRIPCOLOR system variable. */
export declare const ACDB_GRIPCOLOR_DEFAULT = 150;
/** AutoCAD valid range for the GRIPCOLOR system variable. */
export declare const ACDB_GRIPCOLOR_MIN = 1;
export declare const ACDB_GRIPCOLOR_MAX = 255;
/** AutoCAD default ACI color index for the GRIPHOT system variable. */
export declare const ACDB_GRIPHOT_DEFAULT = 12;
/** AutoCAD valid range for the GRIPHOT system variable. */
export declare const ACDB_GRIPHOT_MIN = 1;
export declare const ACDB_GRIPHOT_MAX = 255;
/** AutoCAD valid range for the GRIPOBJLIMIT system variable. */
export declare const ACDB_GRIPOBJLIMIT_MIN = 0;
export declare const ACDB_GRIPOBJLIMIT_MAX = 32767;
/** AutoCAD valid range for the GRIPS system variable. */
export declare const ACDB_GRIPS_MIN = 0;
export declare const ACDB_GRIPS_MAX = 2;
/** AutoCAD default value for the GRIPSIZE system variable. */
export declare const ACDB_GRIPSIZE_DEFAULT = 5;
/** AutoCAD valid range for the GRIPSIZE system variable. */
export declare const ACDB_GRIPSIZE_MIN = 1;
export declare const ACDB_GRIPSIZE_MAX = 255;
/**
 * COMPAREPROPS bit: include color property changes in drawing comparison.
 *
 * @see https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-FC52193A-3801-42D1-B5C3-873B192B36B2
 */
export declare const ACDB_COMPAREPROPS_COLOR = 1;
/** COMPAREPROPS bit: include layer property changes. */
export declare const ACDB_COMPAREPROPS_LAYER = 2;
/** COMPAREPROPS bit: include linetype property changes. */
export declare const ACDB_COMPAREPROPS_LINETYPE = 4;
/** COMPAREPROPS bit: include linetype scale property changes. */
export declare const ACDB_COMPAREPROPS_LINETYPESCALE = 8;
/** COMPAREPROPS bit: include lineweight property changes. */
export declare const ACDB_COMPAREPROPS_LINEWEIGHT = 16;
/** COMPAREPROPS bit: include transparency property changes. */
export declare const ACDB_COMPAREPROPS_TRANSPARENCY = 32;
/** COMPAREPROPS bit: include thickness property changes. */
export declare const ACDB_COMPAREPROPS_THICKNESS = 64;
/** AutoCAD default for COMPAREPROPS: property changes are not compared. */
export declare const ACDB_COMPAREPROPS_DEFAULT = 0;
/** AutoCAD valid range for the COMPAREPROPS bitcode (sum of defined bits). */
export declare const ACDB_COMPAREPROPS_MIN = 0;
export declare const ACDB_COMPAREPROPS_MAX: number;
/** AutoCAD default for COMPAREHATCH: hatch objects are excluded from comparison. */
export declare const ACDB_COMPAREHATCH_DEFAULT = 0;
/** AutoCAD valid range for the COMPAREHATCH system variable. */
export declare const ACDB_COMPAREHATCH_MIN = 0;
export declare const ACDB_COMPAREHATCH_MAX = 1;
/**
 * AutoCAD default for MIRRTEXT: mirrored TEXT/MTEXT stay readable (not truly
 * mirrored).
 */
export declare const ACDB_MIRRTEXT_DEFAULT = 0;
/** AutoCAD valid range for the MIRRTEXT system variable. */
export declare const ACDB_MIRRTEXT_MIN = 0;
export declare const ACDB_MIRRTEXT_MAX = 1;
/**
 * AutoCAD default for TRIMMODE: fillet/chamfer selected edges are trimmed.
 * @see https://help.autodesk.com/view/ACD/2024/ENU/?guid=GUID-3D639DCE-5A01-4C07-899D-0595F8DDEBF7
 */
export declare const ACDB_TRIMMODE_DEFAULT = 1;
export declare const ACDB_TRIMMODE_MIN = 0;
export declare const ACDB_TRIMMODE_MAX = 1;
/** AutoCAD default for CHAMMODE: two chamfer distances. */
export declare const ACDB_CHAMMODE_DEFAULT = 0;
export declare const ACDB_CHAMMODE_MIN = 0;
export declare const ACDB_CHAMMODE_MAX = 1;
/**
 * AutoCAD default for FILLETPOLYARC: fillet arc segments in FILLET Polyline.
 * @see https://help.autodesk.com/cloudhelp/2026/ENU/AutoCAD-Core/files/GUID-DD802826-BEE4-4B85-9B76-E9A3FBD02E24.htm
 */
export declare const ACDB_FILLETPOLYARC_DEFAULT = 1;
export declare const ACDB_FILLETPOLYARC_MIN = 0;
export declare const ACDB_FILLETPOLYARC_MAX = 1;
/** AutoCAD default for COMMANDPREVIEW: command-result preview on. */
export declare const ACDB_COMMANDPREVIEW_DEFAULT = 1;
export declare const ACDB_COMMANDPREVIEW_MIN = 0;
export declare const ACDB_COMMANDPREVIEW_MAX = 1;
/**
 * AutoCAD default for HPISLANDDETECTIONMODE: island detection on.
 *
 * @see https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-1595FDAF-AE59-475B-A8DA-D7D754C16501.htm
 */
export declare const ACDB_HPISLANDDETECTIONMODE_DEFAULT = 1;
export declare const ACDB_HPISLANDDETECTIONMODE_MIN = 0;
export declare const ACDB_HPISLANDDETECTIONMODE_MAX = 1;
/**
 * AutoCAD default for HPORIGINMODE: use HPORIGIN as the hatch origin.
 *
 * @see https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-471B755D-69F9-467B-BE6F-103106C1B03A.htm
 */
export declare const ACDB_HPORIGINMODE_DEFAULT = 0;
export declare const ACDB_HPORIGINMODE_MIN = 0;
export declare const ACDB_HPORIGINMODE_MAX = 5;
/**
 * AutoCAD default for HPQUICKPREVIEW: show hatch preview while hovering
 * enclosed areas during HATCH pick-points.
 *
 * @see https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-55E323D8-5BC3-407E-A57C-B18273325604.htm
 */
export declare const ACDB_HPQUICKPREVIEW_DEFAULT = 1;
export declare const ACDB_HPQUICKPREVIEW_MIN = 0;
export declare const ACDB_HPQUICKPREVIEW_MAX = 1;
/**
 * AutoCAD default for HPQUICKPREVTIMEOUT: max seconds to generate a hatch
 * hover preview before cancelling it (valid range 1–300).
 *
 * @see https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-4AB77E71-3EA7-41E7-AE43-EFE547149D4C.htm
 */
export declare const ACDB_HPQUICKPREVTIMEOUT_DEFAULT = 2;
export declare const ACDB_HPQUICKPREVTIMEOUT_MIN = 1;
export declare const ACDB_HPQUICKPREVTIMEOUT_MAX = 300;
/**
 * AutoCAD default for PROJMODE: project to UCS XY for TRIM/EXTEND.
 * @see https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-8735A062-2688-44A7-809A-9883761533F9.htm
 */
export declare const ACDB_PROJMODE_DEFAULT = 1;
export declare const ACDB_PROJMODE_MIN = 0;
export declare const ACDB_PROJMODE_MAX = 2;
/** AutoCAD default for COMPARERCMARGIN: revision-cloud offset of 5. */
export declare const ACDB_COMPARERCMARGIN_DEFAULT = 5;
/** AutoCAD valid range for the COMPARERCMARGIN system variable. */
export declare const ACDB_COMPARERCMARGIN_MIN = 1;
export declare const ACDB_COMPARERCMARGIN_MAX = 25;
/** AutoCAD default for COMPARETEXT: text objects are included in comparison. */
export declare const ACDB_COMPARETEXT_DEFAULT = 1;
/** AutoCAD valid range for the COMPARETEXT system variable. */
export declare const ACDB_COMPARETEXT_MIN = 0;
export declare const ACDB_COMPARETEXT_MAX = 1;
/** AutoCAD default for COMPARETOLERANCE: 6 decimal places. */
export declare const ACDB_COMPARETOLERANCE_DEFAULT = 6;
/** AutoCAD valid range for the COMPARETOLERANCE system variable. */
export declare const ACDB_COMPARETOLERANCE_MIN = 0;
export declare const ACDB_COMPARETOLERANCE_MAX = 14;
/**
 * Truncates a numeric system-variable value to an integer and rejects values
 * outside AutoCAD's documented valid range.
 */
export declare function acdbCoerceIntegerSysVar(displayName: string, value: unknown, min: number, max: number): number;
/**
 * Returns a truncated integer when it lies in `[min, max]`; otherwise
 * `undefined`. Used when ingesting untrusted drawing data such as DXF HEADER.
 */
export declare function acdbIntegerSysVarIfInRange(value: unknown, min: number, max: number): number | undefined;
//# sourceMappingURL=AcDbConstants.d.ts.map