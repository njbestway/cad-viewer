import { type AcDbObjectId } from '../base/AcDbObject.js';
import { AcDbHatch } from '../entity/AcDbHatch.js';
import type { AcDbDatabase } from './AcDbDatabase.js';
/**
 * Reverse index from boundary entity id → associative hatch ids, plus
 * post-commit listeners that rebuild hatch loops when a source boundary
 * is modified and disassociate when a source is erased.
 *
 * Soft-pointers live on {@link AcDbHatch} (DXF 97/330). This index only
 * accelerates lookup and drives live association updates.
 */
export declare class AcDbHatchAssociationIndex {
    private readonly _db;
    /** boundaryId → hatchIds that reference it */
    private readonly _boundaryToHatches;
    /** hatchId → boundaryIds currently registered for that hatch */
    private readonly _hatchToBoundaries;
    private _listenersAttached;
    /** Avoid re-entrant rebuild while a hatch is being rewritten from a boundary edit. */
    private readonly _rebuilding;
    constructor(db: AcDbDatabase);
    /**
     * Ensures database entity events are wired. Safe to call repeatedly.
     */
    attachListeners(): void;
    /**
     * Rebuilds the reverse map for every hatch currently in model/paper space.
     * Call after a full database load.
     */
    rebuildIndex(): void;
    /**
     * Registers (or re-registers) an associative hatch's source boundary ids.
     * Skips write-transaction clones (temporary object ids).
     */
    refresh(hatch: AcDbHatch): void;
    /**
     * Removes a hatch from the reverse index.
     */
    unregister(hatchId: AcDbObjectId): void;
    /**
     * Returns hatch object ids that list `boundaryId` among their path sources.
     */
    hatchesForBoundary(boundaryId: AcDbObjectId): ReadonlyArray<AcDbObjectId>;
    /**
     * Returns every boundary id currently linked to `hatchId`.
     */
    boundariesForHatch(hatchId: AcDbObjectId): ReadonlyArray<AcDbObjectId>;
    private onEntityModified;
    private onEntityErased;
    private rebuildHatch;
    private runRebuildHatch;
    private disassociateBoundary;
    private runDisassociateBoundary;
}
//# sourceMappingURL=AcDbHatchAssociationIndex.d.ts.map