import { AcCmColor, AcCmTransparency } from '@mlightcad/common';
import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePlane, AcGePoint3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiDirectBatchPrimitive, AcGiEntity, AcGiLineStyle, AcGiLineWeight, AcGiRenderer, AcGiSubEntityTraits } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { AcDbObject } from '../base/AcDbObject.js';
import { AcDbIntersect } from '../misc/AcDbIntersect.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbEntityProperties, AcDbEntityPropertyGroup } from './AcDbEntityProperties.js';
/**
 * Abstract base class for all drawing entities.
 *
 * This class provides the fundamental functionality for all drawing entities,
 * including layer management, color handling, linetype support, visibility,
 * and geometric operations. All specific entity types (lines, circles, text, etc.)
 * inherit from this class.
 *
 * @example
 * ```typescript
 * class MyEntity extends AcDbEntity {
 *   get geometricExtents(): AcGeBox3d {
 *     // Implementation for geometric extents
 *   }
 *
 *   draw(renderer: AcGiRenderer): AcGiEntity | undefined {
 *     // Implementation for drawing
 *   }
 * }
 * ```
 */
export declare abstract class AcDbEntity extends AcDbObject {
    /** The entity type name */
    static typeName: string;
    /** The layer name this entity belongs to */
    private _layer?;
    /** The color of this entity */
    private _color?;
    /**
     * True when this entity's unresolved color is the ByLayer default (DXF file
     * omitted color group 62/420). Keeps the entity's color lazily unallocated
     * — {@link getEntityColor} materializes it as ByLayer on first access instead
     * of eagerly allocating one `AcCmColor` per entity (~89% of typical drawings).
     */
    private _colorIsByLayerDefault;
    /** The linetype name for this entity */
    private _lineType?;
    /** The line weight for this entity */
    private _lineWeight?;
    /** The linetype scale factor for this entity */
    private _linetypeScale?;
    /** Whether this entity is visible */
    private _visibility;
    /** The transparency level of this entity (0-1), materialized on first access. */
    private _transparency?;
    /** Whether transparency was explicitly assigned on this entity. */
    private _transparencySet;
    /** DXF group 67 paper-space flag captured during dxfIn. */
    private _dxfPaperSpace;
    /**
     * AcDbEntity groups without a native model — 284 shadow mode, 347 material,
     * 380/390 plot style — kept for DXF round trip. Allocated only when present.
     * The 430 color-book name is not kept: it would override a color changed
     * after reading.
     */
    private _dxfCommonExtras?;
    /**
     * The entity's original DWG handle (hex handle as a number), captured by the
     * acad-rust native converter during the initial open mapping. Undefined for
     * DXF-sourced and newly created entities. Route-B incremental DWG save
     * addresses the source record through it; write-once so a later edit can
     * never re-point an entity at another record.
     */
    private _dwgHandle?;
    /**
     * Gets the type name of this entity.
     *
     * This method returns the entity type by removing the "AcDb" prefix
     * from the constructor name.
     *
     * @returns The entity type name
     *
     * @example
     * ```typescript
     * const entity = new AcDbLine();
     * console.log(entity.type); // "Line"
     * ```
     */
    get type(): string;
    /**
     * Gets the DXF entity type name written to the file.
     *
     * This value is the literal DXF record type emitted for the entity during
     * DXF export, such as `LINE`, `INSERT`, or `DIMENSION`.
     *
     * Every concrete entity class must explicitly define this property so the
     * DXF export contract stays local to the entity implementation rather than
     * being inferred by the base class.
     *
     * @returns The DXF entity type name used during export
     */
    abstract get dxfTypeName(): string;
    /**
     * Gets the name of the layer referenced by this entity.
     *
     * @returns The layer name
     *
     * @example
     * ```typescript
     * const layerName = entity.layer;
     * ```
     */
    get layer(): string;
    /**
     * Sets the name of the layer for this entity.
     *
     * @param value - The new layer name
     *
     * @example
     * ```typescript
     * entity.layer = 'MyLayer';
     * ```
     */
    set layer(value: string);
    /**
     * Gets the color information of this entity.
     *
     * @returns The color object for this entity
     *
     * @example
     * ```typescript
     * const color = entity.color;
     * ```
     */
    get color(): AcCmColor;
    /**
     * Sets the color information for this entity.
     *
     * @param value - The new color object
     *
     * @example
     * ```typescript
     * entity.color = new AcCmColor(0xFF0000);
     * ```
     */
    set color(value: AcCmColor);
    /**
     * Resolved color applied on this entity. It will resolve layer colors and block colors as needed.
     */
    get resolvedColor(): AcCmColor;
    /**
     * Default ByLayer / ByBlock colour resolution for entities without an INSERT owner.
     */
    protected resolveStandardColor(): AcCmColor;
    /**
     * Gets the name of the line type referenced by this entity.
     *
     * @returns The linetype name
     *
     * @example
     * ```typescript
     * const lineType = entity.lineType;
     * ```
     */
    get lineType(): string;
    /**
     * Sets the name of the line type for this entity.
     *
     * @param value - The new linetype name
     *
     * @example
     * ```typescript
     * entity.lineType = 'DASHED';
     * ```
     */
    set lineType(value: string);
    /**
     * Gets the line weight used by this entity.
     *
     * @returns The line weight value
     */
    get lineWeight(): AcGiLineWeight;
    /**
     * Sets the line weight for this entity.
     *
     * @param value - The new line weight value
     */
    set lineWeight(value: AcGiLineWeight);
    /**
     * Gets the line type scale factor of this entity.
     *
     * When an entity is first instantiated, its line type scale is initialized
     * to an invalid value. When the entity is added to the database, if a
     * linetype scale has not been specified for the entity, it is set to the
     * database's current line type scale value.
     *
     * @returns The linetype scale factor
     *
     * @example
     * ```typescript
     * const scale = entity.linetypeScale;
     * ```
     */
    get linetypeScale(): number;
    /**
     * Sets the line type scale factor for this entity.
     *
     * @param value - The new linetype scale factor
     *
     * @example
     * ```typescript
     * entity.linetypeScale = 2.0;
     * ```
     */
    set linetypeScale(value: number);
    /**
     * Gets whether this entity is visible.
     *
     * @returns True if the entity is visible, false otherwise
     *
     * @example
     * ```typescript
     * const isVisible = entity.visibility;
     * ```
     */
    get visibility(): boolean;
    /**
     * Sets whether this entity is visible.
     *
     * @param value - True to make the entity visible, false to hide it
     *
     * @example
     * ```typescript
     * entity.visibility = false; // Hide the entity
     * ```
     */
    set visibility(value: boolean);
    /**
     * Gets the transparency level of this entity.
     *
     * @returns The transparency value.
     *
     * @example
     * ```typescript
     * const transparency = entity.transparency;
     * ```
     */
    get transparency(): AcCmTransparency;
    /**
     * Sets the transparency level of this entity.
     *
     * @param value - The transparency value.
     *
     * @example
     * ```typescript
     * entity.transparency = 0.5; // 50% transparent
     * ```
     */
    set transparency(value: AcCmTransparency);
    /**
     * Returns whether a layer value has been explicitly assigned on this entity.
     */
    protected hasExplicitLayer(): boolean;
    /**
     * Returns whether a color value has been explicitly assigned on this entity.
     */
    protected hasExplicitColor(): boolean;
    /**
     * Returns the stored entity color, initializing it from CECOLOR if needed.
     *
     * Entities marked by {@link applyDxfFileDefaults} are materialized as the
     * ByLayer default instead of the CECOLOR seed, which is exactly what the
     * eager allocation used to store for them.
     */
    protected getEntityColor(): AcCmColor;
    /**
     * Assigns the stored entity color.
     */
    protected setEntityColor(value: AcCmColor): void;
    /**
     * Returns whether unresolved entity color should be initialized from CECOLOR.
     * ByLayer-default entities (from DXF without color group) must NOT be seeded
     * with CECOLOR — they should stay as ByLayer.
     */
    protected shouldResolveColorFromCecolor(): boolean;
    /**
     * Applies DXF file defaults right after reading this entity from a DXF file.
     *
     * Per DXF spec, an entity whose color group (62/420) is absent defaults to
     * ByLayer (256) — not CECOLOR. CECOLOR only seeds entities created
     * programmatically (see {@link resolveEffectiveProperties}, mirroring
     * `AcDbEntity::setDatabaseDefaults`). Records the default lazily instead of
     * allocating an `AcCmColor` per entity.
     *
     * @internal
     */
    applyDxfFileDefaults(): void;
    /**
     * Returns whether transparency has been explicitly assigned on this entity.
     */
    protected hasExplicitTransparency(): boolean;
    /**
     * Writes common entity-level DXF fields (layer, linetype, color, etc.).
     *
     * Subclasses should call this first, then write their own fields.
     *
     * @param filer - DXF output writer.
     * @returns The entity instance (for chaining).
     */
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /** Writes the preserved {@link _dxfCommonExtras} the target can carry. */
    private dxfOutCommonExtras;
    /**
     * Reads AcDbEntity common fields until the next subclass marker or object end.
     */
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * DXF group 67 paper-space flag from the last {@link dxfInFields} pass.
     * Used by the streaming document reader to choose model vs paper ownership.
     * @internal
     */
    get dxfPaperSpace(): boolean;
    /**
     * The source DWG handle captured at open time, or undefined when the entity
     * is not DWG-sourced (DXF import, newly created). Read-only provenance for
     * the Route-B incremental save path.
     */
    get dwgHandle(): number | undefined;
    /**
     * @internal Write-once: the DWG converter sets it during the initial mapping;
     * subsequent assignments are ignored so an edit can never re-point an entity
     * at another source record.
     */
    set dwgHandle(value: number | undefined);
    /**
     * Resolves the effective properties of this entity.
     *
     * This method determines the final, usable values for entity properties such as
     * layer, linetype, lineweight, color, and other display-related attributes.
     * If a property is not explicitly set on the entity (for example, it is undefined
     * or specified as *ByLayer* / *ByBlock*), the value is resolved according to the
     * current AutoCAD system variables and drawing context.
     *
     * Typical system variables involved in the resolution process include, but are
     * not limited to:
     * - `CLAYER`    – Current layer
     * - `CELTYPE`   – Current linetype
     * - `CELWEIGHT` – Current lineweight
     * - `CECOLOR`   – Current color
     *
     * The resolution follows AutoCAD semantics:
     * - Explicitly assigned entity properties take precedence
     * - *ByLayer* properties are inherited from the entity’s layer
     * - *ByBlock* properties are inherited from the owning block reference
     * - If no explicit value can be determined, the corresponding system variable
     *   or default drawing value is used
     *
     * This method does not change user-defined property settings; it only computes
     * and applies the final effective values used for display, selection, and
     * downstream processing.
     */
    resolveEffectiveProperties(): void;
    /**
     * Returns the full property definition for this entity, including
     * all property groups and runtime accessors.
     *
     * This getter is used by the property inspector UI to:
     * - determine the layout and grouping of properties,
     * - look up editable flags and metadata,
     * - read/write live values on this entity using accessors.
     *
     * The returned structure contains:
     * - static metadata (label, type, group structure),
     * - dynamic accessor bindings that expose the actual values stored in the entity.
     *
     * Note: The `groups` array contains `AcDbEntityPropertyGroup` objects whose
     * `properties` entries are runtime-resolved property descriptors that include
     * {@link AcDbPropertyAccessor} objects. Each property object therefore
     * conforms to `AcDbEntityRuntimeProperty`.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this entity.
     *
     * Grip points are the control points that can be used to modify the entity.
     * This method should be overridden by subclasses to provide entity-specific
     * grip points.
     *
     * @returns Array of grip points as 3D points
     *
     * @example
     * ```typescript
     * const gripPoints = entity.subGetGripPoints();
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Moves the grip points at the specified indices by the given offset.
     *
     * This method should be overridden by subclasses to provide entity-specific
     * grip editing behavior, matching AutoCAD `AcDbEntity::subMoveGripPointsAt`.
     *
     * @param indices - Zero-based indexes into the array returned by {@link subGetGripPoints}
     * @param offset - WCS translation offset applied to the selected grips
     * @returns This entity after the grip edit
     *
     * @example
     * ```typescript
     * entity.subMoveGripPointsAt([0], new AcGeVector3d(1, 0, 0));
     * ```
     */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the stretch points for this entity.
     *
     * Stretch points are used by the STRETCH command. Points that lie inside
     * the crossing selection are moved by {@link subMoveStretchPointsAt}.
     * Matches AutoCAD `AcDbEntity::subGetStretchPoints`.
     *
     * The default returns the same points as {@link subGetGripPoints}.
     *
     * @returns Array of stretch points as 3D points in WCS
     */
    subGetStretchPoints(): AcGePoint3d[];
    /**
     * Moves the stretch points at the specified indices by the given offset.
     *
     * Matches AutoCAD `AcDbEntity::subMoveStretchPointsAt`. The default
     * translates the whole entity via {@link transformBy}, ignoring which
     * indices were selected. Entities that support local stretch must override
     * this to move only the selected points.
     *
     * @param indices - Zero-based indexes into {@link subGetStretchPoints}
     * @param offset - WCS translation offset
     * @returns This entity after the stretch
     */
    subMoveStretchPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this entity.
     *
     * Object snap points are the points that can be used for precise positioning
     * when drawing or editing. This method should be overridden by subclasses
     * to provide entity-specific snap points.
     *
     * @param osnapMode - The object snap mode
     * @param pickPoint - The pick point
     * @param lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     * @param gsMark - The object id of subentity. For now, it is used by INSERT
     * entity only. In AutoCAD, it uses AcGiSubEntityTraits::setSelectionMarkerInput
     * to set GS marker of the subentity involved in the object snap operation. For
     * now, we don't provide such a GS marker mechanism yet. So passed id of subentity
     * as GS marker. Maybe this behavior will change in the future.
     * @param insertionMat - Cumulative insertion transform matrix from nested block
     * references. This parameter is primarily used by INSERT entities.
     *
     * @example
     * ```typescript
     * const snapPoints: AcGePoint3d[] = [];
     * entity.subGetOsnapPoints(AcDbOsnapMode.Endpoint, 0, pickPoint, lastPoint, snapPoints);
     * ```
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[], gsMark?: AcDbObjectId, insertionMat?: AcGeMatrix3d): void;
    /**
     * Finds intersection points between this entity and another entity.
     *
     * This method mirrors ObjectARX `AcDbEntity::intersectWith`. Intersection
     * points are returned in WCS. The optional `projPlane` argument corresponds
     * to the ObjectARX overload that intersects the projections of both
     * entities onto a plane (apparent intersection). `gsMarker` subentity
     * filtering is not implemented.
     *
     * Subclasses should override {@link subGetIntersectCurves} instead of this
     * method.
     *
     * @param entity - The other entity
     * @param intType - Whether to extend this entity, the other entity, both, or neither
     * @param projPlane - Optional projection plane for apparent intersection
     * @returns Intersection points in WCS; empty when the entities do not intersect
     */
    intersectWith(entity: AcDbEntity, intType?: AcDbIntersect, projPlane?: AcGePlane): AcGePoint3d[];
    /**
     * Returns the WCS curve primitives used by {@link intersectWith}.
     *
     * Default implementation returns `[]` (no intersections). Subclasses with
     * drawable curve geometry override this; callers should use `intersectWith`.
     * Entities without curve primitives (text, points, attributes) keep this
     * empty default, matching ObjectARX.
     */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Transforms this entity by the specified matrix.
     *
     * This method applies a geometric transformation to the entity.
     * Subclasses should override this method to provide entity-specific
     * transformation behavior.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This entity after transformation
     *
     * @example
     * ```typescript
     * const matrix = AcGeMatrix3d.translation(10, 0, 0);
     * entity.transformBy(matrix);
     * ```
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * A copy is a *new* entity: it must not claim the source DWG record of the
     * original, so the provenance handle is dropped (the Route-B save journal
     * would otherwise patch one source record from two live entities). Undo/redo
     * snapshots keep it via {@link clonePreservingIdentity}.
     */
    clone(): this;
    /** Undo/redo restores the same logical entity — keep its source handle. */
    clonePreservingIdentity(): this;
    /**
     * Returns a new entity that is a clone of this entity transformed by
     * `matrix`, mirroring ObjectARX `AcDbEntity::getTransformedCopy()`.
     *
     * The default implementation clones this entity and calls
     * {@link transformBy} on the clone. Subclasses that need database-context
     * during the transform (for example TEXT/`MIRRTEXT`) may override this.
     *
     * @param matrix - Transformation matrix to apply to the copy.
     * @returns A non-database-resident transformed copy.
     */
    getTransformedCopy(matrix: AcGeMatrix3d): AcDbEntity;
    /**
     * Breaks this entity into a set of simpler entities, mirroring ObjectARX
     * `AcDbEntity::explode()`.
     *
     * The returned entities are new, non-database-resident objects expressed in
     * WCS. This entity is not modified: as in ObjectARX, it is up to the caller
     * (for example the EXPLODE command) to append the returned entities to a
     * block table record and to erase the original entity.
     *
     * An empty array means the entity cannot be exploded (ObjectARX returns
     * `Acad::eNotApplicable` in that case), e.g. lines, arcs, circles, single
     * line text, MINSERT block references or blocks whose definition disallows
     * exploding.
     *
     * This method is non-virtual: subclasses customize the behavior by
     * overriding {@link subExplode}.
     *
     * @returns The entities this entity breaks into, or an empty array when it
     *          cannot be exploded.
     *
     * @example
     * ```typescript
     * const parts = polyline.explode()
     * if (parts.length > 0) {
     *   db.tables.blockTable.modelSpace.appendEntity(parts)
     *   polyline.erase()
     * }
     * ```
     */
    explode(): AcDbEntity[];
    /**
     * Explodes this entity. Called by {@link explode}; mirrors ObjectARX
     * `AcDbEntity::subExplode()`.
     *
     * Overrides must return new, non-database-resident entities in WCS and must
     * not modify this entity. The default implementation returns `undefined`,
     * meaning the entity cannot be exploded.
     *
     * @returns The exploded entities, or `undefined` / an empty array when this
     *          entity cannot be exploded.
     */
    protected subExplode(): AcDbEntity[] | undefined;
    /**
     * Joins `other` into a new entity with this as the primary, mirroring
     * ObjectARX `AcDbEntity::joinEntity()`.
     *
     * The returned entity is a new, non-database-resident object. This entity and
     * `other` are not modified: the caller (for example the JOIN command) must
     * append the result and erase the sources.
     *
     * Returns `undefined` when the two entities cannot be joined (ObjectARX
     * `Acad::eNotApplicable`), e.g. closed curves, non-collinear lines, or
     * unsupported types.
     *
     * This method is non-virtual: subclasses customize behavior by overriding
     * {@link subJoinEntity}.
     *
     * @param other - Secondary entity to join with this primary.
     * @returns The joined entity, or `undefined` when join is not applicable.
     */
    joinEntity(other: AcDbEntity): AcDbEntity | undefined;
    /**
     * Joins `others` into a new entity with this as the primary, mirroring
     * ObjectARX `AcDbEntity::joinEntities()`.
     *
     * Same contract as {@link joinEntity}: returns a new entity and does not
     * mutate or erase inputs. Subclasses that support batch rules (gapped
     * collinear lines, concentric arcs, polyline chains) override
     * {@link subJoinEntities}.
     *
     * @param others - Secondary entities to join with this primary.
     * @returns The joined entity, or `undefined` when join is not applicable.
     */
    joinEntities(others: readonly AcDbEntity[]): AcDbEntity | undefined;
    /**
     * Pairwise join hook for {@link joinEntity}. Default: not joinable.
     */
    protected subJoinEntity(_other: AcDbEntity): AcDbEntity | undefined;
    /**
     * Multi-entity join hook for {@link joinEntities}.
     *
     * Default folds a single secondary through {@link joinEntity}; longer lists
     * return `undefined` unless a subclass overrides for batch join rules.
     */
    protected subJoinEntities(others: readonly AcDbEntity[]): AcDbEntity | undefined;
    /**
     * Copies the general entity properties of `source` to this entity, mirroring
     * ObjectARX `AcDbEntity::setPropertiesFrom()`.
     *
     * The copied properties are layer, color, linetype, linetype scale,
     * lineweight, transparency and visibility. Unset (lazily resolved) values
     * stay unset so that database defaults still apply when this entity is
     * appended to a database.
     *
     * @param source - Entity whose properties are copied.
     * @returns This entity.
     */
    setPropertiesFrom(source: AcDbEntity): this;
    /**
     * Adds the layer and linetype this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Translates the layer and linetype names of a cloned entity.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Gets the geometric extents of this entity.
     *
     * This method should be implemented by subclasses to return the
     * bounding box that encompasses the entire entity.
     *
     * @returns The geometric extents as a 3D bounding box
     *
     * @example
     * ```typescript
     * const extents = entity.geometricExtents;
     * console.log(`Min: ${extents.minPoint}, Max: ${extents.maxPoint}`);
     * ```
     */
    abstract get geometricExtents(): AcGeBox3d;
    /**
     * Erase the current entity from the associated database.
     *
     * @returns — true if an entity in the database existed and has been removed,
     * or false if the entity does not exist.
     */
    erase(): boolean;
    /**
     * Draws this entity using the specified renderer.
     *
     * This method should be implemented by subclasses to provide
     * entity-specific drawing behavior.
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true. For now, text and mtext entity supports this flag only. Other types of entities
     * just ignore this flag.
     * @returns The rendered entity, or undefined if drawing failed
     */
    abstract subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * The batchable primitive kind emitted by {@link subWorldDraw}, when this entity
     * is eligible for direct geometry batching without an intermediate drawable tree.
     *
     * Default `null`: not eligible. Simple entities override to return the expected
     * primitive kind (`lineStrip`, `point`, `area`, …). Renderers should still treat
     * capture misses (wide polyline → `area` instead of `lines`, multi-draw, etc.)
     * as a fallback to the legacy path.
     *
     * @internal
     */
    get directBatchPrimitive(): AcGiDirectBatchPrimitive | null;
    /**
     * Called by cad application when it wants the entity to draw itself in WCS (World Coordinate
     * System) and acts as a wrapper / dispatcher around subWorldDraw(). The children class should
     * never overidde this method.
     *
     * It executes the following logic:
     * - Skips drawing when the entity's layer is not drawable under the database
     *   {@link AcDbDatabase.drawNoPlotLayers} policy
     * - Handles traits (color, linetype, lineweight, transparency, etc.)
     * - Sets {@link AcGiRenderer.context} database for draw-time database lookups
     * - Calls subWorldDraw() to do the actual geometry output
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true. For now, text and mtext entity supports this flag only. Other types of entities
     * just ignore this flag.
     * @returns The rendered entity, or undefined if drawing failed
     */
    worldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Paints `traits` with a color taken from a style (DIMCLRD, MLEADER style
     * colors) instead of this entity's own color.
     *
     * {@link worldDraw} records on the traits whether the entity color was
     * ByLayer. A substituted color carries its own provenance: leaving the
     * entity's flag in place makes renderers treat an explicit style color as
     * layer-bound and repaint it with the layer color.
     *
     * @param traits - Renderer traits to update.
     * @param color - Color to draw with.
     * @param isByLayer - Whether `color` follows the layer. Defaults to
     *   `color.isByLayer`; pass `true` for a layer color already resolved to a
     *   concrete value.
     * @returns A callback restoring the previous color and provenance.
     */
    protected applyTraitsColor(traits: AcGiSubEntityTraits, color: AcCmColor, isByLayer?: boolean): () => void;
    /**
     * Creates the "General" property group for this entity.
     *
     * This group contains common metadata attributes shared by all CAD entities
     * (e.g., handle, layer). Each property includes a runtime {@link AcDbPropertyAccessor}
     * allowing the property inspector to read and update live values.
     *
     * Subclasses may override this method to append additional general-purpose
     * properties while still preserving this base set.
     *
     * @returns A fully resolved property group containing runtime-accessible properties.
     */
    protected getGeneralProperties(): AcDbEntityPropertyGroup;
    /**
     * Gets the line style for this entity.
     *
     * This method returns the line style based on the entity's linetype
     * and other properties.
     *
     * @returns The line style object
     *
     * @example
     * ```typescript
     * const lineStyle = entity.lineStyle;
     * ```
     */
    get lineStyle(): AcGiLineStyle;
    /**
     * Gets the line type for this entity.
     *
     * This method resolves the line type, handling ByLayer and ByBlock
     * references as needed.
     *
     * @returns The resolved line type
     *
     * @example
     * ```typescript
     * const lineType = entity.getLineType();
     * ```
     */
    private getLineType;
    /**
     * Gets the color of the layer this entity belongs to.
     *
     * This method retrieves the color from the layer table for the
     * layer this entity belongs to.
     *
     * @returns The layer color, or undefined if the layer doesn't exist
     *
     * @example
     * ```typescript
     * const layerColor = entity.getLayerColor();
     * ```
     */
    protected getLayerColor(): AcCmColor | null;
    /**
     * Attaches entity information to a graphic interface entity.
     *
     * This method transfers essential entity properties (object ID, owner ID,
     * layer name, and visibility) from this entity to the target graphic
     * interface entity. This is typically used during the rendering process
     * to ensure the graphic entity has the correct metadata.
     *
     * @param target - The graphic interface entity to attach information to
     *
     */
    private attachEntityInfo;
}
//# sourceMappingURL=AcDbEntity.d.ts.map