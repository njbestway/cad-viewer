import { type AcGeBoundaryEdgeType } from '@mlightcad/geometry-engine';
import { AcDbEntity } from './AcDbEntity.js';
/**
 * Converts a supported boundary entity into hatch boundary edges.
 *
 * Used when creating associative hatches and when rebuilding loops from
 * source boundary soft-pointers (DXF group 330).
 *
 * A single path may reference several open entities (lines, arcs, elliptical
 * arcs, splines) that together form a closed loop. Closed polylines/circles
 * (and closed arcs/ellipses/splines) may also be the sole source for a path.
 *
 * Supported entities: polyline, circle, arc, line, ellipse, spline.
 */
export declare function acdbHatchBoundaryEdgesFromEntity(entity: AcDbEntity): AcGeBoundaryEdgeType[];
//# sourceMappingURL=acdbHatchBoundaryEdgesFromEntity.d.ts.map