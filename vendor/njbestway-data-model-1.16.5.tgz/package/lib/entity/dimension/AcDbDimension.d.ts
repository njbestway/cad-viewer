import { AcGeBox3d, AcGeIntersectPrimitive, AcGeLine3d, AcGeMatrix3d, AcGePoint2dLike, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiArrowStyle, AcGiArrowType, AcGiMTextAttachmentPoint, AcGiRenderer } from '@mlightcad/graphic-interface';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../../base/AcDbIdMapping.js';
import { AcDbObjectId } from '../../base/index.js';
import { AcDbDxfFiler } from '../../base/index.js';
import type { AcDbBlockTableRecord } from '../../database/AcDbBlockTableRecord.js';
import { AcDbDimStyleTableRecord } from '../../database/index.js';
import { type AcDbAnnotationScaleContext, type AcDbAnnotationScaleDrawInfo } from '../../misc/index.js';
import { AcDbOsnapMode } from '../../misc/index.js';
import { AcDbDimensionObjectContextData } from '../../object/AcDbDimensionObjectContextData.js';
import { AcDbEntity } from '../AcDbEntity.js';
import { AcDbEntityProperties, AcDbEntityPropertyGroup, AcDbEntityPropertyType, AcDbEntityRuntimeProperty } from '../AcDbEntityProperties.js';
/**
 * Defines the line spacing style for dimension text.
 */
export declare enum AcDbLineSpacingStyle {
    /** At least the specified spacing */
    AtLeast = 1,
    /** Exactly the specified spacing */
    Exactly = 2
}
/**
 * Abstract base class for all dimension entity types in AutoCAD.
 *
 * This class provides the fundamental functionality for all dimension entities,
 * including dimension text, style management, arrow handling, and measurement
 * calculations. The appearance of dimensions is controlled by dimension variable
 * settings and dimension styles.
 *
 * @example
 * ```typescript
 * class MyDimension extends AcDbDimension {
 *   // Implementation for specific dimension type
 *   draw(renderer: AcGiRenderer) {
 *     // Custom drawing logic
 *   }
 * }
 * ```
 */
export declare abstract class AcDbDimension extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The block table record ID containing the dimension entities */
    private _dimBlockId;
    /** The relative position point of the block referenced by the dimension (in WCS coordinates). */
    private _dimBlockPosition;
    /**
     * DXF group code 10 definition point captured during {@link dxfInFields}.
     *
     * This is **not** {@link dimBlockPosition} (DXF group 12). Subclasses use it
     * as the dim-line / center / far-chord point when their typed point codes are
     * absent (matching AutoCAD DXF and dxf-json-converter).
     */
    protected _dxfDefinitionPoint: AcGePoint3d;
    /** The dimension style name used by this dimension */
    private _dimensionStyleName;
    /** The user-supplied dimension annotation text */
    private _dimensionText;
    /** The measured value of the dimension */
    private _measurement?;
    /** The line spacing factor for dimension text */
    private _textLineSpacingFactor;
    /** The line spacing style for dimension text */
    private _textLineSpacingStyle;
    /** The position of the dimension text */
    private _textPosition;
    /** The rotation angle of the dimension text */
    private _textRotation;
    /**
     * Horizontal direction for the dimension entity (DXF group 51), in radians.
     * Negative of the angle between the OCS X axis and the UCS X axis.
     */
    private _horizontalRotation;
    /**
     * Dimension type flags (DXF group 70). Low bits select the dimension kind;
     * bit 32 marks user-defined text position, etc.
     */
    private _dimensionType;
    /** Dimension text attachment point (DXF group 71). */
    private _attachmentPoint;
    /** DXF class version (group 280); 0 = R2010+. */
    private _dxfVersion;
    /** The cached dimension style record */
    private _dimStyle?;
    /** The normal vector of the plane containing the block reference */
    private _normal;
    /**
     * Additional rotation (radians) applied when placing the anonymous dimension
     * block. Block geometry is authored at a fixed orientation; this accumulates
     * rigid-body rotations from {@link transformBy} so the block rotates with the
     * dimension definition points.
     */
    private _dimBlockRotation;
    /**
     * Additional uniform scale applied when placing the anonymous dimension
     * block. Accumulates the scale of {@link transformBy} so cached block
     * geometry stays on the scaled definition points until
     * {@link recomputeDimBlock} regenerates it (which resets it to 1, keeping
     * text height and arrow size at their dimension-style values like
     * AutoCAD SCALE).
     */
    private _dimBlockScale;
    /**
     * Set by {@link recomputeDimBlock}: {@link dimBlockId} was regenerated from
     * the definition points and wins over annotative scale-context blocks.
     */
    private _dimBlockRegenerated;
    /**
     * Creates a new dimension entity.
     *
     * This constructor initializes a dimension with default values.
     * Subclasses should override this constructor to set up dimension-specific properties.
     *
     * @example
     * ```typescript
     * const dimension = new MyDimension();
     * dimension.dimensionText = "10.0";
     * dimension.textPosition = new AcGePoint3d(5, 5, 0);
     * ```
     */
    constructor();
    /**
     * Gets the block table record ID containing the entities that this dimension displays.
     *
     * @returns The block table record ID, or null if not set
     *
     * @example
     * ```typescript
     * const blockId = dimension.dimBlockId;
     * console.log(`Dimension block ID: ${blockId}`);
     * ```
     */
    get dimBlockId(): string | null;
    /**
     * Sets the block table record ID for this dimension.
     *
     * @param value - The block table record ID, or null to clear
     *
     * @example
     * ```typescript
     * dimension.dimBlockId = "MyDimensionBlock";
     * ```
     */
    set dimBlockId(value: string | null);
    /**
     * Gets the relative position point of the block referenced by the dimension (in WCS coordinates).
     * The block position is the insertion point of the block referenced by the dimension, relative to
     * the primary definition point (DXF group code 10) of the dimension itself.
     *
     * The block position (in WCS) is added to the dimension primary definition point (also in WCS) to
     * get the actual insertion point for the anonymous block that is referenced by the dimension. So,
     * for example, changing a dimension's block position from (0,0,0) to (0,0,1) (in WCS) will cause
     * the dimension to display as though it has been moved 1 unit along the WCS Z axis.
     *
     * For a dimension newly created via any dimension command, the block position will be (0,0,0).
     * For copies of existing dimensions, or if a dimension is moved, the block position will be the
     * offset vector (in WCS) from where the original dimension was located. For example, moving a
     * dimension 1 unit down the WCS Y axis will cause AutoCAD to update the block position value from
     * (0,0,0) to (0,-1,0) (in WCS coordinates).
     *
     * The position point is used for DXF group code 12.
     *
     * @returns The relative position point of the block referenced by the dimension.
     *
     */
    get dimBlockPosition(): AcGePoint3d;
    /**
     * Sets the relative position point of the block referenced by the dimension (in WCS coordinates).
     * The block position is the insertion point of the block referenced by the dimension, relative to
     * the primary definition point (DXF group code 10) of the dimension itself.
     *
     * The block position (in WCS) is added to the dimension primary definition point (also in WCS) to
     * get the actual insertion point for the anonymous block that is referenced by the dimension. So,
     * for example, changing a dimension's block position from (0,0,0) to (0,0,1) (in WCS) will cause
     * the dimension to display as though it has been moved 1 unit along the WCS Z axis.
     *
     * For a dimension newly created via any dimension command, the block position will be (0,0,0).
     * For copies of existing dimensions, or if a dimension is moved, the block position will be the
     * offset vector (in WCS) from where the original dimension was located. For example, moving a
     * dimension 1 unit down the WCS Y axis will cause AutoCAD to update the block position value from
     * (0,0,0) to (0,-1,0) (in WCS coordinates).
     *
     * The position point is used for DXF group code 12.
     *
     * @param value - The relative position point of the block referenced by the dimension.
  
     */
    set dimBlockPosition(value: AcGePoint3dLike);
    /**
     * Gets the dimension style name used by this dimension.
     *
     * @returns The dimension style name, or null if not set
     *
     * @example
     * ```typescript
     * const styleName = dimension.dimensionStyleName;
     * console.log(`Dimension style: ${styleName}`);
     * ```
     */
    get dimensionStyleName(): string | null;
    /**
     * Sets the dimension style name for this dimension.
     *
     * @param value - The dimension style name, or null to use default
     *
     * @example
     * ```typescript
     * dimension.dimensionStyleName = "Standard";
     * ```
     */
    set dimensionStyleName(value: string | null);
    /**
     * Gets the dimension style used by this dimension.
     *
     * Entity-level `ACAD`/`DSTYLE` XData overrides are layered on top of the
     * referenced table record, which is how AutoCAD stores per-dimension changes
     * to DIMASZ, DIMGAP, DIMLDRBLK, tolerance settings and so on.
     *
     * @returns The effective dimension style record
     *
     * @example
     * ```typescript
     * const style = dimension.dimensionStyle;
     * console.log(`Style name: ${style.name}`);
     * ```
     */
    get dimensionStyle(): AcDbDimStyleTableRecord;
    /**
     * Gets the user-supplied dimension annotation text string.
     *
     * This string can contain multiline text formatting characters. The text can be:
     * - Empty string ('') for default text only
     * - Text with angle brackets for mixed default and user text (e.g., 'This is the default text <>')
     * - Period ('.') for no text
     * - User-defined text only
     *
     * @returns The dimension text string
     *
     * @example
     * ```typescript
     * const text = dimension.dimensionText;
     * console.log(`Dimension text: ${text}`);
     * ```
     */
    get dimensionText(): string | null;
    set dimensionText(value: string | null);
    /**
     * The current measurement value for this dimension
     */
    get measurement(): number | undefined;
    set measurement(value: number | undefined);
    /**
     * The line spacing factor (a value between 0.25 and 4.00).
     */
    get textLineSpacingFactor(): number;
    set textLineSpacingFactor(value: number);
    /**
     * The line spacing style for the dimension.
     */
    get textLineSpacingStyle(): AcDbLineSpacingStyle;
    set textLineSpacingStyle(value: AcDbLineSpacingStyle);
    /**
     * The dimension's text position point. This is the middle center point of the text (which is itself an
     * MText object with middle-center justification).
     */
    get textPosition(): AcGePoint3d;
    set textPosition(value: AcGePoint3d);
    /**
     * The rotation angle (in radians) of the dimension's annotation text. This is the angle from the
     * dimension's horizontal axis to the horizontal axis used by the text. The angle is in the dimension's
     * OCS X-Y plane with positive angles going counterclockwise when looking down the OCS Z axis towards
     * the OCS origin. The value obtained from: (2 * pi) + the dimension's text rotation angle--the
     * dimension's horizontal rotation angle
     */
    get textRotation(): number;
    set textRotation(value: number);
    /**
     * Horizontal direction for the dimension entity (DXF group 51), in radians.
     *
     * Per the AutoCAD DXF reference this is the negative of the angle between
     * the OCS X axis and the UCS X axis, always in the OCS XY plane.
     */
    get horizontalRotation(): number;
    set horizontalRotation(value: number);
    /**
     * Dimension type flags from DXF group 70.
     *
     * Bits 0–3 encode the dimension kind; bit 5 (32) indicates the text was
     * placed at a user-defined location.
     */
    get dimensionType(): number;
    set dimensionType(value: number);
    /**
     * Whether the dimension text is at its default (home) position.
     *
     * Backed by bit 128 of {@link dimensionType}, which AutoCAD sets once the
     * text is dragged away from home. When `false`, {@link createDimBlock} keeps
     * {@link textPosition} instead of recomputing it.
     */
    get isUsingDefaultTextPosition(): boolean;
    set isUsingDefaultTextPosition(value: boolean);
    /**
     * Attachment point of the dimension text (DXF group 71).
     */
    get attachmentPoint(): AcGiMTextAttachmentPoint;
    set attachmentPoint(value: AcGiMTextAttachmentPoint);
    /**
     * DXF class version (group 280). `0` means R2010+.
     */
    get dxfVersion(): number;
    set dxfVersion(value: number);
    /**
     * Gets the normal vector of the plane containing the dimension.
     *
     * @returns The normal vector
     */
    get normal(): AcGeVector3d;
    /**
     * Sets the normal vector of the plane containing the dimension.
     *
     * @param value - The new normal vector
     */
    set normal(value: AcGeVector3dLike);
    /**
     * Whether this dimension is annotative (AcadAnnotative XDATA and/or scale contexts).
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    get properties(): AcDbEntityProperties;
    protected getBaseProperties(): AcDbEntityProperties;
    /**
     * Transforms this dimension by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Resolves osnap points through the anonymous dimension block.
     *
     * Dimensions are rendered from `dimBlockId` contents, so osnap queries need
     * to delegate to the block entities and map points between block-local space
     * and WCS.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[], gsMark?: AcDbObjectId): void;
    /**
     * Resolves the anonymous dim block and transform origin for the active
     * CANNOSCALE when this dimension is annotative.
     */
    resolveAnnotativePresentation(): {
        dimBlockId: string | null;
        blockPosition: AcGePoint3d;
        preferred?: AcDbAnnotationScaleContext;
        annotationScale?: AcDbAnnotationScaleDrawInfo;
        featureScale: number;
        contextData?: AcDbDimensionObjectContextData;
    };
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity | undefined;
    /**
     * Attaches viewport annotation-scale metadata when this dimension is annotative.
     */
    private attachAnnotationScaleDrawInfo;
    /**
     * Explodes this dimension into the entities of its anonymous dimension
     * block (lines, arcs, multiline text, points and arrowhead block
     * references), like AutoCAD EXPLODE.
     *
     * The parts are placed in WCS with the dimension block transform. Layer `0`
     * and ByBlock values resolve to the dimension's own properties, so the
     * exploded geometry looks the same as the dimension. When the dimension has
     * no block yet, its geometry is generated with {@link createDimBlock}
     * without adding a block to the database.
     */
    protected subExplode(): AcDbEntity[];
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Computes transformed geometric extents from the anonymous dimension block.
     */
    protected getDimBlockGeometricExtents(): AcGeBox3d;
    /**
     * Builds geometric extents from a dimension block when present, otherwise from
     * the supplied WCS definition points and user-placed text position.
     */
    protected getGeometricExtentsFromDimBlockOrPoints(points: AcGePoint3dLike[]): AcGeBox3d;
    /**
     * Returns true when dimension text has been placed away from the default origin.
     */
    private hasExplicitTextPosition;
    /**
     * Collects dimension-specific definition grip points in WCS coordinates.
     *
     * Subclasses override this to expose their editable definition points,
     * matching AutoCAD `AcDbDimension::getGripPoints` behavior.
     */
    protected collectDimensionDefinitionGripPoints(): AcGePoint3d[];
    /**
     * Gets the grip points for this dimension.
     *
     * Returns definition points together with the dimension text position.
     *
     * @returns Array of grip points as 3D points
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Moves dimension definition and text grip points by the given offset.
     *
     * Grip indices follow {@link subGetGripPoints}: definition grips first, the
     * text grip last. Each dimension type applies AutoCAD's stretch rules through
     * {@link moveDefinitionGripAt} and {@link moveTextGrip}. Only the definition
     * data changes; call {@link recomputeDimBlock} afterwards to regenerate the
     * displayed geometry.
     */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Stretch points are definition grips only (AutoCAD excludes the text grip).
     */
    subGetStretchPoints(): AcGePoint3d[];
    /**
     * Moves selected definition stretch points (not the text grip).
     *
     * Delegates to {@link subMoveGripPointsAt} so subclasses that dedupe paired
     * definition grips (aligned dim-line ends, radial/diametric chords) keep the
     * same stretch behavior as grip editing.
     */
    subMoveStretchPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Moves one definition grip. The default moves the point returned by
     * {@link collectDimensionDefinitionGripPoints} freely.
     *
     * @param index - Definition grip index.
     * @param offset - WCS displacement of the grip.
     */
    protected moveDefinitionGripAt(index: number, offset: AcGeVector3dLike): void;
    /**
     * Moves the text grip. The default places the text at the new location and
     * marks it as user-defined.
     *
     * @param offset - WCS displacement of the text grip.
     */
    protected moveTextGrip(offset: AcGeVector3dLike): void;
    /**
     * DIMTMOVE of the effective dimension style: 0 moves the dimension line with
     * the text, 1 adds a leader, 2 moves the text freely.
     */
    protected get textMovement(): number;
    /**
     * Returns the text position to use while building the dimension block.
     *
     * Keeps a user-defined {@link textPosition}; otherwise stores and returns
     * the supplied default position.
     *
     * @param defaultPosition - Home position computed by the dimension type.
     */
    protected resolveBlockTextPosition(defaultPosition: AcGePoint3d): AcGePoint3d;
    /**
     * Computes the measured value from the current definition points, ignoring
     * the stored {@link measurement}.
     *
     * @returns The measured value, or `undefined` when the type cannot measure.
     */
    protected computeMeasurement(): number | undefined;
    /**
     * Builds the anonymous block holding this dimension's graphics from its
     * current definition points and style. The block is not added to the
     * database.
     *
     * @param blockName - Name of the new block record.
     */
    abstract createDimBlock(blockName: string): AcDbBlockTableRecord;
    /**
     * Regenerates the anonymous dimension block after the definition points
     * changed, like ObjectARX `AcDbDimension::recomputeDimBlock`.
     *
     * The measurement is refreshed, a new block is built and added to the
     * database, and {@link dimBlockId} points at it. The previous block is left
     * untouched so undo, which restores the old `dimBlockId`, still finds it.
     *
     * @param blockName - Block name to use. An existing block with this name is
     *   replaced (used for transient previews). Defaults to the next free `*D{n}`.
     * @returns The name of the new block.
     */
    recomputeDimBlock(blockName?: string): string;
    /**
     * Looks up the anonymous block referenced by `dimBlockId` (or an override
     * from the active annotation-scale context).
     */
    protected getDimBlockTableRecord(blockId?: string | null): AcDbBlockTableRecord | undefined;
    protected getDimensionProperties(): AcDbEntityPropertyGroup;
    protected createProperty<T>(name: string, type: AcDbEntityPropertyType, get: () => T, set?: (value: T) => void, options?: {
        label: string;
        value: unknown;
    }[]): AcDbEntityRuntimeProperty<T>;
    /**
     * Creates X/Y/Z properties for a definition point. Editing a coordinate
     * passes a new point to `setPoint`; the palette regenerates the dimension
     * block afterwards (see {@link recomputeDimBlock}).
     */
    protected createPoint3dProperties(prefix: string, getPoint: () => AcGePoint3d, setPoint?: (value: AcGePoint3d) => void): AcDbEntityRuntimeProperty<number>[];
    protected getMeasurementPropertyValue(): number | undefined;
    /**
     * Builds the complete dimension-block transform (OCS transform + extrusion).
     */
    protected getFullDimBlockTransform(blockPosition?: AcGePoint3dLike): AcGeMatrix3d;
    protected get arrowScaleFactor(): number;
    /**
     * Arrow style of the first arrow
     */
    protected get firstArrowStyle(): AcGiArrowStyle;
    /**
     * Arrow style of the second arrow
     */
    protected get secondArrowStyle(): AcGiArrowStyle;
    /**
     * The flag to determinate how to attach arrow to endpoint of the line.
     * - true: append arrow to endpoint of the line
     * - false: overlap arrow with endpoint of the line
     */
    protected get isAppendArrow(): boolean;
    /**
     * The BTR id associated with the first arrow type
     */
    protected get firstArrowTypeBtrId(): string;
    /**
     * The first arrow type
     */
    protected get firstArrowType(): AcGiArrowType;
    /**
     * The BTR id associated with the second arrow type
     */
    protected get secondArrowTypeBtrId(): string;
    /**
     * The second arrow type
     */
    protected get secondArrowType(): AcGiArrowType;
    /**
     * The maximum number of arrow lines of this dimension
     */
    protected get arrowLineCount(): number;
    /**
     * Find the point `p3` on a line along the line direction at a distance `length` from `p2`.
     *
     * @param p1 - The start point of the line.
     * @param p2 - The end point of the line.
     * @param length - The distance from `p2` to `p3`.
     * @returns Return the point `p3`.
     */
    protected findPointOnLine1(p1: AcGePoint3d, p2: AcGePoint3d, length: number): AcGePoint3d;
    /**
     * Find the point `p2` on a line starting from `p1` at a specified angle
     * and at a distance `length` from `p1`.
     *
     * @param p1 - The start point of the line.
     * @param angle - The angle of the line in radians relative to the x-axis.
     * @param length - The distance from `p1` to `p2`.
     * @returns Return the point `p2`.
     */
    protected findPointOnLine2(p1: AcGePoint2dLike, angle: number, length: number): AcGePoint2dLike;
    /**
     * Adjust start point and end point of extension line according current dimension style
     * @param extensionLine Input extension line to adjust its start point and end point
     */
    protected adjustExtensionLine(extensionLine: AcGeLine3d): void;
    /**
     * Get dimension style name by dimension block id
     * @param id Input dimension block id
     * @returns Return dimension style name by dimension block id
     */
    private getArrowName;
    /**
     * Computes the block-local transformation matrix for the anonymous block
     * referenced by this dimension entity.
     *
     * In AutoCAD, each dimension references an **anonymous block** that contains
     * the graphical representation of the dimension (dimension line, extension
     * lines, arrows, and text). That block is defined in the **dimension?? Object
     * Coordinate System (OCS)**.
     *
     * This method computes the transformation that positions the anonymous
     * dimension block **within the dimension?? OCS**, excluding any extrusion
     * (normal) transformation.
     *
     * Conceptually, AutoCAD applies the following steps when displaying a
     * dimension block:
     *
     * 1. Translate block geometry by the negative block base point
     * 2. Translate by the dimension block position (DXF group code 12)
     * 3. Finally, transform from OCS to WCS using the dimension normal (DXF 210)
     *
     * This method implements **steps 1 and 2 only**.
     *
     * The OCS ??WCS transformation derived from {@link normal} is **intentionally
     * excluded** and must be applied **after rendering** (see
     * {@link AcDbRenderingCache.draw}). This matches AutoCAD / RealDWG behavior and
     * ensures:
     *
     * - Dimension text rotation remains defined in OCS
     * - Arrow orientation and extension line directions remain correct
     * - Anonymous dimension blocks can be safely cached and reused
     *
     * ### Matrix composition (right-multiply convention)
     *
     * ```
     * dimBlockTransform =
     *   T(dimBlockPosition)
     * ? R(dimBlockRotation)
     * ? T(-blockBasePoint)
     * ```
     *
     * ### Notes
     *
     * - The returned matrix operates entirely in dimension OCS
     * - {@link transformBy} accumulates extra block rotation so cached anonymous
     *   block geometry rotates with the dimension definition points
     * - {@link normal} is applied later as a final orientation step
     *
     * @returns A transformation matrix that positions the anonymous dimension
     *          block in OCS space, excluding extrusion.
     */
    private computeDimBlockTransform;
    /**
     * Subclasses can override this to transform their own definition points.
     */
    protected subTransformBy(_matrix: AcGeMatrix3d): void;
    /**
     * Adds the dimension style and the dimension block this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Translates the dimension style and dimension block names of a clone.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Returns the owning database, or `undefined` for a detached dimension.
     *
     * `.database` falls back to the host working database and throws when none is
     * set (detached entities in unit tests / clone paths), so style resolution
     * cannot rely on it.
     */
    private tryGetDatabase;
    /**
     * Drops the cached effective dimension style when `ACAD` XData changes.
     *
     * `dimensionStyle` memoizes the record built from the base table record plus
     * the entity-level `ACAD`/`DSTYLE` overrides. Writing new XData, clearing the
     * style or reloading the entity must not keep the previous geometry settings.
     */
    protected onXDataChanged(appId: string): void;
    /**
     * Drops the cached effective style when the entity moves to another database,
     * because the referenced style record belongs to the previous database.
     */
    protected onDatabaseChanged(): void;
}
//# sourceMappingURL=AcDbDimension.d.ts.map