import { AcCmColor } from '@mlightcad/common';
import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiMTextAttachmentPoint, AcGiMTextFlowDirection, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { type AcDbAnnotationScaleContext, type AcDbAnnotationScaleDrawInfo } from '../misc/AcDbAnnotationScale.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbMLeaderStyle } from '../object/AcDbMLeaderStyle.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbEntityProperties } from './AcDbEntityProperties.js';
/**
 * Defines the type of leader line used by a multileader.
 */
export declare enum AcDbMLeaderLineType {
    /** The leader line is not displayed. */
    InvisibleLeader = 0,
    /** The leader line is drawn using straight segments. */
    StraightLeader = 1,
    /** The leader line is drawn as a spline. */
    SplineLeader = 2
}
/**
 * Defines the annotation content type used by a multileader.
 */
export declare enum AcDbMLeaderContentType {
    /** No annotation content. */
    NoneContent = 0,
    /** Block annotation content. */
    BlockContent = 1,
    /** MText annotation content. */
    MTextContent = 2,
    /** Tolerance annotation content. */
    ToleranceContent = 3
}
/**
 * Defines the attachment direction of multileader text.
 */
export declare enum AcDbMLeaderTextAttachmentDirection {
    /** Text is attached horizontally. */
    Horizontal = 0,
    /** Text is attached vertically. */
    Vertical = 1
}
/**
 * Defines the general direction of a leader branch.
 */
export declare enum AcDbMLeaderDirectionType {
    /** Direction is not known or not applicable. */
    Unknown = 0,
    /** Leader points to the left of the content. */
    Left = 1,
    /** Leader points to the right of the content. */
    Right = 2,
    /** Leader points above the content. */
    Top = 3,
    /** Leader points below the content. */
    Bottom = 4
}
/**
 * Bits of {@link AcDbMLeader.propertyOverrideFlag} (DXF group 90). A set bit
 * means the entity value wins over its multileader style.
 */
export declare enum AcDbMLeaderPropertyOverrideFlag {
    /** Leader line type (straight / spline / none). */
    LeaderLineType = 1,
    /** Leader line color. */
    LeaderLineColor = 2,
    /** Leader linetype. */
    LeaderLineTypeId = 4,
    /** Leader lineweight. */
    LeaderLineWeight = 8,
    /** Landing (dogleg) on/off. */
    DoglegEnabled = 64,
    /** Landing (dogleg) length. */
    DoglegLength = 128,
    /** Text color. */
    TextColor = 32768
}
/**
 * Represents a leader break segment input using point-like values.
 */
export interface AcDbMLeaderBreakLike {
    index?: number;
    start: AcGePoint3dLike;
    end: AcGePoint3dLike;
}
/**
 * Represents a normalized leader break segment stored with concrete points.
 */
export interface AcDbMLeaderBreak {
    index?: number;
    start: AcGePoint3d;
    end: AcGePoint3d;
}
/**
 * Represents a leader-line input payload before normalization.
 */
export interface AcDbMLeaderLineLike {
    vertices?: AcGePoint3dLike[];
    breakPointIndexes?: number[];
    leaderLineIndex?: number;
    breaks?: AcDbMLeaderBreakLike[];
}
/**
 * Represents one normalized leader line.
 */
export interface AcDbMLeaderLine {
    vertices: AcGePoint3d[];
    breakPointIndexes: number[];
    leaderLineIndex?: number;
    breaks: AcDbMLeaderBreak[];
}
/**
 * Represents a leader-branch input payload.
 */
export interface AcDbMLeaderLeaderLike {
    lastLeaderLinePoint?: AcGePoint3dLike;
    lastLeaderLinePointSet?: boolean;
    landingPoint?: AcGePoint3dLike;
    doglegVector?: AcGeVector3dLike;
    doglegVectorSet?: boolean;
    doglegLength?: number;
    breaks?: AcDbMLeaderBreakLike[];
    leaderBranchIndex?: number;
    directionType?: AcDbMLeaderDirectionType;
    leaderLines?: AcDbMLeaderLineLike[];
}
/**
 * Represents one normalized leader branch stored by the entity.
 */
export interface AcDbMLeaderLeader {
    lastLeaderLinePoint?: AcGePoint3d;
    lastLeaderLinePointSet?: boolean;
    landingPoint?: AcGePoint3d;
    doglegVector?: AcGeVector3d;
    doglegVectorSet?: boolean;
    doglegLength?: number;
    breaks: AcDbMLeaderBreak[];
    leaderBranchIndex?: number;
    directionType?: AcDbMLeaderDirectionType;
    leaderLines: AcDbMLeaderLine[];
}
/**
 * Represents MText content input data for a multileader.
 */
export interface AcDbMLeaderMTextContentLike {
    text: string;
    anchorPoint: AcGePoint3dLike;
}
/**
 * Represents normalized MText content stored by a multileader.
 */
export interface AcDbMLeaderMTextContent {
    text: string;
    anchorPoint: AcGePoint3d;
}
/**
 * Represents block content input data for a multileader.
 */
export interface AcDbMLeaderBlockContentLike {
    blockContentId?: string;
    blockHandle?: string;
    normal?: AcGeVector3dLike;
    position?: AcGePoint3dLike;
    scale?: AcGeVector3dLike;
    rotation?: number;
    color?: AcCmColor;
    transformationMatrix?: number[];
}
/**
 * Represents normalized block content stored by a multileader.
 */
export interface AcDbMLeaderBlockContent {
    blockContentId?: string;
    blockHandle?: string;
    normal?: AcGeVector3d;
    position?: AcGePoint3d;
    scale: AcGeVector3d;
    rotation: number;
    color?: AcCmColor;
    transformationMatrix: number[];
}
/**
 * Represents a handle tied to a specific index in multileader data.
 */
export interface AcDbMLeaderIndexedHandle {
    index: number;
    handle?: string;
}
/**
 * Represents one block attribute override entry.
 */
export interface AcDbMLeaderBlockAttribute {
    id?: string;
    index?: number;
    width?: number;
    text?: string;
}
/**
 * Represents a multileader entity.
 *
 * A multileader contains one or more leader branches, each of which can contain
 * one or more leader lines, plus optional MText or block content.
 */
export declare class AcDbMLeader extends AcDbEntity {
    /** The entity type name. */
    static typeName: string;
    /**
     * Gets the DXF type name used when exporting this entity.
     */
    get dxfTypeName(): string;
    private _leaders;
    private _leaderLineType;
    private _contentType;
    private _doglegEnabled;
    private _doglegLength;
    private _landingPoint?;
    private _doglegVector;
    private _normal;
    private _mleaderStyleId;
    private _mtextContent?;
    private _textHeight;
    private _textWidth;
    private _textRotation;
    private _textDirection;
    private _textStyleName;
    private _textAttachmentPoint;
    private _textDrawingDirection;
    private _textLineSpacingFactor;
    private _textAttachmentDirection;
    private _blockContent?;
    private _version?;
    private _leaderStyleId?;
    private _propertyOverrideFlag?;
    private _leaderLineColor?;
    private _leaderLineTypeId?;
    private _leaderLineWeight?;
    private _landingEnabled?;
    private _arrowheadId?;
    private _arrowheadSize?;
    private _textStyleId?;
    private _textLeftAttachmentType?;
    private _textRightAttachmentType?;
    private _textAngleType?;
    private _textAlignmentType?;
    private _textColor?;
    private _textFrameEnabled?;
    private _landingGap?;
    private _textAttachment?;
    private _textFlowDirection?;
    private _blockContentId?;
    private _blockContentColor?;
    private _blockContentScale?;
    private _blockContentRotation?;
    private _blockContentConnectionType?;
    private _annotativeScaleEnabled?;
    private _arrowheadOverrides;
    private _blockAttributes;
    private _textDirectionNegative?;
    private _textAlignInIPE?;
    private _bottomTextAttachmentDirection?;
    private _topTextAttachmentDirection?;
    private _contentScale?;
    private _contentBasePosition?;
    private _textAnchor?;
    private _textLineSpacingStyle?;
    private _textBackgroundColor?;
    private _textBackgroundScaleFactor?;
    private _textBackgroundTransparency?;
    private _textBackgroundColorOn?;
    private _textFillOn?;
    private _textColumnType?;
    private _textUseAutoHeight?;
    private _textColumnWidth?;
    private _textColumnGutterWidth?;
    private _textColumnFlowReversed?;
    private _textColumnHeight?;
    private _textUseWordBreak?;
    private _hasMText?;
    private _hasBlock?;
    private _planeOrigin?;
    private _planeXAxisDirection?;
    private _planeYAxisDirection?;
    private _planeNormalReversed?;
    /** Transient presentation used while `subWorldDraw` is in progress. */
    private _drawPresentation?;
    /**
     * Creates an empty multileader entity with default style-related state.
     *
     * @remarks
     * Initializes geometry, text, and block-related members to defaults that
     * are compatible with common MLEADER behavior.
     */
    constructor();
    /**
     * Gets a deep-cloned collection of all leader branches.
     */
    get leaders(): AcDbMLeaderLeader[];
    /**
     * Gets the current number of leader branches.
     */
    get numberOfLeaders(): number;
    /**
     * Gets the leader line type.
     */
    get leaderLineType(): AcDbMLeaderLineType;
    set leaderLineType(value: AcDbMLeaderLineType);
    /**
     * Gets the content type.
     */
    get contentType(): AcDbMLeaderContentType;
    set contentType(value: AcDbMLeaderContentType);
    /**
     * Gets the dogleg enabled.
     */
    get doglegEnabled(): boolean;
    set doglegEnabled(value: boolean);
    /**
     * Gets the dogleg length.
     */
    get doglegLength(): number;
    set doglegLength(value: number);
    /**
     * Gets the dogleg vector.
     */
    get doglegVector(): AcGeVector3dLike;
    set doglegVector(value: AcGeVector3dLike);
    /**
     * Gets the landing point.
     */
    get landingPoint(): AcGePoint3dLike | undefined;
    set landingPoint(value: AcGePoint3dLike | undefined);
    /**
     * Gets the normal.
     */
    get normal(): AcGeVector3dLike;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the mleader style id.
     */
    get mleaderStyleId(): string;
    set mleaderStyleId(value: string);
    /**
     * Gets or sets the serialized MLeader version code.
     *
     * This value mirrors DXF/internal version metadata and is used to keep
     * compatibility with files saved from different AutoCAD generations.
     */
    get version(): number | undefined;
    set version(value: number | undefined);
    /**
     * Gets or sets the MLeader style handle override stored on the entity.
     *
     * When provided, this value is typically used as a fallback in addition to
     * `mleaderStyleId` during style resolution.
     */
    get leaderStyleId(): string | undefined;
    set leaderStyleId(value: string | undefined);
    /**
     * Gets or sets the property-override bit flag.
     *
     * The flag indicates which visual/behavioral properties are overridden at the
     * entity level instead of inherited from the referenced MLeader style.
     */
    get propertyOverrideFlag(): number | undefined;
    set propertyOverrideFlag(value: number | undefined);
    /**
     * Gets or sets the explicit leader line color override.
     */
    get leaderLineColor(): AcCmColor | undefined;
    set leaderLineColor(value: AcCmColor | undefined);
    /**
     * Gets or sets the leader line type handle override.
     */
    get leaderLineTypeId(): string | undefined;
    set leaderLineTypeId(value: string | undefined);
    /**
     * Gets or sets the lineweight override for leader segments.
     */
    get leaderLineWeight(): number | undefined;
    set leaderLineWeight(value: number | undefined);
    /**
     * Gets or sets whether leader landings are enabled.
     */
    get landingEnabled(): boolean | undefined;
    set landingEnabled(value: boolean | undefined);
    /**
     * Gets or sets the arrowhead block handle/name override.
     */
    get arrowheadId(): string | undefined;
    set arrowheadId(value: string | undefined);
    /**
     * Gets or sets the arrowhead size override in drawing units.
     */
    get arrowheadSize(): number | undefined;
    set arrowheadSize(value: number | undefined);
    /**
     * Gets or sets the text style handle override for MText content.
     */
    get textStyleId(): string | undefined;
    set textStyleId(value: string | undefined);
    /**
     * Gets or sets left-side text attachment behavior code.
     */
    get textLeftAttachmentType(): number | undefined;
    set textLeftAttachmentType(value: number | undefined);
    /**
     * Gets or sets right-side text attachment behavior code.
     */
    get textRightAttachmentType(): number | undefined;
    set textRightAttachmentType(value: number | undefined);
    /**
     * Gets or sets the text angle type code controlling rotation strategy.
     */
    get textAngleType(): number | undefined;
    set textAngleType(value: number | undefined);
    /**
     * Gets or sets the text alignment type code.
     */
    get textAlignmentType(): number | undefined;
    set textAlignmentType(value: number | undefined);
    /**
     * Gets or sets the MText color override.
     */
    get textColor(): AcCmColor | undefined;
    set textColor(value: AcCmColor | undefined);
    /**
     * Gets or sets whether a text frame (border) is enabled.
     */
    get textFrameEnabled(): boolean | undefined;
    set textFrameEnabled(value: boolean | undefined);
    /**
     * Gets or sets the gap distance between landing and annotation content.
     */
    get landingGap(): number | undefined;
    set landingGap(value: number | undefined);
    /**
     * Gets or sets the legacy text attachment value used in some DXF variants.
     */
    get textAttachment(): number | undefined;
    set textAttachment(value: number | undefined);
    /**
     * Gets or sets the text flow direction override code.
     */
    get textFlowDirection(): number | undefined;
    set textFlowDirection(value: number | undefined);
    /**
     * Gets or sets the referenced block content id/handle for block-based content.
     */
    get blockContentId(): string | undefined;
    set blockContentId(value: string | undefined);
    /**
     * Gets or sets the block content color override.
     */
    get blockContentColor(): AcCmColor | undefined;
    set blockContentColor(value: AcCmColor | undefined);
    /**
     * Gets or sets the block content scale vector override.
     */
    get blockContentScale(): AcGeVector3d | undefined;
    set blockContentScale(value: AcGeVector3d | undefined);
    /**
     * Gets or sets the block content rotation override in radians.
     */
    get blockContentRotation(): number | undefined;
    set blockContentRotation(value: number | undefined);
    /**
     * Gets or sets the block content connection type code.
     */
    get blockContentConnectionType(): number | undefined;
    set blockContentConnectionType(value: number | undefined);
    /**
     * Gets or sets whether annotative scaling is enabled for this entity.
     */
    get annotativeScaleEnabled(): boolean | undefined;
    set annotativeScaleEnabled(value: boolean | undefined);
    /**
     * Whether this multileader is annotative (XDATA/contexts or scale-enabled flag).
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    /**
     * Gets or sets per-index arrowhead overrides.
     *
     * Each entry maps a branch/line index to a specific arrowhead handle.
     */
    get arrowheadOverrides(): AcDbMLeaderIndexedHandle[];
    set arrowheadOverrides(value: AcDbMLeaderIndexedHandle[]);
    /**
     * Gets or sets block attribute override values used by block content.
     */
    get blockAttributes(): AcDbMLeaderBlockAttribute[];
    set blockAttributes(value: AcDbMLeaderBlockAttribute[]);
    /**
     * Gets or sets whether text direction is treated as negative.
     */
    get textDirectionNegative(): boolean | undefined;
    set textDirectionNegative(value: boolean | undefined);
    /**
     * Gets or sets the in-place editor text alignment code.
     */
    get textAlignInIPE(): number | undefined;
    set textAlignInIPE(value: number | undefined);
    /**
     * Gets or sets bottom attachment direction code for vertical text behavior.
     */
    get bottomTextAttachmentDirection(): number | undefined;
    set bottomTextAttachmentDirection(value: number | undefined);
    /**
     * Gets or sets top attachment direction code for vertical text behavior.
     */
    get topTextAttachmentDirection(): number | undefined;
    set topTextAttachmentDirection(value: number | undefined);
    /**
     * Gets or sets the overall content scale override.
     */
    get contentScale(): number | undefined;
    set contentScale(value: number | undefined);
    /**
     * Gets or sets the base insertion position of annotation content.
     */
    get contentBasePosition(): AcGePoint3d | undefined;
    set contentBasePosition(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the explicit text anchor position.
     */
    get textAnchor(): AcGePoint3d | undefined;
    set textAnchor(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the text line spacing style code for column/text layout.
     */
    get textLineSpacingStyle(): number | undefined;
    set textLineSpacingStyle(value: number | undefined);
    /**
     * Gets or sets text background color override.
     */
    get textBackgroundColor(): AcCmColor | undefined;
    set textBackgroundColor(value: AcCmColor | undefined);
    /**
     * Gets or sets background-mask scale factor around text.
     */
    get textBackgroundScaleFactor(): number | undefined;
    set textBackgroundScaleFactor(value: number | undefined);
    /**
     * Gets or sets text background transparency value.
     */
    get textBackgroundTransparency(): number | undefined;
    set textBackgroundTransparency(value: number | undefined);
    /**
     * Gets or sets whether explicit background color masking is enabled.
     */
    get textBackgroundColorOn(): boolean | undefined;
    set textBackgroundColorOn(value: boolean | undefined);
    /**
     * Gets or sets whether text fill/mask is enabled.
     */
    get textFillOn(): boolean | undefined;
    set textFillOn(value: boolean | undefined);
    /**
     * Gets or sets the text column layout type code.
     */
    get textColumnType(): number | undefined;
    set textColumnType(value: number | undefined);
    /**
     * Gets or sets whether text column height is auto-managed.
     */
    get textUseAutoHeight(): boolean | undefined;
    set textUseAutoHeight(value: boolean | undefined);
    /**
     * Gets or sets the fixed width for text columns.
     */
    get textColumnWidth(): number | undefined;
    set textColumnWidth(value: number | undefined);
    /**
     * Gets or sets the gutter width between text columns.
     */
    get textColumnGutterWidth(): number | undefined;
    set textColumnGutterWidth(value: number | undefined);
    /**
     * Gets or sets whether text columns flow in reverse order.
     */
    get textColumnFlowReversed(): boolean | undefined;
    set textColumnFlowReversed(value: boolean | undefined);
    /**
     * Gets or sets the explicit text column height.
     */
    get textColumnHeight(): number | undefined;
    set textColumnHeight(value: number | undefined);
    /**
     * Gets or sets whether word breaking is enabled in column layout.
     */
    get textUseWordBreak(): boolean | undefined;
    set textUseWordBreak(value: boolean | undefined);
    /**
     * Gets or sets whether MText content exists in the serialized payload.
     */
    get hasMText(): boolean | undefined;
    set hasMText(value: boolean | undefined);
    /**
     * Gets or sets whether block content exists in the serialized payload.
     */
    get hasBlock(): boolean | undefined;
    set hasBlock(value: boolean | undefined);
    /**
     * Gets or sets the origin of the MLeader plane definition.
     */
    get planeOrigin(): AcGePoint3d | undefined;
    set planeOrigin(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the X-axis direction vector of the MLeader plane.
     */
    get planeXAxisDirection(): AcGeVector3d | undefined;
    set planeXAxisDirection(value: AcGeVector3d | undefined);
    /**
     * Gets or sets the Y-axis direction vector of the MLeader plane.
     */
    get planeYAxisDirection(): AcGeVector3d | undefined;
    set planeYAxisDirection(value: AcGeVector3d | undefined);
    /**
     * Gets or sets whether the MLeader plane normal is reversed.
     */
    get planeNormalReversed(): boolean | undefined;
    set planeNormalReversed(value: boolean | undefined);
    /**
     * Gets the alias of `leaders`.
     */
    get leaderSections(): AcDbMLeaderLeader[];
    /**
     * Gets the alias of `blockContent`.
     */
    get blockContentData(): AcDbMLeaderBlockContentLike | undefined;
    /**
     * Gets the MText content payload if present.
     */
    get mtextContent(): AcDbMLeaderMTextContentLike | undefined;
    set mtextContent(value: AcDbMLeaderMTextContentLike | undefined);
    /**
     * Gets the displayed MText string content.
     */
    get contents(): string;
    set contents(value: string);
    /**
     * Gets the MText anchor point.
     */
    get textLocation(): AcGePoint3dLike | undefined;
    set textLocation(value: AcGePoint3dLike | undefined);
    /**
     * Gets the text height.
     */
    get textHeight(): number;
    set textHeight(value: number);
    /**
     * Gets the text width.
     */
    get textWidth(): number;
    set textWidth(value: number);
    /**
     * Gets the text rotation.
     */
    get textRotation(): number;
    set textRotation(value: number);
    /**
     * Gets the text direction.
     */
    get textDirection(): AcGeVector3dLike;
    set textDirection(value: AcGeVector3dLike);
    /**
     * Gets the text style name.
     */
    get textStyleName(): string;
    set textStyleName(value: string);
    /**
     * Gets the text attachment point.
     */
    get textAttachmentPoint(): AcGiMTextAttachmentPoint;
    set textAttachmentPoint(value: AcGiMTextAttachmentPoint);
    /**
     * Gets the text drawing direction.
     */
    get textDrawingDirection(): AcGiMTextFlowDirection;
    set textDrawingDirection(value: AcGiMTextFlowDirection);
    /**
     * Gets the text line spacing factor.
     */
    get textLineSpacingFactor(): number;
    set textLineSpacingFactor(value: number);
    /**
     * Gets the text attachment direction.
     */
    get textAttachmentDirection(): AcDbMLeaderTextAttachmentDirection;
    set textAttachmentDirection(value: AcDbMLeaderTextAttachmentDirection);
    /**
     * Gets the block content.
     */
    get blockContent(): AcDbMLeaderBlockContentLike | undefined;
    set blockContent(value: AcDbMLeaderBlockContentLike | undefined);
    /**
     * Adds a leader branch and returns its index.
     *
     * @param leader Optional leader payload used to initialize branch data.
     * @returns Index of the newly added leader branch.
     */
    addLeader(leader?: AcDbMLeaderLeaderLike): number;
    /**
     * Removes a leader branch.
     *
     * @param leaderIndex Zero-based index of the leader branch to remove.
     * @returns The current entity instance for chaining.
     */
    removeLeader(leaderIndex: number): this;
    /**
     * Adds a leader line to a leader branch and returns the line index.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param vertices Optional initial vertices for the leader line.
     * @returns Index of the newly added leader line.
     */
    addLeaderLine(leaderIndex: number, vertices?: AcGePoint3dLike[]): number;
    /**
     * Appends a vertex to one leader line.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param leaderLineIndex Index of the target leader line.
     * @param point Vertex to append.
     * @returns The current entity instance for chaining.
     */
    appendVertex(leaderIndex: number, leaderLineIndex: number, point: AcGePoint3dLike): this;
    /**
     * Replaces the vertices of one leader line.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param leaderLineIndex Index of the target leader line.
     * @param vertices New vertex sequence.
     * @returns The current entity instance for chaining.
     */
    setLeaderLineVertices(leaderIndex: number, leaderLineIndex: number, vertices: AcGePoint3dLike[]): this;
    /**
     * Gets cloned vertices from the specified leader line.
     *
     * @param leaderIndex Index of the leader branch.
     * @param leaderLineIndex Index of the leader line in the branch.
     * @returns A cloned vertex list so callers cannot mutate internal state.
     */
    getLeaderLineVertices(leaderIndex: number, leaderLineIndex: number): AcGePoint3d[];
    /**
     * Adds a break segment to a specific leader line.
     *
     * @param leaderIndex Index of the leader branch.
     * @param leaderLineIndex Index of the leader line.
     * @param start Break start point.
     * @param end Break end point.
     * @returns The current entity instance for chaining.
     */
    addBreak(leaderIndex: number, leaderLineIndex: number, start: AcGePoint3dLike, end: AcGePoint3dLike): this;
    /**
     * Sets the landing point for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param point New landing point, or `undefined` to clear it.
     * @returns The current entity instance for chaining.
     */
    setLandingPoint(leaderIndex: number, point: AcGePoint3dLike | undefined): this;
    /**
     * Sets the dogleg direction for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param vector New dogleg direction vector.
     * @returns The current entity instance for chaining.
     */
    setDoglegDirection(leaderIndex: number, vector: AcGeVector3dLike): this;
    /**
     * Sets the dogleg length for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param length New dogleg length, or `undefined` to clear the override.
     * @returns The current entity instance for chaining.
     */
    setDoglegLength(leaderIndex: number, length: number | undefined): this;
    /**
     * Applies a multileader style the way AutoCAD does for a new MLEADER: the
     * entity references the style and receives its sizes (scaled by the
     * style's overall scale, or by `annotationScale` for annotative styles),
     * landing, leader type, text style and text attachment settings.
     *
     * @param style Multileader style to apply.
     * @param annotationScale Current annotation scale factor (drawing units per
     *   paper unit, e.g. `50` for CANNOSCALE `1:50`); only used when the style
     *   is annotative.
     * @returns The current entity instance for chaining.
     */
    applyMLeaderStyle(style: AcDbMLeaderStyle, annotationScale?: number): this;
    /**
     * Places the content next to a landing like AutoCAD: MText is attached by
     * its left side when the landing points right (by its right side
     * otherwise), one landing gap past the landing end, at the height given by
     * the left / right text attachment type. Block content is inserted at the
     * landing end. Also stores the landing end as
     * {@link contentBasePosition}.
     *
     * @param leaderIndex Branch whose landing the content attaches to.
     * @returns The current entity instance for chaining.
     */
    attachContentToLanding(leaderIndex?: number): this;
    /**
     * Adds a leader line whose arrowhead is at `point`, like AutoCAD's
     * `AcDbMLeader::addLeaderLine(point)` and MLEADEREDIT *Add leader*: the
     * line joins the existing landing on the side of the content facing
     * `point`; when no landing faces it, a new landing is created on that side
     * of the content (one landing gap past its far edge).
     *
     * @param point Arrowhead location of the new leader line.
     * @returns Indices of the branch and of the new line in that branch.
     */
    addLeaderLineAtPoint(point: AcGePoint3dLike): {
        leaderIndex: number;
        leaderLineIndex: number;
    };
    /**
     * Gets the axis-aligned extents computed from all geometry points.
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets grip points used for interactive editing.
     *
     * Mirrors AutoCAD's MLEADER grips: one grip per leader-line vertex
     * (arrowhead tip and intermediate vertices), one landing grip where the
     * leader lines meet the landing, one grip at the far end of the landing
     * (lengthen landing) and one content grip (text / block location).
     * Coincident internal points are never exposed as separate grips, so a
     * drag always edits the whole multileader consistently.
     *
     * @returns Grip points in the same order {@link subMoveGripPointsAt} uses.
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Moves grips returned by {@link subGetGripPoints}.
     *
     * - Vertex grips stretch that vertex only.
     * - The landing grip and the content grip move the content together with
     *   every landing (leader tips stay), flipping a landing to the other side
     *   of the content when the content crosses its leader (AutoCAD *Stretch*).
     * - The landing-end grip lengthens the landing along its direction and keeps
     *   the content attached (AutoCAD *Lengthen Landing*).
     *
     * @param indices Grip indices to move.
     * @param offset Displacement applied to the grips.
     * @returns The current entity instance for chaining.
     */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Local stretch: move selected stretch points via grip editing.
     */
    subMoveStretchPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this multileader.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Applies a transformation matrix to this entity.
     *
     * Points are transformed and direction vectors stay unit vectors. Like
     * AutoCAD SCALE on a MULTILEADER, a scale also scales the whole annotation:
     * text height, arrowhead size, landing gap, dogleg length, text column
     * sizes and the block content scale are multiplied by the uniform scale
     * factor of the matrix.
     *
     * @param matrix Transformation matrix applied to all geometry and vectors.
     * @returns The current entity instance for chaining.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Multiplies every size of the annotation by `scale` (AutoCAD SCALE).
     *
     * Sizes that currently come from the multileader style are stored on the
     * entity (and the dogleg-length override flag is set) so the scaled value
     * is the one that is drawn.
     *
     * @param scale Uniform scale factor.
     */
    private scaleSizes;
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     *
     * @returns The current entity instance with effective properties resolved.
     */
    resolveEffectiveProperties(): void;
    /**
     * Builds renderable primitives for this multileader entity.
     *
     * @param renderer Graphics renderer used to create draw entities.
     * @returns A single entity, an entity group, or undefined when nothing is drawable.
     */
    /**
     * Resolves text/arrow sizes and metadata for the active CANNOSCALE when
     * this multileader is annotative.
     */
    resolveAnnotativePresentation(): {
        textHeight: number;
        arrowheadSize: number;
        textAnchor?: AcGePoint3d;
        preferred?: AcDbAnnotationScaleContext;
        annotationScale?: AcDbAnnotationScaleDrawInfo;
    };
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Explodes this multileader like AutoCAD EXPLODE.
     *
     * The result mirrors what {@link subWorldDraw} shows: each leader line
     * becomes lines (a spline for spline leaders), each dogleg a line, each
     * arrowhead a block reference of the arrow block (or a solid for the
     * default closed filled arrow), the text content an {@link AcDbMText} and
     * block content a block reference. The parts take the multileader's
     * properties, with the leader-line / text colors, linetype and lineweight
     * resolved from the multileader style.
     */
    protected subExplode(): AcDbEntity[];
    /**
     * Creates the leader lines, doglegs and arrowheads for {@link subExplode}.
     */
    private explodeLeaderLines;
    /**
     * Creates the arrowhead entity of one leader line for {@link subExplode},
     * mirroring {@link drawArrowhead}.
     */
    private createArrowheadEntity;
    /**
     * Creates the text and block content for {@link subExplode}.
     */
    private explodeContent;
    /**
     * Adds the MLEADER style, linetype, arrow block, text style and block
     * content this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Points a cloned MLEADER at the objects in the destination database.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Writes this multileader entity to DXF group codes.
     *
     * @param filer DXF filer that receives serialized values.
     * @returns The current entity instance for chaining.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Finalizes MLEADER fields after DXF group codes are consumed.
     */
    private finishMLeaderDxfIn;
    /**
     * Parses the native AutoCAD `CONTEXT_DATA{ ... }` block (group 300/301).
     *
     * Mirrors dxf-json `parseContextData` so built-in DXF reading matches the
     * converter path used by `@mlightcad/dxf-json`.
     */
    private dxfInContextData;
    /**
     * Parses one `LEADER{ ... }` section (group 302/303) inside CONTEXT_DATA.
     */
    private dxfInLeaderSection;
    /**
     * Parses one `LEADER_LINE{ ... }` block (group 304/305) inside a LEADER section.
     */
    private dxfInLeaderLine;
    private readDxfBoolean;
    private isValidMLeaderHandle;
    /**
     * Creates a concrete point from point-like input.
     *
     * @param point Source point-like value.
     * @returns A newly created point instance.
     */
    private createPoint;
    /**
     * Normalizes one leader-line payload into internal storage format.
     *
     * @param line Source leader-line payload.
     * @returns A normalized leader line.
     */
    private createLeaderLine;
    /**
     * Creates a deep clone of a leader branch.
     *
     * @param leader Leader branch to clone.
     * @returns A deep-cloned leader branch.
     */
    private cloneLeader;
    /**
     * Validates that a leader index is in range.
     *
     * @param leaderIndex Leader branch index to validate.
     * @throws {Error} Thrown when `leaderIndex` is outside valid range.
     * @returns `void`.
     */
    private checkLeaderIndex;
    /**
     * Gets a mutable leader line by branch and line index.
     *
     * @param leaderIndex Leader branch index.
     * @param leaderLineIndex Leader-line index in the branch.
     * @returns The mutable leader line reference.
     */
    private getMutableLeaderLine;
    /**
     * Collects all geometry points contributing to draw/extents calculations.
     *
     * @returns Geometry point collection.
     */
    private collectGeometryPoints;
    /**
     * Estimated world corners of the MText content, or `undefined` when the
     * multileader has no MText content.
     */
    private getMTextBounds;
    /**
     * Center of the content used to decide which side a new leader joins.
     */
    private getContentCenter;
    /**
     * Builds the AutoCAD-style grip list shared by {@link subGetGripPoints} and
     * {@link subMoveGripPointsAt}.
     */
    private collectGrips;
    /**
     * Point where the leader lines of one branch meet its landing.
     */
    private getLeaderConnectionPoint;
    /**
     * Location of the content grip: MText location or block position.
     */
    private getContentGripPoint;
    /**
     * Unit landing direction of one branch (from the leader towards content).
     */
    private getLandingDirection;
    /**
     * Translates the content (text / block and their stored anchors).
     */
    private translateContent;
    /**
     * Moves one branch's landing (connection point) and any leader-line
     * vertex stored on top of it.
     */
    private translateLanding;
    /**
     * Rigidly moves the content and every landing; leader vertices stay.
     */
    private moveContentAndLandings;
    /**
     * Lengthens (or shortens) the landing of one branch and keeps the content
     * and the other landings attached to it.
     */
    private lengthenLanding;
    /**
     * Flips landings whose leader now arrives from the content side, so the
     * landing always points from the leader towards the content (AutoCAD
     * switches the landing to the other side of the text in that case).
     */
    private reorientLandings;
    /**
     * True when at least one leader line of the branch approaches the landing
     * from the content side (content has crossed that tip).
     */
    private isLandingApproachedFromBehind;
    /**
     * Horizontal side the MText is attached by: `1` left, `-1` right, `0`
     * centered or not MText.
     */
    private getTextAttachmentSide;
    /**
     * Resolves the final draw points for a leader line.
     *
     * @param leader Owning leader branch.
     * @param line Leader line to resolve.
     * @returns The resolved draw-point sequence.
     */
    private getLeaderLineDrawPoints;
    /**
     * Computes the dogleg / landing segment points for a leader branch.
     *
     * When {@link contentBasePosition} is present it is the far end of the
     * horizontal landing stored in CONTEXT_DATA (including underline-style
     * attachments under MText). Prefer that endpoint over `doglegLength`: some
     * DWG exports keep an undersized length while `contentBasePosition` still
     * spans the full landing (handle 1549: underline under `（配焊）`).
     *
     * @param leader Leader branch to evaluate.
     * @returns Dogleg segment points, or `undefined` if not applicable.
     */
    private getDoglegPoints;
    /**
     * Builds arrowhead polyline points from leader-line points.
     *
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Arrowhead points, or `undefined` when no arrowhead is drawable.
     */
    private getArrowheadPoints;
    /**
     * Checks whether an arrowhead should be rendered.
     *
     * @returns `true` if arrowhead configuration is visible.
     */
    private isArrowheadVisible;
    /**
     * Draws one leader line and applies arrow style from MLEADER/MLEADERSTYLE.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line draw points.
     * @returns One entity or an entity group representing the full leader line.
     */
    private drawLeaderLine;
    /**
     * Resolves leader-line points used for stroke drawing after arrow overlap trim.
     *
     * @param points Original leader polyline points.
     * @returns Trimmed points used to draw the leader stroke.
     */
    private getLeaderLinePointsForDraw;
    /**
     * Resolves how much of leader start should be trimmed to avoid arrow overlap.
     *
     * @returns Trim distance in drawing units.
     */
    private getArrowheadLeaderLineTrimDistance;
    /**
     * Trims the start of a polyline by a given distance.
     *
     * @param points Polyline points.
     * @param trimDistance Distance to trim from the start.
     * @returns Trimmed polyline points.
     */
    private trimPolylineStart;
    /**
     * Draws one arrowhead primitive from leader-line points.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Arrowhead entity, or `undefined` when no arrowhead is drawable.
     */
    private drawArrowhead;
    /**
     * Draws arrowhead by rendering entities from referenced arrow block record.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Rendered block-based arrowhead entity, or `undefined`.
     */
    private drawArrowheadBlock;
    /**
     * Resolves tip point and direction for arrowhead placement.
     *
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Tip and normalized direction, or `undefined` when unavailable.
     */
    private getArrowheadFrame;
    /**
     * Resolves the effective arrowhead id.
     *
     * @returns Arrowhead id used for rendering.
     */
    private getResolvedArrowheadId;
    /**
     * Resolves arrowhead block record by Arrowhead ID handle.
     *
     * @returns Arrowhead block table record, or `undefined` when not found.
     */
    private getResolvedArrowheadBlockTableRecord;
    /**
     * Base (non-annotative) arrowhead size from entity / style overrides.
     */
    private getBaseArrowheadSize;
    /**
     * Resolves the effective arrowhead size (annotative when drawing).
     *
     * @returns Arrowhead size used for rendering.
     */
    private getResolvedArrowheadSize;
    /**
     * Base (non-annotative) text height from entity / style overrides.
     */
    private getBaseTextHeight;
    /**
     * Resolves renderable MText content using entity content first, with style fallback.
     *
     * @returns Renderable text payload, or `undefined` when unavailable.
     */
    private getRenderableMTextContent;
    /**
     * Computes render width for current MText content.
     *
     * AutoCAD/GstarCAD treat MLeader `textWidth` of `0` as an auto-sized box
     * (no soft wrap). Inventing a `length × height` wrap column here made CJK
     * labels such as `（配焊）` break mid-token when TrueType advances exceed the
     * estimate (handle 1549). Keep width `0` so the MTEXT renderer lays out a
     * single unwrapped line; only a positive declared width is a wrap column.
     *
     * @param _text Source MText content string (unused when width is auto).
     * @param _textHeight Effective text height (unused when width is auto).
     * @returns Explicit wrap width, or `0` for AutoCAD-style auto width.
     */
    private getMTextRenderWidth;
    /**
     * Resolves the referenced MLeader style object.
     *
     * @returns Resolved style object or `undefined` when not available.
     */
    private getMLeaderStyle;
    /**
     * Resolves the default MLEADER style from CMLEADERSTYLE, with first-entry fallback.
     *
     * @returns Default style object or `undefined` when style dictionary is empty.
     */
    private getDefaultMLeaderStyle;
    /**
     * Resolves one MLEADER style by style name (dictionary key) or object ID.
     *
     * @param styleName Style name or object id candidate.
     * @returns Matching style object, or `undefined` when not found.
     */
    private resolveMLeaderStyleByName;
    /**
     * Resolves current CMLEADERSTYLE value with a stable default fallback.
     *
     * @returns Preferred default style name.
     */
    private getDefaultMLeaderStyleName;
    /**
     * Resolves text style name considering entity values, ids and style fallback.
     *
     * @returns Resolved text style name, or `undefined` when unresolved.
     */
    private getResolvedTextStyleName;
    /**
     * Resolves the text style used by renderer-side MText drawing.
     *
     * @returns A valid text style object.
     */
    private getTextStyle;
    /**
     * Marks a style property as overridden by this entity (DXF group 90).
     */
    private setPropertyOverride;
    /**
     * Resolves effective leader-line color by override-flag and style rules.
     *
     * @returns Effective leader-line color.
     */
    private getResolvedLeaderLineColor;
    /**
     * Resolves effective leader-line geometry type.
     *
     * @returns Effective leader-line type.
     */
    private getResolvedLeaderLineType;
    /**
     * Resolves effective leader-line linetype id/handle.
     *
     * @returns Effective linetype id, or `undefined` when not available.
     */
    private getResolvedLeaderLineTypeId;
    /**
     * Resolves renderer linetype style for leader lines.
     *
     * @returns User-specified renderer linetype style, or `undefined`.
     */
    private getResolvedLeaderLineStyle;
    /**
     * Resolves effective leader-line weight by override-flag and style rules.
     *
     * @returns Effective line weight, or `undefined`.
     */
    private getResolvedLeaderLineWeight;
    /**
     * Resolves whether dogleg drawing is effectively enabled.
     *
     * @returns Effective dogleg-enabled state.
     */
    private getResolvedDoglegEnabled;
    /**
     * Resolves effective dogleg length by override-flag and style rules.
     *
     * @returns Effective dogleg length.
     */
    private getResolvedDoglegLength;
    /**
     * Resolves effective text color by override-flag and style rules.
     *
     * @returns Effective text color.
     */
    private getResolvedTextColor;
    /**
     * Resolves effective component color from entity raw value and style fallback.
     *
     * @param rawEntityColor Raw DXF color value stored on the entity.
     * @param styleColor Style-level fallback color.
     * @param overrideFlagMask Property-override flag mask for this component.
     * @returns Effective color used for rendering and trait application.
     */
    private getResolvedComponentColor;
    /**
     * Resolves effective value using override-flag and style fallback rules.
     *
     * @typeParam T Value type.
     * @param entityValue Value stored on the entity.
     * @param styleValue Value provided by style.
     * @param overrideFlagMask Property-override flag mask for this component.
     * @returns Effective resolved value.
     */
    private getResolvedStyleDrivenValue;
    /**
     * Checks whether a specific property-override bit is enabled.
     *
     * @param flagMask Bit mask for the property being queried.
     * @returns `true` if enabled, `false` if disabled, or `undefined` when flag is absent.
     */
    private isPropertyOverrideEnabled;
    /**
     * Applies color traits while preserving original values for reset.
     *
     * ByLayer / ByBlock component colors must be resolved to a concrete swatch
     * before they reach the renderer. Leaving an unresolved ByLayer
     * {@link AcCmColor} on the traits makes
     * {@link AcGiContext.resolveSubEntityTraitsRgb} fall back to white, which is
     * why ByLayer MULTILEADER lines on a green layer (e.g. handles 35F9B /
     * 24F18) painted ACI 7 instead of the layer color. ByBlock keeps the
     * entity color already stored by {@link worldDraw}.
     *
     * @param traits Renderer traits object to mutate.
     * @param color Effective component color to apply.
     * @param originalColor Original trait color value.
     * @param originalIsColorByLayer Original trait ByLayer provenance.
     * @returns `void`.
     */
    private applyColorTraits;
    /**
     * Applies line style traits when resolved values are available.
     *
     * @param traits Renderer traits object to mutate.
     * @param lineType Resolved linetype style.
     * @param lineWeight Resolved line weight.
     * @returns `void`.
     */
    private applyLineTraits;
}
//# sourceMappingURL=AcDbMLeader.d.ts.map