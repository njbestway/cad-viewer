import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js';
import type { AcDbCloneDependencies, AcDbIdMapping } from '../base/AcDbIdMapping.js';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js';
import { AcDbCurve } from './AcDbCurve.js';
import { AcDbEntity } from './AcDbEntity.js';
import { AcDbEntityProperties } from './AcDbEntityProperties.js';
/**
 * Defines the annotation type for leader entities.
 */
export declare enum AcDbLeaderAnnotationType {
    /** Multiline text annotation */
    MText = 0,
    /** Feature control frame annotation */
    Fcf = 1,
    /** Block reference annotation */
    BlockReference = 2,
    /** No annotation */
    NoAnnotation = 3
}
/**
 * Represents a leader entity in AutoCAD.
 *
 * A leader is a dimension-like entity that consists of a line or spline with an arrowhead
 * pointing to a specific object or location, and an annotation (text, block, or feature
 * control frame) at the other end. Leaders are controlled by dimension variable settings
 * and dimension styles.
 *
 * @example
 * ```typescript
 * // Create a leader entity
 * const leader = new AcDbLeader();
 * leader.appendVertex(new AcGePoint3d(0, 0, 0));
 * leader.appendVertex(new AcGePoint3d(5, 5, 0));
 * leader.appendVertex(new AcGePoint3d(10, 5, 0));
 * leader.hasArrowHead = true;
 * leader.hasHookLine = true;
 * leader.annoType = AcDbLeaderAnnotationType.MText;
 *
 * // Access leader properties
 * console.log(`Number of vertices: ${leader.numVertices}`);
 * console.log(`Has arrow head: ${leader.hasArrowHead}`);
 * console.log(`Has hook line: ${leader.hasHookLine}`);
 * ```
 */
export declare class AcDbLeader extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Whether this leader is spline-fit */
    private _isSplined;
    /** The spline geometry if this leader is spline-fit */
    private _splineGeo?;
    /** Whether this leader has been updated */
    private _updated;
    /** Whether this leader has an arrowhead */
    private _hasArrowHead;
    /** The vertices of the leader line */
    private _vertices;
    /** The dimension style applied to this leader */
    private _dimensionStyle;
    /** Memoized effective style (table record plus `ACAD`/`DSTYLE` overrides). */
    private _dimStyle?;
    /** Name the memoized {@link _dimStyle} was resolved for. */
    private _dimStyleName?;
    /** Whether this leader has a hook line */
    private _hasHookLine;
    /** Whether the hook line has the same direction as the horizontal vector */
    private _isHookLineSameDirection;
    /** The annotation type for this leader */
    private _annoType;
    private _textHeight;
    private _textWidth;
    private _byBlockColor?;
    private _associatedAnnotation;
    private _normal;
    private _horizontalDirection;
    private _offsetFromBlock?;
    private _offsetFromAnnotation?;
    /**
     * Creates a new leader entity.
     *
     * This constructor initializes a leader with default values.
     * The leader is not spline-fit, has no arrowhead, no hook line,
     * and no annotation type.
     *
     * @example
     * ```typescript
     * const leader = new AcDbLeader();
     * leader.appendVertex(new AcGePoint3d(0, 0, 0));
     * leader.appendVertex(new AcGePoint3d(5, 5, 0));
     * ```
     */
    constructor();
    /**
     * Gets whether this leader is spline-fit.
     *
     * @returns True if the leader is spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * const isSplined = leader.isSplined;
     * console.log(`Leader is spline-fit: ${isSplined}`);
     * ```
     */
    get isSplined(): boolean;
    /**
     * Sets whether this leader is spline-fit.
     *
     * @param value - True to make the leader spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * leader.isSplined = true;
     * ```
     */
    set isSplined(value: boolean);
    /**
     * Gets whether this leader has an arrowhead.
     *
     * @returns True if the leader has an arrowhead, false otherwise
     *
     * @example
     * ```typescript
     * const hasArrowHead = leader.hasArrowHead;
     * console.log(`Leader has arrowhead: ${hasArrowHead}`);
     * ```
     */
    get hasArrowHead(): boolean;
    /**
     * Sets whether this leader has an arrowhead.
     *
     * @param value - True to enable arrowhead, false to disable
     *
     * @example
     * ```typescript
     * leader.hasArrowHead = true;
     * ```
     */
    set hasArrowHead(value: boolean);
    /**
     * Gets whether this leader has a hook line.
     *
     * The "hookline" is the small horizontal line at the end of the leader line
     * just before the annotation.
     *
     * @returns True if the leader has a hook line, false otherwise
     *
     * @example
     * ```typescript
     * const hasHookLine = leader.hasHookLine;
     * console.log(`Leader has hook line: ${hasHookLine}`);
     * ```
     */
    get hasHookLine(): boolean;
    /**
     * Sets whether this leader has a hook line.
     *
     * @param value - True to enable hook line, false to disable
     *
     * @example
     * ```typescript
     * leader.hasHookLine = true;
     * ```
     */
    set hasHookLine(value: boolean);
    get isHookLineSameDirection(): boolean;
    set isHookLineSameDirection(value: boolean);
    /**
     * Gets the number of vertices in the leader's vertex list.
     *
     * @returns The number of vertices
     *
     * @example
     * ```typescript
     * const numVertices = leader.numVertices;
     * console.log(`Number of vertices: ${numVertices}`);
     * ```
     */
    get numVertices(): number;
    get vertices(): AcGePoint3d[];
    /**
     * Gets the dimension style applied to this leader.
     *
     * @returns The dimension style name
     *
     * @example
     * ```typescript
     * const dimensionStyle = leader.dimensionStyle;
     * console.log(`Dimension style: ${dimensionStyle}`);
     * ```
     */
    get dimensionStyle(): string;
    /**
     * Sets the dimension style applied to this leader.
     *
     * @param value - The new dimension style name
     *
     * @example
     * ```typescript
     * leader.dimensionStyle = "Standard";
     * ```
     */
    set dimensionStyle(value: string);
    /**
     * Gets the leader's annotation type.
     *
     * @returns The annotation type
     *
     * @example
     * ```typescript
     * const annoType = leader.annoType;
     * console.log(`Annotation type: ${annoType}`);
     * ```
     */
    get annoType(): AcDbLeaderAnnotationType;
    /**
     * Sets the leader's annotation type.
     *
     * @param value - The new annotation type
     *
     * @example
     * ```typescript
     * leader.annoType = AcDbLeaderAnnotationType.MText;
     * ```
     */
    set annoType(value: AcDbLeaderAnnotationType);
    get textHeight(): number;
    set textHeight(value: number);
    get textWidth(): number;
    set textWidth(value: number);
    get byBlockColor(): number | undefined;
    set byBlockColor(value: number | undefined);
    get associatedAnnotation(): string;
    set associatedAnnotation(value: string);
    get normal(): AcGeVector3dLike;
    set normal(value: AcGeVector3dLike);
    get horizontalDirection(): AcGeVector3dLike;
    set horizontalDirection(value: AcGeVector3dLike);
    get offsetFromBlock(): AcGeVector3dLike | undefined;
    set offsetFromBlock(value: AcGeVector3dLike | undefined);
    get offsetFromAnnotation(): AcGeVector3dLike | undefined;
    set offsetFromAnnotation(value: AcGeVector3dLike | undefined);
    /**
     * Returns the runtime property definition of this leader so the property
     * palette can show and edit it like other entities.
     *
     * The palette resolves each `name` through the `entity.property` locale
     * namespace and each enum `label` through `entity.enum`, so the names used
     * here are the ones translated by the viewer.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Builds one runtime property, marking it editable only when a setter exists.
     */
    private createProperty;
    /**
     * Builds the X/Y/Z properties of a vector that may not be present yet.
     *
     * Reading an absent vector returns `undefined` so the palette shows an empty
     * cell; writing any component materializes the vector with the other
     * components defaulting to `0`.
     */
    private createOptionalPoint3dProperties;
    /**
     * Appends vertex to the end of the vertex list for this leader. If vertex is not in the plane of the
     * leader, then it will be projected parallel the leader's normal onto the leader's plane and the
     * projection will be appended to the leader's vertex list. If the new vertex is too close to the one
     * next to it (that is, within 1.e-10 for X, Y, and Z), the new vertex will not be appended.
     * @param point Input point (in WCS coordinates) to add to the vertex list
     */
    appendVertex(point: AcGePoint3dLike): void;
    /**
     * Reset the vertex at index to the point point projected (along the plane normal) onto the plane
     * containing the leader. It doesn't reset the vertex if that would cause one of the segments to
     * become zero length (within 1e-10).
     * @param index Input index number (0 based) of the vertex to change
     * @param point Input new point value (in WCS) to use
     */
    setVertexAt(index: number, point: AcGePoint3dLike): this;
    /**
     * Get the point that is the vertex at the location index (0 based) in this leader's vertex array.
     * @param index Input index number (0 based) of the vertex desired
     */
    vertexAt(index: number): AcGePoint3d;
    /**
     * Gets the grip points for this leader.
     *
     * @returns Array of grip points at each leader vertex.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Local stretch: move selected stretch points via grip editing.
     */
    subMoveStretchPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this leader.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * @inheritdoc
     */
    get closed(): boolean;
    set closed(_value: boolean);
    /** @inheritdoc */
    get area(): number;
    /**
     * Transforms this leader by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * This leader draws as a single `lineStrip` primitive unless drawing it
     * needs more than the entity color already applied by `worldDraw`.
     *
     * An arrowhead (DXF 71) adds a second primitive. A DIMCLRD or group 77 color
     * that differs from the entity color is applied inside `subWorldDraw`, and a
     * geometry-only batch would keep the entity color instead. Either case falls
     * back to the legacy draw path. The style lookup is memoized on the leader.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip" | null;
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity;
    /**
     * Explodes this leader like AutoCAD EXPLODE: the leader path becomes lines
     * (a spline for a splined leader, including the hook line) and the
     * arrowhead becomes a block reference of the arrow block, or a solid for
     * the default closed filled arrow when no such block exists.
     *
     * The associated annotation is a separate entity and is not included. The
     * parts take the leader's properties; when the dimension style assigns the
     * leader a color (DIMCLRD), the parts use that color.
     */
    protected subExplode(): AcDbEntity[];
    /**
     * Color assigned to the exploded leader parts.
     *
     * Unlike {@link resolveLeaderLineColor} (a display color, where ByLayer is
     * already resolved to the layer's actual color), this keeps ByLayer as
     * ByLayer, as AutoCAD EXPLODE does, so the parts keep following their
     * layer. `undefined` means the parts keep the leader's own color (DIMCLRD
     * ByBlock without a group 77 override, or no dimension style).
     */
    private resolveExplodedLeaderLineColor;
    /**
     * Creates the entity representing the arrowhead for {@link subExplode},
     * mirroring the geometry drawn by {@link drawArrowHead}.
     */
    private createArrowHeadEntity;
    /**
     * Whether an arrowhead primitive is emitted at the leader start.
     *
     * DXF group code 71 (`hasArrowHead`) is authoritative: when it is 0 AutoCAD
     * draws no arrowhead at all. The arrow geometry itself comes from the
     * dimension style (DIMLDRBLK arrow block scaled by DIMASZ).
     */
    private get hasRenderableArrowHead();
    /**
     * Color of the leader line and arrowhead.
     *
     * AutoCAD paints both from DIMCLRD. An explicit ACI (including a DSTYLE
     * override) wins over the entity color, which is why a ByLayer leader on
     * layer 0 still draws red when DIMCLRD is 1. ByBlock keeps the entity
     * color, unless DXF group 77 names a color to use in that case. Group 77
     * follows the same ACI convention as group 62: 256 is ByLayer.
     *
     * @returns The dimension color, or `undefined` when the entity color
     *   already on the renderer traits should be kept.
     */
    private resolveLeaderLineColor;
    /**
     * Whether {@link resolveLeaderLineColor} would paint something other than
     * the color `worldDraw` already stored on the renderer, including whether
     * that color follows the layer.
     */
    private leaderLineColorDiffersFromEntity;
    /**
     * Whether {@link resolveLeaderLineColor} paints the layer color: DIMCLRD is
     * ByLayer, or ByBlock with group 77 set to ByLayer. The returned color is
     * already concrete, so renderers need this to keep it bound to the layer.
     */
    private leaderLineColorFollowsLayer;
    /**
     * DXF group 77, used only when DIMCLRD is ByBlock.
     *
     * `0` and a missing value keep the entity color. `256` is ByLayer.
     */
    private resolveByBlockLeaderColor;
    /**
     * Layer color for DIMCLRD / group 77 ByLayer.
     *
     * The returned color is a clone so assigning it to renderer traits cannot
     * mutate the layer table record.
     */
    private resolveLayerLeaderColor;
    /**
     * Draws the arrowhead (DXF group code 71) at the first leader vertex.
     *
     * The tip sits on the first vertex and the tail points toward the second
     * vertex. Arrow blocks are authored with the tip at the block origin and the
     * tail along -X, so the insert angle maps block +X onto the outward leader
     * direction. When the referenced block is missing, the built-in AutoCAD
     * arrow blocks are generated on demand; only the default closed filled arrow
     * can still be reproduced procedurally if that lookup also fails.
     *
     * @param renderer - Renderer used to create the primitive.
     * @param points - Leader draw points whose first entry is the arrow tip.
     * @param leaderColor - DIMCLRD color, when it replaces the entity color.
     * @returns The arrowhead primitive, or `undefined` when none is drawn.
     */
    private drawArrowHead;
    /**
     * Resolves the arrowhead size in drawing units.
     *
     * AutoCAD documents DIMASZ as "the size of dimension line **and leader line**
     * arrowheads", so leaders always use DIMASZ (not the DIMTSZ oblique-tick size,
     * which only replaces terminators on linear/radius/diameter dimensions).
     * DIMASZ is scaled by the effective dimension/annotation scale.
     */
    private resolveArrowHeadSize;
    /**
     * Resolves the leader arrowhead block name from DIMLDRBLK.
     *
     * An empty DIMLDRBLK means the default closed filled arrow; `_NONE` resolves
     * to an empty name so no arrowhead is drawn.
     */
    private resolveArrowHeadBlockName;
    /**
     * Looks up the arrowhead block table record by name.
     */
    private resolveArrowHeadBlock;
    /**
     * Builds the leader polyline including the optional horizontal hook line
     * segment that spans the associated annotation width.
     */
    private collectDrawPoints;
    /**
     * Whether a hook line (the landing segment at the annotation end) should be
     * rendered for the landing vertex.
     *
     * DXF group code 75 (and its DWG equivalent `hookline_on`) is authoritative:
     * when it is 0 AutoCAD does not draw any landing segment, even if the leader
     * happens to sit next to a text entity. Only a leader that advertises a hook
     * line is extended here.
     */
    private shouldDrawHookLine;
    /**
     * Computes the hook-line endpoint from the last leader vertex.
     */
    private computeHookLineEndPoint;
    /**
     * Resolves the hook-line (landing segment) length and side.
     *
     * The landing segment spans the annotation box (DXF 41 / associated MTEXT
     * width) plus the dimension-style gap. A negative DXF 41 means the author
     * flipped the landing to the opposite side, which matches AutoCAD. When no
     * annotation width can be resolved there is nothing to land under, so the
     * hook line is skipped instead of drawing a gap-sized stub past the author's
     * own geometry.
     *
     * @returns The absolute landing length.
     */
    private resolveHookLineLength;
    /**
     * Returns the signed axis along which the hook line extends.
     *
     * DXF 74 gives the hook-line direction relative to the horizontal vector and
     * a negative DXF 41 (annotation box width) flips it once more.
     */
    private resolveHookAxis;
    /**
     * Computes hook span from the landing vertex to the far edge of MTEXT bounds.
     *
     * The span is measured along the resolved landing axis, which already folds
     * in the DXF 74 direction and a negative DXF 41 flip.
     */
    private resolveHookSpanFromMText;
    /**
     * Estimates annotation width from MTEXT content when extents are unavailable.
     */
    private resolveAnnotationWidth;
    private resolveMTextLayoutMetrics;
    /**
     * Scores how closely one MTEXT annotation matches a leader landing vertex.
     */
    private scoreMTextAssociation;
    /**
     * Resolves the dimension style referenced by this leader.
     *
     * Entity-level `ACAD`/`DSTYLE` XData overrides are layered on top of the
     * referenced table record, so per-leader changes to DIMASZ / DIMGAP /
     * DIMLDRBLK take effect the way AutoCAD draws them.
     *
     * The resolved record is memoized: a leader with overrides needs the
     * detached style copy, and `subWorldDraw` asks for the style several times
     * per frame (arrow size, arrow block name, hook gap).
     */
    private resolveDimensionStyle;
    /**
     * Drops the memoized effective style when `ACAD` XData changes.
     */
    protected onXDataChanged(appId: string): void;
    /**
     * Drops the memoized effective style when the leader moves to another
     * database, because the referenced style record belongs to the previous one.
     */
    protected onDatabaseChanged(): void;
    /**
     * Resolves the MTEXT annotation associated with this leader.
     *
     * An explicit `associatedAnnotation` hard pointer (DXF 340) always wins.
     * The spatial search is only a fallback for leaders that were created with an
     * MTEXT annotation (DXF 73 = 0); a standalone leader (DXF 73 = 3) has no
     * annotation, so borrowing an unrelated nearby MTEXT would corrupt its
     * landing geometry.
     */
    private resolveAssociatedMText;
    private tryGetDatabase;
    private get splineGeo();
    private createSplineIfNeeded;
    /**
     * Adds the dimension style this entity references.
     *
     * @param deps - Dependency collector.
     */
    collectCloneDependencies(deps: AcDbCloneDependencies): void;
    /**
     * Translates the dimension style name and the associated annotation of a
     * cloned entity. The annotation is dropped when it was not cloned along.
     *
     * @param idMap - Id mapping of the current clone operation.
     */
    translateClonedReferences(idMap: AcDbIdMapping): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the leader's vertex path in the XY plane and returns an {@link AcDbPolyline}.
     * Splined leaders are sampled before offsetting; the leader is always treated as an
     * open path.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Side test follows the straight or sampled spline path as an open polyline.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline along the leader path, or `null` when offset fails
     */
    private createOffsetCurve;
    /**
     * Flattens the leader geometry to a 2D vertex list for offset operations.
     *
     * Uses 64 samples from the fit spline when {@link isSplined} is true; otherwise
     * returns the stored WCS vertices projected to XY.
     *
     * @returns Leader path in the XY plane
     */
    private collectPath2d;
    private transformVector;
}
//# sourceMappingURL=AcDbLeader.d.ts.map